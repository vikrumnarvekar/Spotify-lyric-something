package com.example.lyricspopup

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LyricsResult(
    val plain: String?,              // un-timed lyrics, if any
    val synced: List<LrcLine>,       // timed lines (empty if the song has no synced lyrics)
    val instrumental: Boolean,
    val geniusUrl: String?,          // link to the song on Genius, if matched
    val error: String? = null        // set when the lookup failed (e.g. no network)
) {
    val hasLyrics get() = synced.isNotEmpty() || !plain.isNullOrBlank()
}

/**
 * Lyrics text comes from LRCLIB (https://lrclib.net), a free community lyrics API.
 * Genius is used (official API, needs a free client access token) to match the song, find its
 * spelling of the title/artist for extra retries, and provide an "open on Genius" link: the
 * Genius API returns metadata, not lyrics, and scraping genius.com is against its terms.
 *
 * Call [fetch] from a background thread.
 */
class LyricsRepository(private val geniusToken: () -> String) {

    private class Http(val code: Int, val body: String?)
    private class GeniusHit(val url: String, val title: String, val artist: String)

    private val cache = object : LinkedHashMap<String, LyricsResult>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LyricsResult>?) = size > 40
    }

    fun fetch(title: String, artist: String, album: String, durationMs: Long): LyricsResult {
        val key = "$title|$artist|$durationMs"
        synchronized(cache) { cache[key] }?.let { return it }

        val durationSec = if (durationMs > 0) durationMs / 1000.0 else null
        var networkFailed = false

        val cleaned = TrackText.cleanTitle(title)
        val primary = TrackText.primaryArtist(artist)
        // Looked up only if needed (no token -> null, no network call).
        val genius by lazy { geniusMatch(cleaned, primary) }

        fun candidate(http: Http?): Candidate? {
            if (http == null) { networkFailed = true; return null }
            val body = http.body ?: return null
            return try { toCandidate(JSONObject(body)) } catch (e: Exception) { null }
        }

        fun searchAll(urls: List<String>): Candidate? {
            for (u in urls) {
                val http = get(u)
                if (http == null) { networkFailed = true; continue }
                val arr = try { JSONArray(http.body ?: "[]") } catch (e: Exception) { JSONArray() }
                val list = (0 until arr.length()).mapNotNull {
                    try { toCandidate(arr.getJSONObject(it)) } catch (e: Exception) { null }
                }
                val found = TrackText.pick(list, durationSec)
                if (found != null) return found
            }
            return null
        }

        // 1) exact lookups, most specific first
        var best: Candidate? = null
        val titles = listOf(title, cleaned).distinct()
        val artists = listOf(artist, primary).distinct()
        outer@ for (t in titles) for (a in artists) {
            val c = candidate(get(lrclibGetUrl(t, a, album, durationSec)))
            if (c != null && (c.instrumental || !c.plain.isNullOrBlank() || !c.synced.isNullOrBlank())) {
                best = c
                break@outer
            }
        }

        // 2) fuzzy searches; pick() only accepts a record whose length matches the track
        if (best == null) {
            val urls = ArrayList<String>()
            urls.add("https://lrclib.net/api/search?track_name=${enc(cleaned)}&artist_name=${enc(primary)}")
            urls.add("https://lrclib.net/api/search?q=${enc("$cleaned $primary")}")
            urls.add("https://lrclib.net/api/search?q=${enc("$title $artist")}")
            best = searchAll(urls)
        }

        // 3) retry with Genius's spelling (it often titles songs differently from Spotify)
        if (best == null) {
            val g = genius
            if (g != null) {
                val gu = ArrayList<String>()
                gu.add("https://lrclib.net/api/search?track_name=${enc(g.title)}&artist_name=${enc(g.artist)}")
                gu.add("https://lrclib.net/api/search?q=${enc("${g.title} ${g.artist}")}")
                best = searchAll(gu)
            }
        }

        // 4) title only; safe because the track length must match
        if (best == null && durationSec != null) {
            best = searchAll(listOf("https://lrclib.net/api/search?q=${enc(cleaned)}"))
        }

        // 5) second source: lyrics.ovh (plain text only, no timing)
        if (best == null) {
            second@ for (t in titles) for (a in artists) {
                val http = get("https://api.lyrics.ovh/v1/${seg(a)}/${seg(t)}")
                if (http == null) { networkFailed = true; continue }
                val body = http.body
                val txt = if (body == null) "" else try {
                    JSONObject(body).optString("lyrics", "")
                } catch (e: Exception) { "" }
                if (txt.isNotBlank()) {
                    best = Candidate(null, txt.trim(), null, false)
                    break@second
                }
            }
        }

        val synced = best?.synced?.let { LrcParser.parse(it) } ?: emptyList()
        val plain = best?.plain?.takeIf { it.isNotBlank() }
        val result = LyricsResult(
            plain = plain,
            synced = synced,
            instrumental = best?.instrumental == true,
            geniusUrl = genius?.url,
            error = if (best == null && networkFailed) "Couldn't reach the lyrics service.\nCheck your connection." else null
        )
        // Only remember definite answers, so a temporary network failure is retried next time.
        if (result.error == null) synchronized(cache) { cache[key] = result }
        return result
    }

    private fun lrclibGetUrl(title: String, artist: String, album: String, durationSec: Double?): String {
        val sb = StringBuilder("https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}")
        if (album.isNotBlank()) sb.append("&album_name=").append(enc(album))
        if (durationSec != null && durationSec in 1.0..3600.0) sb.append("&duration=").append(durationSec.toInt())
        return sb.toString()
    }

    private fun toCandidate(o: JSONObject) = Candidate(
        durationSec = if (o.has("duration") && !o.isNull("duration")) o.optDouble("duration") else null,
        plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        instrumental = o.optBoolean("instrumental", false)
    )

    private fun geniusMatch(title: String, artist: String): GeniusHit? {
        val token = geniusToken().trim()
        if (token.isEmpty()) return null
        val http = get(
            "https://api.genius.com/search?q=${enc("$title $artist")}",
            mapOf("Authorization" to "Bearer $token")
        ) ?: return null
        return try {
            val hits = JSONObject(http.body ?: return null).getJSONObject("response").getJSONArray("hits")
            if (hits.length() == 0) return null
            val r = hits.getJSONObject(0).getJSONObject("result")
            GeniusHit(
                url = r.getString("url"),
                title = r.optString("title", title),
                artist = r.optJSONObject("primary_artist")?.optString("name", artist) ?: artist
            )
        } catch (e: Exception) { null }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** URL-encode one path segment (spaces must be %20 in a path, not +). */
    private fun seg(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /** Returns null only on an I/O failure (no network, timeout). HTTP errors return a code. */
    private fun get(url: String, headers: Map<String, String> = emptyMap()): Http? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                // LRCLIB asks apps to identify themselves.
                setRequestProperty("User-Agent", "LyricsPopup/1.2 (Android)")
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
            }
            val code = conn.responseCode
            val body = if (code in 200..299) conn.inputStream.bufferedReader().readText() else null
            Http(code, body)
        } catch (e: IOException) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
