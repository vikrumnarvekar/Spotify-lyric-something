package com.example.lyricspopup

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class LyricsResult(
    val plain: String?,              // un-timed lyrics, if any
    val synced: List<LrcLine>,       // timed lines (empty if the song has no synced lyrics)
    val instrumental: Boolean,
    val geniusUrl: String?,          // link to the song on Genius, if matched
    val artUrl: String? = null,      // Genius cover image, used if Spotify gives none
    val error: String? = null        // set when the lookup failed (e.g. no network)
) {
    val hasLyrics get() = synced.isNotEmpty() || !plain.isNullOrBlank()
}

/**
 * Lyrics come from LRCLIB (https://lrclib.net, timed lyrics when available), then lyrics.ovh, then
 * the text of the Genius song page as a last resort. Genius search also supplies the song's
 * cover image and page link. For personal use only.
 *
 * Call [fetch] from a background thread.
 */
class LyricsRepository(private val geniusToken: () -> String) {

    private class Http(val code: Int, val body: String?)
    private class GeniusHit(val url: String, val title: String, val artist: String, val art: String?)

    private val cache = object : LinkedHashMap<String, LyricsResult>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, LyricsResult>?) = size > 40
    }

    fun fetch(title: String, artist: String, album: String, durationMs: Long): LyricsResult {
        val key = "$title|$artist|$durationMs"
        synchronized(cache) { cache[key] }?.let { return it }

        val durationSec = if (durationMs > 0) durationMs / 1000.0 else null
        var networkFailed = false

        val cleaned = TrackText.cleanTitle(title)
        val primary = TrackText.primaryArtist(artist)
        // Looked up only if needed (no token -> null, no network call).
        val genius by lazy { geniusMatch(cleaned, primary) }

        fun candidate(http: Http?): Candidate? {
            if (http == null) { networkFailed = true; return null }
            val body = http.body ?: return null
            return try { toCandidate(JSONObject(body)) } catch (e: Exception) { null }
        }

        fun searchAll(urls: List<String>): Candidate? {
            for (u in urls) {
                val http = get(u)
                if (http == null) { networkFailed = true; continue }
                val arr = try { JSONArray(http.body ?: "[]") } catch (e: Exception) { JSONArray() }
                val list = (0 until arr.length()).mapNotNull {
                    try { toCandidate(arr.getJSONObject(it)) } catch (e: Exception) { null }
                }
                val found = TrackText.pick(list, durationSec)
                if (found != null) return found
            }
            return null
        }

        // 1) exact lookups, most specific first
        var best: Candidate? = null
        val titles = listOf(title, cleaned).distinct()
        val artists = listOf(artist, primary).distinct()
        outer@ for (t in titles) for (a in artists) {
            val c = candidate(get(lrclibGetUrl(t, a, album, durationSec)))
            if (c != null && (c.instrumental || !c.plain.isNullOrBlank() || !c.synced.isNullOrBlank())) {
                best = c
                break@outer
            }
        }

        // 2) fuzzy searches; pick() only accepts a record whose length matches the track
        if (best == null) {
            val urls = ArrayList<String>()
            urls.add("https://lrclib.net/api/search?track_name=${enc(cleaned)}&artist_name=${enc(primary)}")
            urls.add("https://lrclib.net/api/search?q=${enc("$cleaned $primary")}")
            urls.add("https://lrclib.net/api/search?q=${enc("$title $artist")}")
            best = searchAll(urls)
        }

        // 3) retry with Genius's spelling (it often titles songs differently from Spotify)
        if (best == null) {
            val g = genius
            if (g != null) {
                val gu = ArrayList<String>()
                gu.add("https://lrclib.net/api/search?track_name=${enc(g.title)}&artist_name=${enc(g.artist)}")
                gu.add("https://lrclib.net/api/search?q=${enc("${g.title} ${g.artist}")}")
                best = searchAll(gu)
            }
        }

        // 4) title only; safe because the track length must match
        if (best == null && durationSec != null) {
            best = searchAll(listOf("https://lrclib.net/api/search?q=${enc(cleaned)}"))
        }

        // 5) second source: lyrics.ovh (plain text only, no timing)
        if (best == null) {
            second@ for (t in titles) for (a in artists) {
                val http = get("https://api.lyrics.ovh/v1/${seg(a)}/${seg(t)}")
                if (http == null) { networkFailed = true; continue }
                val body = http.body
                val txt = if (body == null) "" else try {
                    JSONObject(body).optString("lyrics", "")
                } catch (e: Exception) { "" }
                if (txt.isNotBlank()) {
                    best = Candidate(null, txt.trim(), null, false)
                    break@second
                }
            }
        }

        // 6) last resort: scrape the Genius page directly for the lyrics text
        if (best == null) {
            val geniusPageUrl = genius?.url
            if (geniusPageUrl != null) {
                val scraped = scrapeGeniusPage(geniusPageUrl)
                if (scraped != null) best = Candidate(null, scraped, null, false)
            }
        }

        val synced = best?.synced?.let { LrcParser.parse(it) } ?: emptyList()
        val plain = best?.plain?.takeIf { it.isNotBlank() }
        val result = LyricsResult(
            plain = plain,
            synced = synced,
            instrumental = best?.instrumental == true,
            geniusUrl = genius?.url,
            artUrl = genius?.art,
            error = if (best == null && networkFailed) "Couldn't reach the lyrics service.\nCheck your connection." else null
        )
        // Only remember definite answers, so a temporary network failure is retried next time.
        if (result.error == null) synchronized(cache) { cache[key] = result }
        return result
    }

    private fun lrclibGetUrl(title: String, artist: String, album: String, durationSec: Double?): String {
        val sb = StringBuilder("https://lrclib.net/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}")
        if (album.isNotBlank()) sb.append("&album_name=").append(enc(album))
        if (durationSec != null && durationSec in 1.0..3600.0) sb.append("&duration=").append(durationSec.toInt())
        return sb.toString()
    }

    private fun toCandidate(o: JSONObject) = Candidate(
        durationSec = if (o.has("duration") && !o.isNull("duration")) o.optDouble("duration") else null,
        plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        instrumental = o.optBoolean("instrumental", false)
    )

    private fun geniusMatch(title: String, artist: String): GeniusHit? {
        val token = geniusToken().trim()
        val http = (if (token.isEmpty())
            get("https://genius.com/api/search/song?q=${enc("$title $artist")}")
        else get(
            "https://api.genius.com/search?q=${enc("$title $artist")}",
            mapOf("Authorization" to "Bearer $token")
        )) ?: return null
        return try {
            val resp = JSONObject(http.body ?: return null).getJSONObject("response")
            val hits = if (token.isEmpty()) resp.getJSONArray("sections").getJSONObject(0).getJSONArray("hits")
                       else resp.getJSONArray("hits")
            if (hits.length() == 0) return null
            val r = hits.getJSONObject(0).getJSONObject("result")
            GeniusHit(
                url = r.getString("url"),
                title = r.optString("title", title),
                artist = r.optJSONObject("primary_artist")?.optString("name", artist) ?: artist,
                art = r.optString("song_art_image_thumbnail_url", "").takeIf { it.startsWith("http") }
            )
        } catch (e: Exception) { null }
    }

    /**
     * Fetches the Genius song page and extracts lyrics from data-lyrics-container divs.
     * Returns null if the page could not be fetched or no lyrics container was found.
     */
    /** Removes nested <div data-exclude-from-selection> blocks (Genius puts blurbs inside the lyrics). */
    private fun stripExcluded(input: String): String {
        var s = input
        while (true) {
            val at = s.indexOf("data-exclude-from-selection=\"true\"")
            if (at == -1) return s
            val start = s.lastIndexOf("<div", at)
            if (start == -1) return s
            var depth = 0
            var pos = start
            var end = -1
            while (pos < s.length) {
                val o = s.indexOf("<div", pos)
                val c = s.indexOf("</div>", pos)
                if (c == -1) break
                if (o != -1 && o < c) { depth++; pos = o + 4 }
                else { depth--; pos = c + 6; if (depth == 0) { end = pos; break } }
            }
            if (end == -1) return s.substring(0, start)
            s = s.substring(0, start) + s.substring(end)
        }
    }

    private fun scrapeGeniusPage(url: String): String? {
        val http = get(url) ?: return null
        val html = http.body ?: return null
        val sb = StringBuilder()
        var searchFrom = 0
        while (true) {
            val attrIdx = html.indexOf("data-lyrics-container=\"true\"", searchFrom)
            if (attrIdx == -1) break
            val openTagEnd = html.indexOf('>', attrIdx)
            if (openTagEnd == -1) break
            var depth = 1
            var pos = openTagEnd + 1
            var contentEnd = -1
            while (pos < html.length && depth > 0) {
                val nextOpenDiv = html.indexOf("<div", pos)
                val nextCloseDiv = html.indexOf("</div>", pos)
                if (nextCloseDiv == -1) break
                if (nextOpenDiv != -1 && nextOpenDiv < nextCloseDiv) {
                    depth++
                    pos = nextOpenDiv + 4
                } else {
                    depth--
                    if (depth == 0) contentEnd = nextCloseDiv
                    pos = nextCloseDiv + 6
                }
            }
            if (contentEnd != -1) {
                sb.append(stripExcluded(html.substring(openTagEnd + 1, contentEnd))).append("\n")
            }
            searchFrom = if (contentEnd != -1) contentEnd + 6 else openTagEnd + 1
        }
        if (sb.isEmpty()) return null
        return sb.toString()
            .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&#x27;", "'")
            .replace("&apos;", "'")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
            .takeIf { it.isNotEmpty() }
    }

    /** Downloads a small image; null on any failure. */
    fun fetchBitmap(url: String): android.graphics.Bitmap? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "LyricsPopup/1.2 (Android)")
        c.inputStream.use { android.graphics.BitmapFactory.decodeStream(it) }
    } catch (e: Exception) { null }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** URL-encode one path segment (spaces must be %20 in a path, not +). */
    private fun seg(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /** Returns null only on an I/O failure (no network, timeout). HTTP errors return a code. */
    private fun get(url: String, headers: Map<String, String> = emptyMap()): Http? {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                // LRCLIB asks apps to identify themselves.
                setRequestProperty("User-Agent", "LyricsPopup/1.2 (Android)")
                headers.forEach { (k, v) -> setRequestProperty(k, v) }
            }
            val code = conn.responseCode
            val body = if (code in 200..299) conn.inputStream.bufferedReader().readText() else null
            Http(code, body)
        } catch (e: IOException) {
            null
        } finally {
            conn?.disconnect()
        }
    }
}
