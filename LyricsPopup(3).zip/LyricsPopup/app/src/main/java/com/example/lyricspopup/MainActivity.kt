package com.example.lyricspopup

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var tokenInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        col.addView(TextView(this).apply {
            text = "Lyrics Popup"
            textSize = 26f
            setTextColor(Color.BLACK)
        })
        col.addView(TextView(this).apply {
            text = "Floating lyrics for whatever is playing in Spotify.\n\nSetup (do once):"
            textSize = 15f
            setPadding(0, pad / 2, 0, pad / 2)
        })

        col.addView(btn("1. Allow display over other apps") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        })
        col.addView(btn("2. Grant notification access") {
            // Lets the app read Spotify's now-playing info. It does not read your notifications.
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        })

        tokenInput = EditText(this).apply {
            hint = "Genius client access token (optional)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
                .getString(OverlayService.KEY_TOKEN, ""))
        }
        col.addView(tokenInput)
        col.addView(TextView(this).apply {
            text = "Get a free token at genius.com/api-clients. It's used to find the song on Genius " +
                "for the \"G\" button in the popup."
            textSize = 12f
        })

        col.addView(btn("3. Start lyrics popup") { start() })
        col.addView(btn("Stop") { stopService(Intent(this, OverlayService::class.java)) })

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.START
            setPadding(0, pad, 0, 0)
        }
        col.addView(status)

        setContentView(ScrollView(this).apply { addView(col) })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val listener = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true
        status.text = "Overlay permission: ${if (overlay) "✓" else "✗"}\n" +
            "Notification access: ${if (listener) "✓" else "✗"}"
    }

    private fun start() {
        getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE).edit()
            .putString(OverlayService.KEY_TOKEN, tokenInput.text.toString().trim()).apply()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant the overlay permission first", Toast.LENGTH_LONG).show()
            return
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        moveTaskToBack(true)   // go back to Spotify
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }
}
