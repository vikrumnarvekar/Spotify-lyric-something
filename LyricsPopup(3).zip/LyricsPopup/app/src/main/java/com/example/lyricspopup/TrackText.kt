package com.example.lyricspopup

import kotlin.math.abs

/** A lyrics record returned by the lyrics service. Pure data so matching can be tested on a JVM. */
data class Candidate(
    val durationSec: Double?,
    val plain: String?,
    val synced: String?,
    val instrumental: Boolean
)

/** Text clean-up and matching helpers. No Android classes. */
object TrackText {

    private val TRAILING_BRACKETS = Regex("""\s*[(\[][^)\]]*[)\]]\s*$""")
    private val TRAILING_DASH_SUFFIX = Regex("""\s+-\s+[^-]*$""")

    /**
     * "Song (feat. X) - Remastered 2011" -> "Song".
     * Only trailing decorations are removed, so "(Don't Fear) The Reaper" stays intact.
     */
    fun cleanTitle(title: String): String {
        var t = title.trim()
        // Alternate between the two patterns until nothing changes, so mixed endings like
        // "Song (Live) - 2019 Remaster" are fully cleaned.
        while (true) {
            val next = t.replace(TRAILING_BRACKETS, "").replace(TRAILING_DASH_SUFFIX, "").trim()
            if (next == t) break
            t = next
        }
        return t.ifEmpty { title.trim() }
    }

    /** Spotify joins multiple artists with ", " or ";". Used only as a fallback lookup. */
    fun primaryArtist(artist: String): String =
        artist.split(",", ";").first().trim().ifEmpty { artist.trim() }

    fun isAd(title: String, artist: String): Boolean =
        title.trim().equals("Advertisement", ignoreCase = true) ||
            (artist.isBlank() && title.trim().equals("Spotify", ignoreCase = true))

    /**
     * Choose the best record for a track of [durationSec] seconds.
     * 1) right length + synced lyrics, 2) right length, 3) closest within 15 s but with timing
     * dropped (timestamps from a different cut would be wrong).
     */
    fun pick(candidates: List<Candidate>, durationSec: Double?): Candidate? {
        val usable = candidates.filter {
            it.instrumental || !it.plain.isNullOrBlank() || !it.synced.isNullOrBlank()
        }
        if (usable.isEmpty()) return null

        fun close(c: Candidate): Boolean =
            durationSec == null || c.durationSec == null || abs(c.durationSec - durationSec) <= 3.0

        usable.firstOrNull { close(it) && !it.synced.isNullOrBlank() }?.let { return it }
        usable.firstOrNull { close(it) }?.let { return it }

        val nearest = usable
            .filter { it.durationSec != null }
            .minByOrNull { abs(it.durationSec!! - durationSec!!) }
        return if (nearest != null && abs(nearest.durationSec!! - durationSec!!) <= 15.0) {
            nearest.copy(synced = null)
        } else null
    }
}
