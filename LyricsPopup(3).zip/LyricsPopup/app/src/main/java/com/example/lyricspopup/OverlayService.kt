package com.example.lyricspopup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.widget.ImageView
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val SPOTIFY = "com.spotify.music"
        const val PREFS = "prefs"
        const val KEY_TOKEN = "genius_token"
        private const val CHANNEL_ID = "lyrics_overlay"
        private const val NOTIF_ID = 42
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerComponent: ComponentName

    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var coverView: ImageView
    private lateinit var lyricsView: TextView
    private lateinit var scroll: ScrollView

    private var controller: MediaController? = null
    private var lastTrackKey: String? = null
    private var currentGeniusUrl: String? = null
    private var currentTitle = ""
    private var currentArtist = ""

    private val repo = LyricsRepository {
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TOKEN, "") ?: ""
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            handleMetadata(metadata)
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener {
        attachToSpotify(it)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerComponent = ComponentName(this, MediaListenerService::class.java)
        startAsForeground()
        buildPanel()
        buildBubble()
        showPanel()
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, main)
            attachToSpotify(msm.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            setLyrics("Notification access is not granted.\nOpen the app and tap \"Grant notification access\".")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(controllerCallback)
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- Spotify now-playing ----------

    private fun attachToSpotify(controllers: List<MediaController>?) {
        val spotify = controllers?.firstOrNull { it.packageName == SPOTIFY }
        if (spotify?.sessionToken == controller?.sessionToken && controller != null) return
        controller?.unregisterCallback(controllerCallback)
        controller = spotify
        if (spotify == null) {
            titleView.text = "Waiting for Spotify…"
            artistView.text = ""
            setLyrics("Start playing a song in Spotify.")
            lastTrackKey = null
            return
        }
        spotify.registerCallback(controllerCallback, main)
        handleMetadata(spotify.metadata)
    }

    private fun handleMetadata(md: MediaMetadata?) {
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val key = "$title|$artist"
        if (key == lastTrackKey) return
        lastTrackKey = key
        currentTitle = title
        currentArtist = artist

        titleView.text = title
        artistView.text = artist
        val spotifyArt: Bitmap? = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        if (spotifyArt != null) coverView.setImageBitmap(spotifyArt) else coverView.setImageDrawable(null)
        currentGeniusUrl = null
        setLyrics("Loading lyrics…")
        scroll.scrollTo(0, 0)

        if (TrackText.isAd(title, artist)) {
            setLyrics("Advertisement playing…")
            return
        }
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

        Thread {
            val result = repo.fetch(title, artist, album, durationMs)
            main.post {
                if (key != lastTrackKey) return@post   // song changed while loading
                currentGeniusUrl = result.geniusUrl
                if (spotifyArt == null && result.artUrl != null) {
                    Thread {
                        val bmp = repo.fetchBitmap(result.artUrl)
                        main.post { if (key == lastTrackKey && bmp != null) coverView.setImageBitmap(bmp) }
                    }.start()
                }
                if (!result.hasLyrics && !result.instrumental && result.error == null) {
                    showNotFound(title, artist)
                    scroll.scrollTo(0, 0)
                    return@post
                }
                val text = when {
                    result.error != null -> result.error
                    result.instrumental -> "♪ Instrumental ♪"
                    result.synced.isNotEmpty() ->
                        result.synced.joinToString("\n") { it.text.ifBlank { "♪" } }
                    !result.plain.isNullOrBlank() -> result.plain
                    else -> "No lyrics found for this track.\nTap G to open it on Genius in your browser."
                }
                setLyrics(text)
                scroll.scrollTo(0, 0)
            }
        }.start()
    }

    private fun setLyrics(text: String) {
        lyricsView.movementMethod = null
        lyricsView.text = text
    }

    /** No lyrics in any source we can read: show tappable links to where they can be found. */
    private fun showNotFound(title: String, artist: String) {
        val q = Uri.encode("$title $artist")
        val links = listOf(
            "Genius" to (currentGeniusUrl ?: "https://genius.com/search?q=$q"),
            "Google" to ("https://www.google.com/search?q=" + Uri.encode("$title $artist lyrics")),
            "Musixmatch" to "https://www.musixmatch.com/search/$q",
            "YouTube" to ("https://www.youtube.com/results?search_query=" + Uri.encode("$title $artist lyrics"))
        )
        val sb = android.text.SpannableStringBuilder(
            "These lyrics aren't in the sources this app can read.\nTap a site to find them:\n"
        )
        for ((name, url) in links) {
            sb.append("\n")
            val start = sb.length
            sb.append("▶  $name")
            sb.setSpan(object : android.text.style.ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }, start, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        lyricsView.setLinkTextColor(Color.parseColor("#1ED760"))
        lyricsView.movementMethod = android.text.method.LinkMovementMethod.getInstance()
        lyricsView.text = sb
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#F0242424"), Color.parseColor("#F0101010"))
        ).apply {
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.parseColor("#33FFFFFF"))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(16), dp(8), dp(12), dp(8))
        }

        val pill = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#55FFFFFF")); cornerRadius = dp(2).toFloat()
            }
        }
        val pillRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(pill, LinearLayout.LayoutParams(dp(36), dp(4)))
            setPadding(0, 0, 0, dp(6))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            text = "Waiting for Spotify…"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        artistView = TextView(this).apply {
            setTextColor(Color.parseColor("#1ED760"))
            textSize = 12.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView)
            addView(artistView)
        }
        coverView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#33FFFFFF")); cornerRadius = dp(8).toFloat()
            }
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(8).toFloat())
                }
            }
        }
        header.addView(coverView, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(headerButton("G") {
            // Exact Genius page if we matched one, otherwise a Genius search for the current song.
            val url = currentGeniusUrl
                ?: ("https://genius.com/search?q=" + Uri.encode("$currentTitle $currentArtist"))
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        header.addView(headerButton("–") { showBubble() })
        header.addView(headerButton("✕") { stopSelf() })

        val divider = View(this).apply { setBackgroundColor(Color.parseColor("#22FFFFFF")) }

        lyricsView = TextView(this).apply {
            setTextColor(Color.parseColor("#F2FFFFFF"))
            textSize = 19f
            gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.25f)
            setPadding(dp(4), dp(14), dp(4), dp(20))
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(lyricsView)
        }

        // Double-tap anywhere on the lyrics shrinks the window to the bubble.
        val doubleTap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                showBubble()
                return true
            }
        })
        scroll.setOnTouchListener { _, e ->
            doubleTap.onTouchEvent(e)
            false   // let the ScrollView keep scrolling normally
        }

        // Resize handle (bottom-right corner): drag to make the window bigger or smaller.
        val grip = TextView(this).apply {
            text = "◢"
            textSize = 18f
            setTextColor(Color.parseColor("#99FFFFFF"))
            gravity = Gravity.CENTER
            minWidth = dp(52)
            minHeight = dp(34)
        }
        var gripW = 0
        var gripH = 0
        var gripX = 0f
        var gripY = 0f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    gripW = panelParams.width
                    gripH = panelParams.height
                    gripX = e.rawX
                    gripY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    val sw = resources.displayMetrics.widthPixels
                    val sh = resources.displayMetrics.heightPixels
                    panelParams.width = (gripW + (e.rawX - gripX)).toInt().coerceIn(dp(200), sw)
                    panelParams.height = (gripH + (e.rawY - gripY)).toInt().coerceIn(dp(130), sh)
                    if (root.isAttachedToWindow) wm.updateViewLayout(root, panelParams)
                }
            }
            true
        }
        val footer = LinearLayout(this).apply {
            gravity = Gravity.END
            addView(grip)
        }

        root.addView(pillRow)
        root.addView(header)
        root.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(footer, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        panelParams = WindowManager.LayoutParams(
            (dm.widthPixels * 0.88f).toInt(),
            (dm.heightPixels * 0.5f).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels * 0.06f).toInt()
            y = dp(120)
        }

        makeDraggable(titleBox, panelParams, onDouble = { showBubble() }) { root }
        makeDraggable(pillRow, panelParams, onDouble = { showBubble() }) { root }
        panel = root
    }

    private fun headerButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 17f
        setTextColor(Color.parseColor("#CCFFFFFF"))
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(6), dp(12), dp(6))
        setOnClickListener { onClick() }
    }

    private fun buildBubble() {
        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#1ED760"))
        }
        val b = TextView(this).apply {
            text = "♪"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = circle
            elevation = dp(6).toFloat()
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(200)
        }
        makeDraggable(b, bubbleParams, onTap = { showPanel() }) { b }
        bubble = b
    }

    private fun showPanel() {
        bubble?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        panel?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, panelParams) }
    }

    private fun showBubble() {
        panel?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        bubble?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, bubbleParams) }
    }

    /** Drags the window by touching [handle]; a tiny movement counts as a tap. */
    private fun makeDraggable(
        handle: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        onDouble: (() -> Unit)? = null,
        windowView: () -> View
    ) {
        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        val detector = if (onDouble == null) null else GestureDetector(
            this, object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    onDouble()
                    return true
                }
            })
        handle.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    val w = windowView()
                    if (w.isAttachedToWindow) wm.updateViewLayout(w, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() ?: v.performClick()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Lyrics overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lyrics Popup is running")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
