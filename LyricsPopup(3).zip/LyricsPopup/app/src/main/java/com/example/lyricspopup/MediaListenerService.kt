package com.example.lyricspopup

import android.service.notification.NotificationListenerService

/**
 * Intentionally empty. Granting "Notification access" to this service is what allows
 * MediaSessionManager.getActiveSessions() to return Spotify's playback session.
 * We never read notification contents.
 */
class MediaListenerService : NotificationListenerService()
