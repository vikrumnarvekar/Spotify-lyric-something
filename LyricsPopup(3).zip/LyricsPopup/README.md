# Lyrics Popup (Android)

A floating, draggable lyrics window that follows whatever is playing in Spotify.
Tap **–** to shrink it to a ♪ bubble; tap the bubble to bring it back. **G** opens the song on Genius, **✕** closes it.

## Build the APK
1. Install Android Studio and open this folder (`LyricsPopup`). Let Gradle sync.
2. Plug in your phone (USB debugging on) and press Run, or
   **Build > Build APK(s)**, then copy `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it (allow "install unknown apps").

## First run
1. Open the app, tap **Allow display over other apps** and switch it on.
2. Tap **Grant notification access** and enable Lyrics Popup. (This is how Android lets an app see Spotify's now-playing info. The app never reads your notifications.)
3. Optional: paste a Genius client access token (genius.com/api-clients) for the "G" button.
4. Tap **Start lyrics popup**, then play a song in Spotify.

## How it works
- `MediaListenerService` – empty listener; its permission unlocks media-session access.
- `OverlayService` – foreground service; watches Spotify's media session for track changes and draws the overlay.
- `LyricsRepository` – looks up lyrics text on LRCLIB and the song page on Genius.

## About Genius
Genius's official API returns song metadata and a page URL, not lyrics, and scraping lyrics off genius.com
breaks their terms of service. So lyrics text is pulled from LRCLIB (free, open API), and Genius is used
for matching and the link. To use another source (e.g. Musixmatch), change `LyricsRepository.fetch()`.

## Notes
- Works with the official Spotify app (`com.spotify.music`).
- Some Android skins (Xiaomi, Oppo, Vivo, Samsung) kill background services: set the app's battery usage to "Unrestricted".
- Instrumental tracks and very new releases may show "No lyrics found".

## Get an APK without Android Studio
Push this folder to a new GitHub repo, open the **Actions** tab, run **Build APK**, then download
`LyricsPopup-debug-apk` from the finished run and install the APK on your phone.
