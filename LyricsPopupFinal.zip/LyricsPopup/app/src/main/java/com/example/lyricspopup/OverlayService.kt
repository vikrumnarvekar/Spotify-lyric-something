package com.example.lyricspopup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val SPOTIFY = "com.spotify.music"
        const val PREFS = "prefs"
        const val KEY_TOKEN = "genius_token"
        private const val KEY_OPACITY = "opacity_idx"
        private const val CHANNEL_ID = "lyrics_overlay"
        private const val NOTIF_ID = 42

        /** Background opacity steps, cycled by the ◐ button (higher = more solid). */
        private val ALPHAS = intArrayOf(0x26, 0x4D, 0x80, 0xCC)

        @Volatile var running = false

        private const val MIN_SCALE = 0.6f
        private const val MAX_SCALE = 2.2f

        private const val TICK_MS = 250L
        private const val LOOKAHEAD_MS = 250L          // highlight a line a hair early
        private const val USER_SCROLL_HOLD_MS = 6000L  // leave the scroll alone after you touch it

        private val GREEN = Color.parseColor("#1ED760")
        private val BRIGHT = Color.argb(245, 255, 255, 255)
        private val DIM = Color.argb(120, 255, 255, 255)
        private val SOFT = Color.argb(185, 255, 255, 255)
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerComponent: ComponentName

    private var panel: FrameLayout? = null
    private lateinit var panelRoot: LinearLayout
    private var bubble: TextView? = null
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelBg: GradientDrawable

    private lateinit var coverView: ImageView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var lyricsView: TextView
    private lateinit var scroll: ScrollView
    private lateinit var seek: SeekBar
    private lateinit var timeNow: TextView
    private lateinit var timeTotal: TextView
    private lateinit var playBtn: IconView
    private lateinit var prevBtn: IconView
    private lateinit var nextBtn: IconView
    private lateinit var collapseBtn: IconView
    private lateinit var seekRow: LinearLayout
    private lateinit var modeChip: TextView
    private lateinit var grip: TextView

    // size: window size (panelParams) and a zoom factor are independent
    private var uiScale = 1f
    private var scaleMode = false          // false: grip resizes the window only; true: grip zooms everything
    private var controlsCollapsed = false

    private var controller: MediaController? = null
    private var playbackState: PlaybackState? = null
    private var lastTrackKey: String? = null
    private var currentGeniusUrl: String? = null
    private var currentTitle = ""
    private var currentArtist = ""
    private var durationMs = 0L

    private var coverSet = false
    private var lastArtCheck = 0L
    private var opacityIdx = 1

    // lyrics following
    private var synced: List<LrcLine> = emptyList()
    private var lineStarts = IntArray(0)
    private var lineEnds = IntArray(0)
    private var plainMode = false
    private var highlightIdx = -2
    private var highlightSpan: ForegroundColorSpan? = null
    private var layoutReady = false
    private var recenter = true
    private var lastUserScroll = -USER_SCROLL_HOLD_MS

    // seek bar
    private var seeking = false
    private var pendingSeekPos = 0L
    private var pendingSeekAt = -10_000L

    private val repo = LyricsRepository {
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TOKEN, "") ?: ""
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            handleMetadata(metadata)
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            playbackState = state
            updatePlayIcon()
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener {
        attachToSpotify(it)
    }

    private val ticker = object : Runnable {
        override fun run() {
            try { tick() } catch (t: Throwable) { CrashLog.record(this@OverlayService, t) }
            main.postDelayed(this, TICK_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerComponent = ComponentName(this, MediaListenerService::class.java)
        startAsForeground()
        running = true
        try {
            opacityIdx = getSharedPreferences(PREFS, MODE_PRIVATE)
                .getInt(KEY_OPACITY, 1).coerceIn(0, ALPHAS.size - 1)
            buildPanel()
            buildBubble()
            applyOpacity()
            showPanel()
            try {
                msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, main)
                attachToSpotify(msm.getActiveSessions(listenerComponent))
            } catch (e: SecurityException) {
                setStatus("Notification access is not granted.\nOpen the app and tap \"Grant notification access\".")
            }
        } catch (t: Throwable) {
            CrashLog.record(this, t)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        running = false
        saveLayoutPrefs()
        main.removeCallbacks(ticker)
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(controllerCallback)
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- Spotify now-playing ----------

    private fun attachToSpotify(controllers: List<MediaController>?) {
        val spotify = controllers?.firstOrNull { it.packageName == SPOTIFY }
        if (spotify?.sessionToken == controller?.sessionToken && controller != null) return
        controller?.unregisterCallback(controllerCallback)
        controller = spotify
        if (spotify == null) {
            playbackState = null
            titleView.text = "Waiting for Spotify…"
            artistView.text = ""
            clearCover()
            durationMs = 0
            setStatus("Start playing a song in Spotify.")
            lastTrackKey = null
            return
        }
        spotify.registerCallback(controllerCallback, main)
        playbackState = spotify.playbackState
        handleMetadata(spotify.metadata)
    }

    private fun artFrom(md: MediaMetadata): Bitmap? =
        md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    private fun artUriFrom(md: MediaMetadata): String? =
        listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        ).mapNotNull { md.getString(it) }.firstOrNull { it.startsWith("http") }

    private fun showCover(b: Bitmap) {
        coverView.setImageBitmap(b)
        coverSet = true
    }

    private fun clearCover() {
        coverView.setImageDrawable(null)
        coverSet = false
    }

    private fun handleMetadata(md: MediaMetadata?) {
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val art = artFrom(md)
        val key = "$title|$artist"

        if (key == lastTrackKey) {
            // Same song, refreshed info. Spotify often delivers the cover (and length) a moment late.
            if (dur > 0) durationMs = dur
            if (art != null) showCover(art)
            return
        }
        lastTrackKey = key
        currentTitle = title
        currentArtist = artist
        durationMs = if (dur > 0) dur else 0
        pendingSeekAt = -10_000L

        titleView.text = title
        artistView.text = artist
        currentGeniusUrl = null
        clearCover()
        if (art != null) showCover(art)
        setStatus("Loading lyrics…")
        scroll.scrollTo(0, 0)

        if (TrackText.isAd(title, artist)) {
            setStatus("Advertisement playing…")
            return
        }
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val artUri = artUriFrom(md)

        Thread {
            val result = repo.fetch(title, artist, album, if (dur > 0) dur else durationMs)
            main.post {
                if (key != lastTrackKey) return@post   // song changed while loading
                currentGeniusUrl = result.geniusUrl

                // Genius link and cover fallback are looked up separately so they never delay the lyrics.
                if (result.geniusUrl == null || !coverSet) Thread {
                    val g = repo.geniusInfo(title, artist)
                    val url = artUri ?: g?.art ?: result.artUrl
                    val bmp = if (url != null && !coverSet) repo.fetchBitmap(url) else null
                    main.post {
                        if (key != lastTrackKey) return@post
                        if (g != null) currentGeniusUrl = g.url
                        if (bmp != null && !coverSet) showCover(bmp)
                    }
                }.start()

                val plain = result.plain
                val err = result.error
                when {
                    !result.hasLyrics && !result.instrumental && err == null -> showNotFound(title, artist)
                    err != null -> setStatus(err)
                    result.instrumental -> setStatus("♪ Instrumental ♪")
                    result.synced.isNotEmpty() -> showSynced(result.synced)
                    !plain.isNullOrBlank() -> showPlain(plain)
                    else -> setStatus("No lyrics found for this track.")
                }
                scroll.scrollTo(0, 0)
            }
        }.start()
    }

    // ---------- lyrics display ----------

    private fun resetFollow() {
        synced = emptyList()
        lineStarts = IntArray(0)
        lineEnds = IntArray(0)
        plainMode = false
        highlightIdx = -2
        highlightSpan = null
        layoutReady = false
        recenter = true
    }

    /** A short message (loading, errors, instrumental…). */
    private fun setStatus(text: String) {
        resetFollow()
        lyricsView.movementMethod = null
        lyricsView.setTextColor(BRIGHT)
        lyricsView.setText(text, TextView.BufferType.SPANNABLE)
    }

    private fun showPlain(text: String) {
        resetFollow()
        plainMode = true
        lyricsView.movementMethod = null
        lyricsView.setTextColor(BRIGHT)
        lyricsView.setText(text, TextView.BufferType.SPANNABLE)
    }

    /** Timed lyrics: every line dim, the line being sung bright, scrolled to the middle. */
    private fun showSynced(lines: List<LrcLine>) {
        resetFollow()
        val b = LyricsFollow.build(lines)
        synced = lines
        lineStarts = b.starts
        lineEnds = b.ends
        lyricsView.movementMethod = null
        lyricsView.setTextColor(DIM)
        lyricsView.setText(b.text, TextView.BufferType.SPANNABLE)
    }

    private fun setHighlight(idx: Int) {
        val sp = lyricsView.text as? Spannable ?: return
        highlightSpan?.let { sp.removeSpan(it) }
        highlightSpan = null
        if (idx in synced.indices) {
            val span = ForegroundColorSpan(BRIGHT)
            sp.setSpan(span, lineStarts[idx], lineEnds[idx], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            highlightSpan = span
        }
        highlightIdx = idx
    }

    private fun scrollToLine(idx: Int) {
        if (idx < 0) { scroll.smoothScrollTo(0, 0); return }
        val l = lyricsView.layout ?: return
        val first = l.getLineForOffset(lineStarts[idx])
        val last = l.getLineForOffset((lineEnds[idx] - 1).coerceAtLeast(lineStarts[idx]))
        val mid = (l.getLineTop(first) + l.getLineBottom(last)) / 2 + lyricsView.paddingTop
        scroll.smoothScrollTo(0, (mid - scroll.height / 2).coerceAtLeast(0))
    }

    /** No lyrics in any source we can read: show tappable links to where they can be found. */
    private fun showNotFound(title: String, artist: String) {
        resetFollow()
        val q = Uri.encode("$title $artist")
        val links = listOf(
            "Genius" to (currentGeniusUrl ?: "https://genius.com/search?q=$q"),
            "Google" to ("https://www.google.com/search?q=" + Uri.encode("$title $artist lyrics")),
            "Musixmatch" to "https://www.musixmatch.com/search/$q",
            "YouTube" to ("https://www.youtube.com/results?search_query=" + Uri.encode("$title $artist lyrics"))
        )
        val sb = SpannableStringBuilder(
            "These lyrics aren't in the sources this app can read.\nTap a site to find them:\n"
        )
        for ((name, url) in links) {
            sb.append("\n")
            val start = sb.length
            sb.append("▶  $name")
            sb.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }, start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        lyricsView.setTextColor(BRIGHT)
        lyricsView.setLinkTextColor(GREEN)
        lyricsView.movementMethod = LinkMovementMethod.getInstance()
        lyricsView.setText(sb, TextView.BufferType.SPANNABLE)
    }

    // ---------- playback follow (runs while the window is open) ----------

    private fun currentPositionMs(now: Long): Long {
        val st = playbackState ?: return 0L
        val playing = st.state == PlaybackState.STATE_PLAYING
        if (now - pendingSeekAt < 1500) {
            return LyricsFollow.estimatePosition(pendingSeekPos, pendingSeekAt, now, 1f, playing, durationMs)
        }
        return LyricsFollow.estimatePosition(
            st.position, st.lastPositionUpdateTime, now, st.playbackSpeed, playing, durationMs
        )
    }

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val pos = currentPositionMs(now)
        val dur = durationMs

        seek.isEnabled = dur > 0
        if (dur > 0) {
            if (seek.max != dur.toInt()) seek.max = dur.toInt()
            timeTotal.text = LyricsFollow.formatTime(dur)
            if (!seeking) {
                seek.progress = pos.toInt().coerceIn(0, seek.max)
                timeNow.text = LyricsFollow.formatTime(pos)
            }
        } else {
            timeTotal.text = "0:00"
            if (!seeking) { seek.progress = 0; timeNow.text = "0:00" }
        }
        updatePlayIcon()

        val userBusy = now - lastUserScroll < USER_SCROLL_HOLD_MS
        if (layoutReady) {
            if (synced.isNotEmpty()) {
                val idx = LrcParser.currentIndex(synced, pos + LOOKAHEAD_MS)
                val changed = idx != highlightIdx
                if (changed) setHighlight(idx)
                if ((changed || recenter) && !userBusy) {
                    scrollToLine(idx)
                    recenter = false
                }
            } else if (plainMode && !userBusy && dur > 0) {
                val range = lyricsView.height - scroll.height
                if (range > 0) {
                    scroll.scrollTo(0, (LyricsFollow.plainFraction(pos, dur) * range).toInt())
                }
            }
        }

        // Cover sometimes arrives late; keep asking until we have one.
        if (!coverSet && now - lastArtCheck > 2000) {
            lastArtCheck = now
            controller?.metadata?.let { artFrom(it) }?.let { showCover(it) }
        }
    }

    private fun updatePlayIcon() {
        if (!::playBtn.isInitialized) return
        val kind = if (playbackState?.state == PlaybackState.STATE_PLAYING) IconView.PAUSE else IconView.PLAY
        if (playBtn.kind != kind) {
            playBtn.kind = kind
            playBtn.invalidate()
        }
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun applyOpacity() {
        val a = ALPHAS[opacityIdx]
        panelBg.setColors(intArrayOf(Color.argb(a, 34, 36, 46), Color.argb(a, 8, 9, 14)))
    }

    private fun buildPanel() {
        val dm = resources.displayMetrics
        panelBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, 0)).apply {
            cornerRadius = dp(26).toFloat()
            setStroke(dp(1), Color.argb(60, 255, 255, 255))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding(dp(14), dp(12), dp(14), dp(4))
        }

        // header: cover | title + artist | G ⌄ ◐ – ✕
        collapseBtn = IconView(this, IconView.CHEV_DOWN)
        coverView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.argb(50, 255, 255, 255)); cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat())
                }
            }
        }
        titleView = TextView(this).apply {
            text = "Waiting for Spotify…"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
        }
        artistView = TextView(this).apply {
            setTextColor(GREEN)
            textSize = 12.5f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView)
            addView(artistView)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(coverView, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
            addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(textChip("G") {
                // Exact Genius page if we matched one, otherwise a Genius search for the current song.
                val url = currentGeniusUrl
                    ?: ("https://genius.com/search?q=" + Uri.encode("$currentTitle $currentArtist"))
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }, chipParams())
            addView(collapseBtn.also {
                it.background = chipBg()
                it.setOnClickListener {
                    controlsCollapsed = !controlsCollapsed
                    applyCollapsed()
                    saveLayoutPrefs()
                }
            }, chipParams())
            addView(iconChip(IconView.OPACITY) {
                opacityIdx = (opacityIdx + 1) % ALPHAS.size
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_OPACITY, opacityIdx).apply()
                applyOpacity()
            }, chipParams())
            addView(iconChip(IconView.MINUS) { showBubble() }, chipParams())
            addView(iconChip(IconView.CLOSE) { stopSelf() }, chipParams())
        }

        // lyrics
        lyricsView = TextView(this).apply {
            setTextColor(BRIGHT)
            textSize = 19f
            gravity = Gravity.CENTER_HORIZONTAL
            setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.3f)
            setPadding(dp(6), dp(16), dp(6), dp(40))
            setShadowLayer(dp(4).toFloat(), 0f, dp(1).toFloat(), Color.argb(210, 0, 0, 0))
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                layoutReady = true
                recenter = true
            }
        }
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(lyricsView)
        }

        // Double-tap on the lyrics shrinks the window to the bubble; touching pauses auto-follow.
        val doubleTap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                showBubble()
                return true
            }
        })
        scroll.setOnTouchListener { _, e ->
            doubleTap.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
                lastUserScroll = SystemClock.elapsedRealtime()
                recenter = true
            }
            false   // let the ScrollView keep scrolling normally
        }

        // seek bar row
        timeNow = timeLabel()
        timeTotal = timeLabel()
        seek = SeekBar(this).apply {
            max = 1
            progressTintList = ColorStateList.valueOf(GREEN)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) timeNow.text = LyricsFollow.formatTime(p.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar) { seeking = true }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    seeking = false
                    val target = sb.progress.toLong()
                    pendingSeekPos = target
                    pendingSeekAt = SystemClock.elapsedRealtime()
                    lastUserScroll = -USER_SCROLL_HOLD_MS
                    recenter = true
                    controller?.transportControls?.seekTo(target)
                }
            })
        }
        seekRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(timeNow)
            addView(seek, LinearLayout.LayoutParams(0, dp(32), 1f))
            addView(timeTotal)
        }

        // controls row: [mode] prev play next [grip]
        prevBtn = IconView(this, IconView.PREV).apply {
            setOnClickListener { controller?.transportControls?.skipToPrevious() }
        }
        playBtn = IconView(this, IconView.PLAY).apply {
            setOnClickListener {
                val tc = controller?.transportControls ?: return@setOnClickListener
                if (playbackState?.state == PlaybackState.STATE_PLAYING) tc.pause() else tc.play()
            }
        }
        nextBtn = IconView(this, IconView.NEXT).apply {
            setOnClickListener { controller?.transportControls?.skipToNext() }
        }

        // What the corner grip does is chosen by the chip on its left:
        //   Window = change the window size only (text stays the same size, more/less lyrics fit)
        //   Scale  = zoom the whole popup (window, text and buttons grow/shrink together)
        modeChip = TextView(this).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat() }
            setOnClickListener {
                scaleMode = !scaleMode
                applyMode()
                saveLayoutPrefs()
                Toast.makeText(
                    this@OverlayService,
                    if (scaleMode) "Scale: dragging ◢ zooms everything" else "Window: dragging ◢ resizes only",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        grip = TextView(this).apply {
            text = "◢"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        var gW = 0
        var gH = 0
        var gX = 0f
        var gY = 0f
        var gS = 1f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    gW = panelParams.width; gH = panelParams.height
                    gX = e.rawX; gY = e.rawY; gS = uiScale
                }
                MotionEvent.ACTION_MOVE -> {
                    val sw = resources.displayMetrics.widthPixels
                    val sh = resources.displayMetrics.heightPixels
                    val dx = e.rawX - gX
                    val dy = e.rawY - gY
                    if (scaleMode) {
                        // zoom: window and content change by the same ratio, so the layout stays identical
                        var r = (((gW + dx) / gW) + ((gH + dy) / gH)) / 2f
                        val rMin = MIN_SCALE / gS
                        val rMax = minOf(sw.toFloat() / gW, sh.toFloat() / gH, MAX_SCALE / gS)
                        r = r.coerceAtLeast(rMin).coerceAtMost(rMax)
                        uiScale = gS * r
                        panelParams.width = (gW * r).toInt()
                        panelParams.height = (gH * r).toInt()
                    } else {
                        // resize: same zoom, just a bigger or smaller window
                        val minW = (dp(190) * uiScale).toInt()
                        val minH = (dp(150) * uiScale).toInt()
                        panelParams.width = (gW + dx).toInt().coerceAtLeast(minW).coerceAtMost(sw)
                        panelParams.height = (gH + dy).toInt().coerceAtLeast(minH).coerceAtMost(sh)
                    }
                    applyLayout()
                }
                MotionEvent.ACTION_UP -> saveLayoutPrefs()
            }
            true
        }
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(modeChip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(Space(this@OverlayService), LinearLayout.LayoutParams(0, dp(1), 1f))
            addView(prevBtn, LinearLayout.LayoutParams(dp(48), dp(40)))
            addView(playBtn, LinearLayout.LayoutParams(dp(56), dp(40)))
            addView(nextBtn, LinearLayout.LayoutParams(dp(48), dp(40)))
            addView(Space(this@OverlayService), LinearLayout.LayoutParams(0, dp(1), 1f))
            addView(grip, LinearLayout.LayoutParams(dp(48), dp(40)))
        }

        val divider = View(this).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) }
        val bottomLine = View(this).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) }

        root.addView(header)
        root.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(8)
        })
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottomLine, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
        root.addView(seekRow)
        root.addView(controls)

        val sp = getSharedPreferences(PREFS, MODE_PRIVATE)
        uiScale = sp.getFloat("scale", 1f).coerceAtLeast(MIN_SCALE).coerceAtMost(MAX_SCALE)
        scaleMode = sp.getBoolean("scale_mode", false)
        controlsCollapsed = sp.getBoolean("collapsed", false)
        val w = sp.getInt("win_w", (dm.widthPixels * 0.9f).toInt())
            .coerceAtLeast(dp(150)).coerceAtMost(dm.widthPixels)
        val h = sp.getInt("win_h", (dm.heightPixels * 0.6f).toInt())
            .coerceAtLeast(dp(150)).coerceAtMost(dm.heightPixels)
        panelParams = WindowManager.LayoutParams(
            w, h,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt("win_x", (dm.widthPixels * 0.05f).toInt())
                .coerceAtLeast(0).coerceAtMost((dm.widthPixels - dp(80)).coerceAtLeast(0))
            y = sp.getInt("win_y", dp(100))
                .coerceAtLeast(0).coerceAtMost((dm.heightPixels - dp(80)).coerceAtLeast(0))
        }

        // The window is a plain frame; the real UI inside is laid out at (window size / zoom) and then
        // zoomed, so "Window" resizing changes the layout and "Scale" zoom keeps it identical.
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(1, 1))
        panelRoot = root

        makeDraggable(titleBox, panelParams, onDouble = { showBubble() }) { frame }
        makeDraggable(coverView, panelParams, onDouble = { showBubble() }) { frame }
        panel = frame
        applyLayout()
        applyMode()
        applyCollapsed()
    }

    /** Lay the UI out at window size / zoom, then zoom it, so the window always shows exactly [panelParams]. */
    private fun applyLayout() {
        val root = panelRoot
        val lp = root.layoutParams as FrameLayout.LayoutParams
        lp.width = (panelParams.width / uiScale).toInt()
        lp.height = (panelParams.height / uiScale).toInt()
        root.layoutParams = lp
        root.pivotX = 0f
        root.pivotY = 0f
        root.scaleX = uiScale
        root.scaleY = uiScale
        recenter = true
        panel?.takeIf { it.isAttachedToWindow }?.let { wm.updateViewLayout(it, panelParams) }
    }

    private fun applyMode() {
        modeChip.text = if (scaleMode) "Scale" else "Window"
        modeChip.setTextColor(if (scaleMode) GREEN else SOFT)
        (modeChip.background as GradientDrawable)
            .setStroke(dp(1), if (scaleMode) GREEN else Color.argb(90, 255, 255, 255))
        grip.setTextColor(if (scaleMode) GREEN else Color.argb(150, 255, 255, 255))
    }

    private fun applyCollapsed() {
        val v = if (controlsCollapsed) View.GONE else View.VISIBLE
        seekRow.visibility = v
        prevBtn.visibility = v
        playBtn.visibility = v
        nextBtn.visibility = v
        collapseBtn.kind = if (controlsCollapsed) IconView.CHEV_UP else IconView.CHEV_DOWN
        collapseBtn.invalidate()
        recenter = true
    }

    private fun saveLayoutPrefs() {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putInt("win_w", panelParams.width).putInt("win_h", panelParams.height)
                .putInt("win_x", panelParams.x).putInt("win_y", panelParams.y)
                .putFloat("scale", uiScale)
                .putBoolean("scale_mode", scaleMode)
                .putBoolean("collapsed", controlsCollapsed)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun timeLabel() = TextView(this).apply {
        text = "0:00"
        textSize = 11f
        setTextColor(SOFT)
        gravity = Gravity.CENTER
        minWidth = dp(36)
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
    }

    private fun chipBg() = GradientDrawable().apply {
        setColor(Color.argb(42, 255, 255, 255))
        cornerRadius = dp(10).toFloat()
    }

    private fun chipParams() =
        LinearLayout.LayoutParams(dp(34), dp(30)).apply { leftMargin = dp(4) }

    private fun iconChip(kind: Int, onClick: () -> Unit) = IconView(this, kind).apply {
        background = chipBg()
        setOnClickListener { onClick() }
    }

    private fun textChip(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.argb(235, 255, 255, 255))
        gravity = Gravity.CENTER
        background = chipBg()
        setOnClickListener { onClick() }
    }

    private fun buildBubble() {
        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(235, 30, 215, 96))
        }
        val b = TextView(this).apply {
            text = "♪"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = circle
            elevation = dp(6).toFloat()
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(200)
        }
        makeDraggable(b, bubbleParams, onTap = { showPanel() }) { b }
        bubble = b
    }

    private fun showPanel() {
        bubble?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        panel?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, panelParams) }
        recenter = true
        main.removeCallbacks(ticker)
        main.post(ticker)
    }

    private fun showBubble() {
        saveLayoutPrefs()
        main.removeCallbacks(ticker)   // nothing to follow while collapsed
        panel?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        bubble?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, bubbleParams) }
    }

    /** Drags the window by touching [handle]; a tiny movement counts as a tap. */
    private fun makeDraggable(
        handle: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        onDouble: (() -> Unit)? = null,
        windowView: () -> View
    ) {
        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        val detector = if (onDouble == null) null else GestureDetector(
            this, object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    onDouble()
                    return true
                }
            })
        handle.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    val w = windowView()
                    if (w.isAttachedToWindow) wm.updateViewLayout(w, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() ?: v.performClick()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Lyrics overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lyrics Popup is running")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}

/** Small drawn transport icons (play, pause, previous, next) so no emoji font is involved. */
private class IconView(context: Context, var kind: Int) : View(context) {
    companion object {
        const val PLAY = 0
        const val PAUSE = 1
        const val PREV = 2
        const val NEXT = 3
        const val CHEV_DOWN = 4
        const val CHEV_UP = 5
        const val CLOSE = 6
        const val MINUS = 7
        const val OPACITY = 8
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) * 0.36f
        path.reset()
        when (kind) {
            PLAY -> {
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.lineTo(cx + s, cy)
                path.close()
                c.drawPath(path, paint)
            }
            PAUSE -> {
                c.drawRoundRect(cx - s * 0.85f, cy - s, cx - s * 0.2f, cy + s, s * 0.15f, s * 0.15f, paint)
                c.drawRoundRect(cx + s * 0.2f, cy - s, cx + s * 0.85f, cy + s, s * 0.15f, s * 0.15f, paint)
            }
            PREV -> {
                c.drawRect(cx - s, cy - s * 0.85f, cx - s * 0.6f, cy + s * 0.85f, paint)
                path.moveTo(cx + s, cy - s * 0.9f)
                path.lineTo(cx + s, cy + s * 0.9f)
                path.lineTo(cx - s * 0.5f, cy)
                path.close()
                c.drawPath(path, paint)
            }
            CLOSE -> {
                stroke.strokeWidth = s * 0.28f
                val d = s * 0.62f
                c.drawLine(cx - d, cy - d, cx + d, cy + d, stroke)
                c.drawLine(cx - d, cy + d, cx + d, cy - d, stroke)
            }
            MINUS -> {
                stroke.strokeWidth = s * 0.28f
                c.drawLine(cx - s * 0.7f, cy, cx + s * 0.7f, cy, stroke)
            }
            OPACITY -> {
                stroke.strokeWidth = s * 0.24f
                val r = s * 0.7f
                c.drawCircle(cx, cy, r, stroke)
                c.drawArc(cx - r, cy - r, cx + r, cy + r, 90f, 180f, true, paint)
            }
            CHEV_DOWN, CHEV_UP -> {
                val dir = if (kind == CHEV_DOWN) 1f else -1f
                stroke.strokeWidth = s * 0.3f
                path.moveTo(cx - s * 0.75f, cy - dir * s * 0.3f)
                path.lineTo(cx, cy + dir * s * 0.3f)
                path.lineTo(cx + s * 0.75f, cy - dir * s * 0.3f)
                c.drawPath(path, stroke)
            }
            NEXT -> {
                c.drawRect(cx + s * 0.6f, cy - s * 0.85f, cx + s, cy + s * 0.85f, paint)
                path.moveTo(cx - s, cy - s * 0.9f)
                path.lineTo(cx - s, cy + s * 0.9f)
                path.lineTo(cx + s * 0.5f, cy)
                path.close()
                c.drawPath(path, paint)
            }
        }
    }
}
