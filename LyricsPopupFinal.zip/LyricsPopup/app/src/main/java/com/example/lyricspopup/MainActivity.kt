package com.example.lyricspopup

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Step(
        val card: LinearLayout,
        val badge: TextView,
        val button: TextView,
        val number: Int
    )

    private val bgTop = Color.parseColor("#171925")
    private val bgBottom = Color.parseColor("#09090D")
    private val card = Color.parseColor("#1B1D29")
    private val green = Color.parseColor("#1ED760")
    private val red = Color.parseColor("#FF6B6B")
    private val dim = Color.parseColor("#9AA0AE")
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var step1: Step
    private lateinit var step2: Step
    private lateinit var progressLabel: TextView
    private lateinit var seg1: View
    private lateinit var seg2: View
    private lateinit var startBtn: TextView
    private lateinit var startHint: TextView
    private lateinit var tokenInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        try {
            buildUi()
        } catch (t: Throwable) {
            CrashLog.record(this, t)
            setContentView(ScrollView(this).apply {
                addView(TextView(this@MainActivity).apply {
                    text = "Startup error (please send me this text):\n\n" + Log.getStackTraceString(t)
                    textSize = 12f
                    setPadding(dp(16), dp(48), dp(16), dp(16))
                })
            })
        }
    }

    // ---------- screen ----------

    private fun buildUi() {
        window.setBackgroundDrawable(
            GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(bgTop, bgBottom))
        )
        window.statusBarColor = bgTop

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(28))
        }

        // hero
        val logo = tv("♪", 28f, Color.BLACK, bold = true).apply {
            gravity = Gravity.CENTER
            background = oval(green)
        }
        val heroText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv("Lyrics Popup", 26f, Color.WHITE, bold = true))
            addView(tv("See-through lyrics that follow your Spotify song", 13.5f, dim))
        }
        col.addView(LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)).apply { rightMargin = dp(14) })
            addView(heroText, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        })

        // last crash, if any
        CrashLog.read(this)?.let { crash ->
            val box = cardBox()
            box.addView(tv("The app crashed last time", 15f, red, bold = true))
            box.addView(tv(crash.take(700), 11f, dim).apply { setPadding(0, dp(6), 0, dp(10)) })
            val row = LinearLayout(this)
            row.addView(pill("Copy error", false) {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("crash", crash))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            })
            row.addView(pill("Dismiss", false) {
                CrashLog.clear(this)
                box.visibility = View.GONE
            }, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)).apply { leftMargin = dp(10) })
            box.addView(row)
            col.addView(box, boxParams(top = 16))
        }

        // progress
        progressLabel = tv("", 13f, dim, bold = true)
        seg1 = View(this)
        seg2 = View(this)
        val segs = LinearLayout(this).apply {
            addView(seg1, LinearLayout.LayoutParams(0, dp(5), 1f).apply { rightMargin = dp(6) })
            addView(seg2, LinearLayout.LayoutParams(0, dp(5), 1f))
        }
        col.addView(progressLabel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(22); bottomMargin = dp(8) })
        col.addView(segs, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(14) })

        // step 1 and 2 (required)
        step1 = stepCard(
            1, "Show over other apps",
            "Lets the lyrics window float on top of Spotify.", "Allow"
        ) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        step2 = stepCard(
            2, "Read what's playing",
            "Notification access lets the app see the current Spotify song. It does not read your notifications.",
            "Allow"
        ) {
            startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        }
        col.addView(step1.card, boxParams())
        col.addView(step2.card, boxParams())

        // Xiaomi / Redmi / POCO need one more switch before pop-ups are allowed.
        val m = Build.MANUFACTURER.lowercase()
        if (m.contains("xiaomi") || m.contains("redmi") || m.contains("poco")) {
            val box = cardBox()
            box.addView(tv("Redmi phone? One more thing", 15f, Color.WHITE, bold = true))
            box.addView(tv(
                "Open the page below and turn on \"Display pop-up windows while running in the background\" " +
                    "and Autostart. Set Battery saver to \"No restrictions\".\n\n" +
                    "If \"Allow\" above is greyed out: App info > ⋮ menu > Allow restricted settings.",
                13f, dim
            ).apply { setPadding(0, dp(4), 0, dp(10)) })
            box.addView(pill("Open permissions", false) { openXiaomiPermissions() })
            col.addView(box, boxParams())
        }

        // big start / stop button
        startBtn = tv("", 17f, Color.BLACK, bold = true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { onStartStop() }
        }
        startHint = tv("", 12.5f, dim).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        col.addView(startBtn, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(58)
        ).apply { topMargin = dp(6) })
        col.addView(startHint, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // how to use
        val how = cardBox()
        how.addView(tv("Using the popup", 16f, Color.WHITE, bold = true).apply { setPadding(0, 0, 0, dp(8)) })
        for ((icon, text) in listOf(
            "☰" to "Drag the top bar to move it anywhere.",
            "–" to "Tap – or double-tap the lyrics to shrink it to a ♪ bubble. Tap the bubble to bring it back.",
            "⌄" to "The small tab next to G hides or shows the playback controls.",
            "◐" to "Cycles the transparency, from glass-clear to nearly solid.",
            "◢" to "Drag the corner to resize. The chip beside it picks what that does: " +
                "Window changes the window size only, Scale zooms the text and buttons with it.",
            "━" to "Drag the song bar to jump to any part of the song."
        )) {
            how.addView(LinearLayout(this).apply {
                setPadding(0, dp(5), 0, dp(5))
                addView(tv(icon, 16f, green, bold = true).apply { gravity = Gravity.CENTER },
                    LinearLayout.LayoutParams(dp(30), LinearLayout.LayoutParams.WRAP_CONTENT))
                addView(tv(text, 13.5f, Color.parseColor("#D3D6DE")),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            })
        }
        col.addView(how, boxParams(top = 22))

        // advanced (collapsed)
        val adv = cardBox()
        val advBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val advHeader = tv("Advanced  ▸", 14f, dim, bold = true)
        advHeader.setOnClickListener {
            val open = advBody.visibility != View.VISIBLE
            advBody.visibility = if (open) View.VISIBLE else View.GONE
            advHeader.text = if (open) "Advanced  ▾" else "Advanced  ▸"
        }
        tokenInput = EditText(this).apply {
            hint = "Genius token (optional)"
            setHintTextColor(Color.parseColor("#5C616B"))
            setTextColor(Color.WHITE)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
                .getString(OverlayService.KEY_TOKEN, ""))
        }
        advBody.addView(tv(
            "Not needed: lyrics and covers work without it. A free token from genius.com/api-clients " +
                "only makes the song match more precise.", 12.5f, dim
        ).apply { setPadding(0, dp(8), 0, 0) })
        advBody.addView(tokenInput)
        adv.addView(advHeader)
        adv.addView(advBody)
        col.addView(adv, boxParams())

        setContentView(ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onPause() {
        saveToken()
        super.onPause()
    }

    // ---------- state ----------

    private fun overlayOk() = Settings.canDrawOverlays(this)

    private fun listenerOk() =
        Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
            ?.contains(packageName) == true

    private fun refresh() {
        if (!::step1.isInitialized) return
        val o = overlayOk()
        val l = listenerOk()
        paintStep(step1, o)
        paintStep(step2, l)
        val done = (if (o) 1 else 0) + (if (l) 1 else 0)
        progressLabel.text = if (done == 2) "All set" else "Setup · $done of 2 done"
        progressLabel.setTextColor(if (done == 2) green else dim)
        seg1.background = rounded(if (o) green else Color.parseColor("#2B2E3C"), 3)
        seg2.background = rounded(if (l) green else Color.parseColor("#2B2E3C"), 3)

        val running = OverlayService.running
        when {
            running -> {
                startBtn.text = "Stop lyrics popup"
                startBtn.setTextColor(Color.WHITE)
                startBtn.background = rounded(Color.TRANSPARENT, 18, red)
                startHint.text = "Running. Switch to Spotify and play a song."
            }
            o && l -> {
                startBtn.text = "Start lyrics popup"
                startBtn.setTextColor(Color.BLACK)
                startBtn.background = rounded(green, 18)
                startHint.text = "Then open Spotify and play something."
            }
            else -> {
                startBtn.text = "Start lyrics popup"
                startBtn.setTextColor(Color.parseColor("#6C7080"))
                startBtn.background = rounded(Color.parseColor("#23252F"), 18)
                startHint.text = "Finish the steps above first."
            }
        }
    }

    private fun paintStep(s: Step, done: Boolean) {
        if (done) {
            s.badge.text = "✓"
            s.badge.setTextColor(Color.BLACK)
            s.badge.background = oval(green)
            s.button.text = "Granted · review"
            s.button.setTextColor(dim)
            s.button.background = rounded(Color.TRANSPARENT, 20, Color.parseColor("#3A3D4C"))
            s.card.background = rounded(card, 18, Color.parseColor("#2A5E3E"))
        } else {
            s.badge.text = "${s.number}"
            s.badge.setTextColor(Color.WHITE)
            s.badge.background = oval(Color.parseColor("#2E3140"))
            s.button.text = "Allow"
            s.button.setTextColor(Color.BLACK)
            s.button.background = rounded(green, 20)
            s.card.background = rounded(card, 18)
        }
    }

    private fun saveToken() {
        if (!::tokenInput.isInitialized) return
        getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE).edit()
            .putString(OverlayService.KEY_TOKEN, tokenInput.text.toString().trim()).apply()
    }

    private fun onStartStop() {
        if (OverlayService.running) {
            stopService(Intent(this, OverlayService::class.java))
            ui.postDelayed({ refresh() }, 400)
            return
        }
        if (!overlayOk() || !listenerOk()) {
            Toast.makeText(this, "Finish the two setup steps first", Toast.LENGTH_SHORT).show()
            return
        }
        saveToken()
        try {
            startForegroundService(Intent(this, OverlayService::class.java))
        } catch (t: Throwable) {
            CrashLog.record(this, t)
            Toast.makeText(this, "Couldn't start: ${t.message}", Toast.LENGTH_LONG).show()
            return
        }
        ui.postDelayed({ refresh() }, 500)
        moveTaskToBack(true)   // go back to Spotify
    }

    /** Opens MIUI/HyperOS's own permission page for this app, or the normal app info page. */
    private fun openXiaomiPermissions() {
        try {
            startActivity(Intent("miui.intent.action.APP_PERM_EDITOR").apply {
                setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
                putExtra("extra_pkgname", packageName)
            })
        } catch (_: Throwable) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    // ---------- view helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != 0) setStroke(dp(1), stroke)
    }

    private fun oval(color: Int) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
    }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun pill(label: String, filled: Boolean, onClick: () -> Unit) = tv(label, 14f, Color.BLACK, bold = true).apply {
        gravity = Gravity.CENTER
        setPadding(dp(20), 0, dp(20), 0)
        minHeight = dp(40)
        if (filled) {
            background = rounded(green, 20)
        } else {
            setTextColor(Color.WHITE)
            background = rounded(Color.TRANSPARENT, 20, Color.parseColor("#3A3D4C"))
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40))
        setOnClickListener { onClick() }
    }

    private fun cardBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(card, 18)
        setPadding(dp(18), dp(16), dp(18), dp(16))
    }

    private fun boxParams(top: Int = 0) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top); bottomMargin = dp(12) }

    private fun stepCard(number: Int, title: String, desc: String, action: String, onClick: () -> Unit): Step {
        val badge = tv("$number", 15f, Color.WHITE, bold = true).apply {
            gravity = Gravity.CENTER
            background = oval(Color.parseColor("#2E3140"))
        }
        val button = pill(action, true, onClick)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tv(title, 16f, Color.WHITE, bold = true))
            addView(tv(desc, 13f, dim).apply { setPadding(0, dp(3), 0, dp(12)) })
            addView(button)
        }
        val box = cardBox().apply {
            orientation = LinearLayout.HORIZONTAL
            addView(badge, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(14) })
            addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        return Step(box, badge, button, number)
    }
}
