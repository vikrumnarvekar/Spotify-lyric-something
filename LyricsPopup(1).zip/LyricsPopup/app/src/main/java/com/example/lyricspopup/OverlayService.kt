package com.example.lyricspopup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val SPOTIFY = "com.spotify.music"
        const val PREFS = "prefs"
        const val KEY_TOKEN = "genius_token"
        private const val CHANNEL_ID = "lyrics_overlay"
        private const val NOTIF_ID = 42
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var msm: MediaSessionManager
    private lateinit var listenerComponent: ComponentName

    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams

    private lateinit var titleView: TextView
    private lateinit var lyricsView: TextView
    private lateinit var scroll: ScrollView

    private var controller: MediaController? = null
    private var lastTrackKey: String? = null
    private var currentGeniusUrl: String? = null

    private val repo = LyricsRepository {
        getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TOKEN, "") ?: ""
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            handleMetadata(metadata)
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener {
        attachToSpotify(it)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        msm = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
        listenerComponent = ComponentName(this, MediaListenerService::class.java)
        startAsForeground()
        buildPanel()
        buildBubble()
        showPanel()
        try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, main)
            attachToSpotify(msm.getActiveSessions(listenerComponent))
        } catch (e: SecurityException) {
            setLyrics("Notification access is not granted.\nOpen the app and tap \"Grant notification access\".")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (_: Exception) {}
        controller?.unregisterCallback(controllerCallback)
        panel?.let { runCatching { wm.removeView(it) } }
        bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }

    // ---------- Spotify now-playing ----------

    private fun attachToSpotify(controllers: List<MediaController>?) {
        val spotify = controllers?.firstOrNull { it.packageName == SPOTIFY }
        if (spotify?.sessionToken == controller?.sessionToken && controller != null) return
        controller?.unregisterCallback(controllerCallback)
        controller = spotify
        if (spotify == null) {
            titleView.text = "Waiting for Spotify…"
            setLyrics("Start playing a song in Spotify.")
            lastTrackKey = null
            return
        }
        spotify.registerCallback(controllerCallback, main)
        handleMetadata(spotify.metadata)
    }

    private fun handleMetadata(md: MediaMetadata?) {
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val artist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val key = "$title|$artist"
        if (key == lastTrackKey) return
        lastTrackKey = key

        titleView.text = "$title\n$artist"
        currentGeniusUrl = null
        setLyrics("Loading lyrics…")
        scroll.scrollTo(0, 0)

        if (TrackText.isAd(title, artist)) {
            setLyrics("Advertisement playing…")
            return
        }
        val album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val durationMs = md.getLong(MediaMetadata.METADATA_KEY_DURATION)

        Thread {
            val result = repo.fetch(title, artist, album, durationMs)
            main.post {
                if (key != lastTrackKey) return@post   // song changed while loading
                currentGeniusUrl = result.geniusUrl
                val text = when {
                    result.error != null -> result.error
                    result.instrumental -> "♪ Instrumental ♪"
                    result.synced.isNotEmpty() ->
                        result.synced.joinToString("\n") { it.text.ifBlank { "♪" } }
                    !result.plain.isNullOrBlank() -> result.plain
                    else -> "No lyrics found for this track."
                }
                setLyrics(text)
                scroll.scrollTo(0, 0)
            }
        }.start()
    }

    private fun setLyrics(text: String) { lyricsView.text = text }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val bg = GradientDrawable().apply {
            setColor(Color.parseColor("#E6121212"))
            cornerRadius = dp(18).toFloat()
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(12), dp(8), dp(12), dp(12))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        titleView = TextView(this).apply {
            text = "Waiting for Spotify…"
            setTextColor(Color.parseColor("#1ED760"))
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 2
        }
        header.addView(titleView, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(headerButton("G") {
            currentGeniusUrl?.let {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        })
        header.addView(headerButton("–") { showBubble() })
        header.addView(headerButton("✕") { stopSelf() })

        lyricsView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 17f
            setLineSpacing(0f, 1.15f)
            setPadding(0, dp(8), 0, 0)
        }
        scroll = ScrollView(this).apply { addView(lyricsView) }

        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        panelParams = WindowManager.LayoutParams(
            (dm.widthPixels * 0.88f).toInt(),
            (dm.heightPixels * 0.5f).toInt(),
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (dm.widthPixels * 0.06f).toInt()
            y = dp(120)
        }

        makeDraggable(header, panelParams) { root }
        panel = root
    }

    private fun headerButton(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(6), dp(14), dp(6))
        setOnClickListener { onClick() }
    }

    private fun buildBubble() {
        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#1ED760"))
        }
        val b = TextView(this).apply {
            text = "♪"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = circle
            elevation = dp(6).toFloat()
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(200)
        }
        makeDraggable(b, bubbleParams, onTap = { showPanel() }) { b }
        bubble = b
    }

    private fun showPanel() {
        bubble?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        panel?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, panelParams) }
    }

    private fun showBubble() {
        panel?.takeIf { it.isAttachedToWindow }?.let { wm.removeView(it) }
        bubble?.takeIf { !it.isAttachedToWindow }?.let { wm.addView(it, bubbleParams) }
    }

    /** Drags the window by touching [handle]; a tiny movement counts as a tap. */
    private fun makeDraggable(
        handle: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        windowView: () -> View
    ) {
        var startX = 0; var startY = 0
        var touchX = 0f; var touchY = 0f
        var moved = false
        handle.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    val w = windowView()
                    if (w.isAttachedToWindow) wm.updateViewLayout(w, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() ?: v.performClick()
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Foreground notification ----------

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Lyrics overlay", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lyrics Popup is running")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
