plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.lyricspopup"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.lyricspopup"
        // Android 5.0. The app needs the media-session APIs, which start there.
        minSdk = 21
        targetSdk = 34
        versionCode = 2
        versionName = "1.4"
    }

    // A fixed key for debug builds. GitHub creates a new random debug key on every run, and Android
    // refuses to update an installed app that was signed with a different key ("App not installed").
    // This is a throwaway key for a personal app; do not reuse it for anything you publish.
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    testOptions {
        unitTests.isReturnDefaultValues = true
    }
}

dependencies {
    // The app itself has no third-party dependencies: networking uses HttpURLConnection and JSON uses
    // org.json. JUnit is only used by the unit tests in src/test.
    testImplementation("junit:junit:4.13.2")
}
