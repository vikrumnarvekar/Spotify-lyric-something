package com.example.lyricspopup

import org.junit.Assert.assertEquals
import org.junit.Test

class RomanizerTest {

    @Test
    fun plainLatinTextIsUntouched() {
        assertEquals("hello world", Romanizer.toEnglish("hello world"))
    }

    @Test
    fun fullwidthPunctuationBecomesAscii() {
        assertEquals("Hello!", Romanizer.toEnglish("Hello\uFF01"))
        assertEquals("a, b", Romanizer.toEnglish("a\u3001b"))
    }

    @Test
    fun hiraganaIsWrittenInLatinLetters() {
        assertEquals("ai", Romanizer.toEnglish("\u3042\u3044"))
        assertEquals("sakura", Romanizer.toEnglish("\u3055\u304f\u3089"))
    }

    @Test
    fun smallTsuDoublesTheNextConsonant() {
        assertEquals("kitte", Romanizer.toEnglish("\u304d\u3063\u3066"))
    }
}
