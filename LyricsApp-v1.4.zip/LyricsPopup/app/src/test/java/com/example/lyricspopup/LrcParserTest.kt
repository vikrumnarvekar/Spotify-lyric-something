package com.example.lyricspopup

import org.junit.Assert.assertEquals
import org.junit.Test

class LrcParserTest {

    @Test
    fun parsesTimesAndText() {
        val lines = LrcParser.parse("[00:01.50]Hello\n[01:02.03]World")
        assertEquals(2, lines.size)
        assertEquals(1_500L, lines[0].timeMs)
        assertEquals("Hello", lines[0].text)
        assertEquals(62_030L, lines[1].timeMs)
        assertEquals("World", lines[1].text)
    }

    @Test
    fun oneLineCanCarryManyTimeTags() {
        val lines = LrcParser.parse("[00:10.00][01:20.00]Chorus")
        assertEquals(2, lines.size)
        assertEquals(10_000L, lines[0].timeMs)
        assertEquals(80_000L, lines[1].timeMs)
        assertEquals("Chorus", lines[1].text)
    }

    @Test
    fun ignoresMetadataTags() {
        val lines = LrcParser.parse("[ar:Someone]\n[length:3:20]\n[00:05.00]Hi")
        assertEquals(1, lines.size)
        assertEquals("Hi", lines[0].text)
    }

    @Test
    fun offsetTagShiftsLinesEarlier() {
        val lines = LrcParser.parse("[offset:+500]\n[00:10.00]Line")
        assertEquals(9_500L, lines[0].timeMs)
    }

    @Test
    fun timesNeverGoBelowZero() {
        val lines = LrcParser.parse("[offset:+500]\n[00:00.20]X")
        assertEquals(0L, lines[0].timeMs)
    }

    @Test
    fun linesAreSortedByTime() {
        val lines = LrcParser.parse("[00:20.00]B\n[00:10.00]A")
        assertEquals("A", lines[0].text)
        assertEquals("B", lines[1].text)
    }

    @Test
    fun currentIndexFollowsPlayback() {
        val lines = listOf(LrcLine(1_000, "a"), LrcLine(5_000, "b"), LrcLine(9_000, "c"))
        assertEquals(-1, LrcParser.currentIndex(lines, 0))
        assertEquals(0, LrcParser.currentIndex(lines, 1_000))
        assertEquals(0, LrcParser.currentIndex(lines, 4_999))
        assertEquals(1, LrcParser.currentIndex(lines, 5_000))
        assertEquals(2, LrcParser.currentIndex(lines, 20_000))
    }

    @Test
    fun currentIndexOfNoLinesIsMinusOne() {
        assertEquals(-1, LrcParser.currentIndex(emptyList(), 1_000))
    }
}
