package com.example.lyricspopup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlainTimingTest {

    private val song = "[Verse 1]\nHello there\nGeneral Kenobi\n[Chorus]\nYou are a bold one"

    @Test
    fun headersAreSkippedAndEveryLineGetsATime() {
        val lines = PlainTiming.estimate(song, 200_000)
        assertEquals(3, lines.size)
        assertEquals("Hello there", lines[0].text)
        assertEquals("You are a bold one", lines[2].text)
    }

    @Test
    fun timesIncreaseAndStayInsideTheSong() {
        val lines = PlainTiming.estimate(song, 200_000)
        for (i in 1 until lines.size) assertTrue(lines[i].timeMs > lines[i - 1].timeMs)
        assertTrue(lines.first().timeMs in 3_000L..18_000L)
        assertTrue(lines.last().timeMs < 200_000L)
    }

    @Test
    fun tooShortOrTooSmallGivesNothing() {
        assertTrue(PlainTiming.estimate(song, 10_000).isEmpty())
        assertTrue(PlainTiming.estimate("only one line", 200_000).isEmpty())
    }

    @Test
    fun geniusJunkLinesAreSkipped() {
        val lines = PlainTiming.estimate("First line here\nYou might also like\nSecond line here\n123Embed", 200_000)
        assertEquals(2, lines.size)
    }

    @Test
    fun headerDetection() {
        assertTrue(PlainTiming.isHeader("[Chorus]"))
        assertFalse(PlainTiming.isHeader("Chorus"))
        assertFalse(PlainTiming.isHeader("[]"))
    }

    @Test
    fun syllableCounting() {
        assertEquals(3.0, PlainTiming.syllables("hello world"), 0.0001)
        assertEquals(1.0, PlainTiming.syllables(""), 0.0001)
    }
}
