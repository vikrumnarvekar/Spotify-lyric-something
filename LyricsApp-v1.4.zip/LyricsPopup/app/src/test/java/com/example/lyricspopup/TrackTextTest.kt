package com.example.lyricspopup

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackTextTest {

    @Test
    fun cleanTitleRemovesTrailingDecorations() {
        assertEquals("Song", TrackText.cleanTitle("Song (feat. X) - Remastered 2011"))
        assertEquals("Song", TrackText.cleanTitle("Song - Live"))
    }

    @Test
    fun cleanTitleKeepsLeadingBrackets() {
        assertEquals("(Don't Fear) The Reaper", TrackText.cleanTitle("(Don't Fear) The Reaper"))
    }

    @Test
    fun cleanTitleNeverReturnsNothing() {
        assertEquals("(Live)", TrackText.cleanTitle("(Live)"))
    }

    @Test
    fun primaryArtistTakesTheFirstOne() {
        assertEquals("A", TrackText.primaryArtist("A, B"))
        assertEquals("A", TrackText.primaryArtist("A; B"))
        assertEquals("Solo", TrackText.primaryArtist("Solo"))
    }

    @Test
    fun recognisesAds() {
        assertTrue(TrackText.isAd("Advertisement", ""))
        assertTrue(TrackText.isAd("Spotify", ""))
        assertFalse(TrackText.isAd("Spotify", "Daft Punk"))
        assertFalse(TrackText.isAd("Song", "Artist"))
    }

    @Test
    fun pickPrefersTimedLyricsOfTheRightLength() {
        val plain = Candidate(200.0, "words", null, false)
        val timed = Candidate(200.5, null, "[00:01.00]x", false)
        assertEquals(timed, TrackText.pick(listOf(plain, timed), 200.0))
    }

    @Test
    fun pickRejectsAFarOffLength() {
        assertNull(TrackText.pick(listOf(Candidate(100.0, "words", null, false)), 200.0))
    }

    @Test
    fun pickKeepsTimingWithinTenSeconds() {
        val r = TrackText.pick(listOf(Candidate(208.0, "words", "[00:01.00]x", false)), 200.0)
        assertNotNull(r)
        assertNotNull(r!!.synced)
    }

    @Test
    fun pickDropsTimingWhenTheCutDiffers() {
        val r = TrackText.pick(listOf(Candidate(212.0, "words", "[00:01.00]x", false)), 200.0)
        assertNotNull(r)
        assertNull(r!!.synced)
    }

    @Test
    fun pickAcceptsAnythingWhenLengthIsUnknown() {
        val r = TrackText.pick(listOf(Candidate(123.0, null, "[00:01.00]x", false)), null)
        assertNotNull(r)
    }

    @Test
    fun pickIgnoresEmptyRecords() {
        assertNull(TrackText.pick(listOf(Candidate(null, "", null, false)), 200.0))
    }

    @Test
    fun sameLengthComparesWithinTolerance() {
        assertTrue(TrackText.sameLength(null, 200_000))
        assertTrue(TrackText.sameLength(200.0, 0))
        assertTrue(TrackText.sameLength(200.0, 201_500))
        assertFalse(TrackText.sameLength(200.0, 210_000))
        assertTrue(TrackText.sameLength(205.0, 200_000, 10.0))
    }

    @Test
    fun geniusTranslationPagesAreRecognised() {
        assertTrue(TrackText.isTranslationArtist("Genius English Translations"))
        assertFalse(TrackText.isTranslationArtist("Genius Romanizations"))
        assertFalse(TrackText.isTranslationArtist("Adele"))
        assertTrue(TrackText.isRomanizationArtist("Genius Romanizations"))
        assertFalse(TrackText.isRomanizationArtist("Adele"))
    }

    @Test
    fun creditLinesAreRemovedFromTimedLyrics() {
        val raw = "[00:00.00]Lyricist : Someone\n[00:00.50]Composer: Someone Else\n[00:10.00]Real line"
        assertEquals("[00:10.00]Real line", TrackText.dropCreditLines(raw))
    }

    @Test
    fun chineseCreditLinesAreRemoved() {
        val raw = "[00:00.00]\u4f5c\u8bcd : X\n[00:01.00]\u4f5c\u66f2 : Y\n[00:10.00]Real line"
        assertEquals("[00:10.00]Real line", TrackText.dropCreditLines(raw))
    }

    @Test
    fun ordinaryLinesStartingWithWrittenAreKept() {
        val raw = "[00:10.00]Written in the stars"
        assertEquals(raw, TrackText.dropCreditLines(raw))
    }
}
