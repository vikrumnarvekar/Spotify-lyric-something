package com.example.lyricspopup

import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class LyricsFollowTest {

    @Test
    fun formatTime() {
        assertEquals("0:00", LyricsFollow.formatTime(0))
        assertEquals("1:01", LyricsFollow.formatTime(61_000))
        assertEquals("0:00", LyricsFollow.formatTime(-5))
        assertEquals("59:59", LyricsFollow.formatTime(3_599_000))
    }

    @Test
    fun positionAdvancesWhilePlaying() {
        assertEquals(1_500L, LyricsFollow.estimatePosition(1_000, 0, 500, 1f, true, 0))
        assertEquals(2_000L, LyricsFollow.estimatePosition(1_000, 0, 500, 2f, true, 0))
    }

    @Test
    fun positionStaysWhilePaused() {
        assertEquals(1_000L, LyricsFollow.estimatePosition(1_000, 0, 500, 1f, false, 0))
    }

    @Test
    fun positionIsCappedAtTheSongLength() {
        assertEquals(1_200L, LyricsFollow.estimatePosition(1_000, 0, 5_000, 1f, true, 1_200))
    }

    @Test
    fun negativePositionBecomesZero() {
        assertEquals(0L, LyricsFollow.estimatePosition(-50, 0, 0, 1f, false, 0))
    }

    @Test
    fun plainFractionStaysBetweenZeroAndOne() {
        assertEquals(0f, LyricsFollow.plainFraction(0, 200_000), 0.0001f)
        assertEquals(1f, LyricsFollow.plainFraction(200_000, 200_000), 0.0001f)
        assertEquals(0f, LyricsFollow.plainFraction(5_000, 0), 0.0001f)
    }

    @Test
    fun buildRecordsWhereEachLineSits() {
        val b = LyricsFollow.build(listOf(LrcLine(0, "Hello"), LrcLine(1_000, ""), LrcLine(2_000, "World")))
        assertEquals("Hello\n\u266A\nWorld", b.text)
        assertArrayEquals(intArrayOf(0, 6, 8), b.starts)
        assertArrayEquals(intArrayOf(5, 7, 13), b.ends)
    }
}
