package com.example.lyricspopup

import kotlin.math.abs

/** A lyrics record returned by the lyrics service. Pure data so matching can be tested on a JVM. */
data class Candidate(
    val durationSec: Double?,
    val plain: String?,
    val synced: String?,
    val instrumental: Boolean
)

/** Text clean-up and matching helpers. No Android classes. */
object TrackText {

    private val TRAILING_BRACKETS = Regex("""\s*[(\[][^)\]]*[)\]]\s*$""")
    private val TRAILING_DASH_SUFFIX = Regex("""\s+-\s+[^-]*$""")

    /**
     * "Song (feat. X) - Remastered 2011" -> "Song".
     * Only trailing decorations are removed, so "(Don't Fear) The Reaper" stays intact.
     */
    fun cleanTitle(title: String): String {
        var t = title.trim()
        // Alternate between the two patterns until nothing changes, so mixed endings like
        // "Song (Live) - 2019 Remaster" are fully cleaned.
        while (true) {
            val next = t.replace(TRAILING_BRACKETS, "").replace(TRAILING_DASH_SUFFIX, "").trim()
            if (next == t) break
            t = next
        }
        return t.ifEmpty { title.trim() }
    }

    /** Spotify joins multiple artists with ", " or ";". Used only as a fallback lookup. */
    fun primaryArtist(artist: String): String =
        artist.split(",", ";").first().trim().ifEmpty { artist.trim() }

    fun isAd(title: String, artist: String): Boolean =
        title.trim().equals("Advertisement", ignoreCase = true) ||
            (artist.isBlank() && title.trim().equals("Spotify", ignoreCase = true))

    /**
     * Choose the best record for a track of [durationSec] seconds.
     * 1) right length + synced lyrics, 2) right length, 3) closest within 10 s (timing kept),
     * 4) closest within 15 s with timing dropped (a different cut would have wrong timestamps).
     */
    fun pick(candidates: List<Candidate>, durationSec: Double?): Candidate? {
        val usable = candidates.filter {
            it.instrumental || !it.plain.isNullOrBlank() || !it.synced.isNullOrBlank()
        }
        if (usable.isEmpty()) return null

        fun close(c: Candidate): Boolean =
            durationSec == null || c.durationSec == null || abs(c.durationSec - durationSec) <= 3.0

        usable.firstOrNull { close(it) && !it.synced.isNullOrBlank() }?.let { return it }
        usable.firstOrNull { close(it) }?.let { return it }

        val nearest = usable
            .filter { it.durationSec != null }
            .minByOrNull { abs(it.durationSec!! - durationSec!!) }
        if (nearest == null) return null
        val diff = abs(nearest.durationSec!! - durationSec!!)
        return when {
            // Usually the same recording with a different fade-out, so the timestamps still fit.
            diff <= 10.0 -> nearest
            // A different cut: the words are right but the timing would be wrong.
            diff <= 15.0 -> nearest.copy(synced = null)
            else -> null
        }
    }

    /**
     * True when a lyrics record's length is within [toleranceSec] of the track's length.
     * Unknown lengths (on either side) count as "can't tell", so they are accepted.
     */
    fun sameLength(matchedSec: Double?, durationMs: Long, toleranceSec: Double = 3.0): Boolean =
        matchedSec == null || durationMs <= 0 || abs(matchedSec - durationMs / 1000.0) <= toleranceSec

    /** Genius files translations under artists like "Genius English Translations". */
    fun isTranslationArtist(name: String): Boolean {
        val n = name.trim().lowercase()
        return n.startsWith("genius ") && !n.contains("romaniz")
    }

    /** "Genius Romanizations": the words written in Latin letters. Acceptable, but only as a last resort. */
    fun isRomanizationArtist(name: String): Boolean {
        val n = name.trim().lowercase()
        return n.startsWith("genius ") && n.contains("romaniz")
    }

    private val LRC_TAGS = Regex("""\[[^\]]*]""")
    private val CREDIT_LINE = Regex(
        """^(\u4f5c\u8bcd|\u4f5c\u66f2|\u7f16\u66f2|\u5236\u4f5c\u4eba|\u4f5c\u8a5e|\u7de8\u66f2|\u8bcd|\u66f2|\u76d1\u5236|\u6df7\u97f3|\u6bcd\u5e26|\u5f55\u97f3|\u7b56\u5212|\u51fa\u54c1|lyrics|lyricist|composer|composed|arranger|arranged|producer|written)\s*(by)?\s*[:\uff1a]""",
        RegexOption.IGNORE_CASE
    )

    /** NetEase puts credit lines ("lyricist : ...") into the timed lyrics; remove them. */
    fun dropCreditLines(lrc: String): String =
        lrc.lineSequence()
            .filterNot { CREDIT_LINE.containsMatchIn(it.replace(LRC_TAGS, "").trim()) }
            .joinToString("\n")
}
