package com.example.lyricspopup

/** Pure helpers for following playback (no Android classes, so they can be unit-tested on a JVM). */
object LyricsFollow {

    class Built(val text: String, val starts: IntArray, val ends: IntArray)

    /** Joins synced lines into one string and records where each line starts and ends. */
    fun build(lines: List<LrcLine>): Built {
        val sb = StringBuilder()
        val starts = IntArray(lines.size)
        val ends = IntArray(lines.size)
        lines.forEachIndexed { i, l ->
            if (i > 0) sb.append('\n')
            starts[i] = sb.length
            sb.append(l.text.ifBlank { "♪" })
            ends[i] = sb.length
        }
        return Built(sb.toString(), starts, ends)
    }

    /** Where playback is now, from the last reported position (Android's PlaybackState model). */
    fun estimatePosition(
        basePos: Long, updatedAt: Long, now: Long, speed: Float, playing: Boolean, durationMs: Long
    ): Long {
        var p = if (basePos < 0) 0L else basePos
        if (playing && now > updatedAt) p += ((now - updatedAt) * speed).toLong()
        if (durationMs > 0 && p > durationMs) p = durationMs
        return if (p < 0) 0L else p
    }

    /** For lyrics without timing: how far down to scroll (0..1); intro/outro are skipped roughly. */
    fun plainFraction(posMs: Long, durMs: Long): Float {
        if (durMs <= 0) return 0f
        val f = posMs.toFloat() / durMs
        return ((f - 0.06f) / 0.86f).coerceIn(0f, 1f)
    }

    fun formatTime(ms: Long): String {
        val total = (if (ms < 0) 0 else ms) / 1000
        return "${total / 60}:${(total % 60).toString().padStart(2, '0')}"
    }
}
