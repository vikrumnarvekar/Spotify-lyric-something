package com.example.lyricspopup

import java.text.Normalizer

/**
 * Writes Hindi (Devanagari) and Japanese kana in English letters, the way the words sound.
 * Kanji and other scripts are left alone here; [toEnglish] can be given a hook for the other scripts.
 *
 * Pure Kotlin/JVM (no Android classes) so it is unit-tested on a plain JVM.
 */
object Romanizer {

    private const val PASS = 0
    private const val DEVA = 1
    private const val KANA = 2
    private const val HAN = 3
    private const val OTHER = 4

    /**
     * @param other converts a run of letters from any other non-Latin script (Korean, Cyrillic, Arabic…);
     *              null leaves them as they are.
     */
    fun toEnglish(text: String, other: ((String) -> String)? = null): String {
        if (text.none { it.code >= 0x0370 }) return text

        val sb = StringBuilder()
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            when (kind(cp)) {
                DEVA -> {
                    val start = i
                    while (i < text.length && kind(text.codePointAt(i)) == DEVA) i += Character.charCount(text.codePointAt(i))
                    sb.append(devanagari(text.substring(start, i)))
                }
                KANA -> {
                    val start = i
                    while (i < text.length && kind(text.codePointAt(i)) == KANA) i += Character.charCount(text.codePointAt(i))
                    val prevHan = sb.isNotEmpty() && isHanChar(sb[sb.length - 1])
                    val prevKanaOut = sb.isNotEmpty() && sb[sb.length - 1].isLetter()
                    if (prevHan) sb.append(' ')
                    sb.append(kana(text.substring(start, i), prevHan || prevKanaOut))
                    if (i < text.length && kind(text.codePointAt(i)) == HAN) sb.append(' ')
                }
                OTHER -> {
                    val start = i
                    while (i < text.length && kind(text.codePointAt(i)) == OTHER) i += Character.charCount(text.codePointAt(i))
                    val run = text.substring(start, i)
                    sb.append(if (other != null) other(run) else run)
                }
                else -> {
                    sb.append(punctuation(cp))
                    i += Character.charCount(cp)
                }
            }
        }
        return sb.toString()
    }

    private fun isHanChar(c: Char) = c.code in 0x4E00..0x9FFF || c.code in 0x3400..0x4DBF || c.code in 0xF900..0xFAFF || c == '々'

    private fun kind(cp: Int): Int = when {
        cp in 0x0900..0x097F -> DEVA
        cp in 0x3041..0x30FF && cp != 0x30FB || cp in 0x31F0..0x31FF || cp in 0xFF66..0xFF9F -> KANA
        cp in 0x4E00..0x9FFF || cp in 0x3400..0x4DBF || cp in 0xF900..0xFAFF || cp == 0x3005 -> HAN
        cp < 0x0370 -> PASS
        else -> if (otherScript(cp)) OTHER else PASS
    }

    /** False once Character.UnicodeScript turned out to be missing (it only exists from Android 7.0). */
    private var scriptApi = true

    /** True for letters of a non-Latin script that is not handled above (Korean, Cyrillic, Arabic...). */
    private fun otherScript(cp: Int): Boolean {
        if (scriptApi) {
            try {
                return when (Character.UnicodeScript.of(cp)) {
                    Character.UnicodeScript.COMMON, Character.UnicodeScript.LATIN,
                    Character.UnicodeScript.INHERITED, Character.UnicodeScript.UNKNOWN -> false
                    else -> true
                }
            } catch (e: LinkageError) {
                scriptApi = false          // older Android: fall back to a plain "is it a letter" check
            } catch (e: Exception) {
                return false
            }
        }
        return Character.isLetter(cp) && cp !in 0x1E00..0x1EFF && cp !in 0xFF21..0xFF5A
    }

    /** Japanese/fullwidth punctuation to plain ASCII. */
    private fun punctuation(cp: Int): String = when (cp) {
        0x3001 -> ", "
        0x3002 -> ". "
        0x30FB -> " "
        0x300C, 0x300D, 0x300E, 0x300F -> "\""
        0x3000 -> " "
        in 0xFF01..0xFF5E -> (cp - 0xFEE0).toChar().toString()
        else -> String(Character.toChars(cp))
    }

    // =====================================================================================
    // Hindi
    // =====================================================================================

    private val CONS = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "ny",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh",
        'स' to "s", 'ह' to "h", 'ळ' to "l",
        // letters that already carry a dot (precomposed)
        'क़' to "q", 'ख़' to "kh", 'ग़' to "gh", 'ज़' to "z",
        'ड़' to "r", 'ढ़' to "rh", 'फ़' to "f", 'य़' to "y"
    )

    private val NUKTA = mapOf(
        'क' to "q", 'ख' to "kh", 'ग' to "gh", 'ज' to "z", 'ड' to "r", 'ढ' to "rh", 'फ' to "f", 'य' to "y"
    )

    private val INDEP = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo", 'ऋ' to "ri",
        'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऍ' to "e"
    )

    private val MATRA = mapOf(
        'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo",
        'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ॉ' to "o", 'ॅ' to "e"
    )

    private const val HALANT = '्'
    private const val NUKTA_SIGN = '़'

    private fun isCons(c: Char) = CONS.containsKey(c)

    private class Syl(var cons: String, val vowel: String, val schwa: Boolean, val conj: Boolean) {
        var nasal = false
        var visarga = false
        var deleted = false
        val hasVowel get() = vowel.isNotEmpty() && !deleted
    }

    /** A run of Devanagari characters: words are romanized, digits and dandas become ASCII. */
    private fun devanagari(run: String): String {
        val out = StringBuilder()
        val word = StringBuilder()
        fun flush() {
            if (word.isNotEmpty()) { out.append(devaWord(word.toString())); word.setLength(0) }
        }
        for (c in run) {
            when {
                c in '०'..'९' -> { flush(); out.append(('0' + (c - '०'))) }
                c == '।' || c == '॥' || c == '॰' -> { flush(); out.append('.') }
                c == 'ॐ' -> { flush(); out.append("om") }
                else -> word.append(c)
            }
        }
        flush()
        return out.toString()
    }

    /** Very common words whose spelling doesn't show how they are said. */
    private val WORD_FIXES = mapOf(
        "हम" to "hum", "यह" to "yeh", "वह" to "woh", "ये" to "ye", "वो" to "woh", "कुछ" to "kuch",
        "तुझे" to "tujhe", "मुझे" to "mujhe", "क्यूँ" to "kyun", "क्यों" to "kyon"
    )

    private fun devaWord(w: String): String {
        WORD_FIXES[w]?.let { return it }
        val syls = ArrayList<Syl>()
        val pendingLiteral = StringBuilder()
        var i = 0
        while (i < w.length) {
            val c = w[i]
            when {
                isCons(c) -> {
                    var cons = CONS[c]!!
                    val first = c
                    i++
                    if (i < w.length && w[i] == NUKTA_SIGN) { cons = NUKTA[c] ?: cons; i++ }
                    var conj = false
                    while (i + 1 < w.length && w[i] == HALANT && isCons(w[i + 1])) {
                        val next = w[i + 1]
                        var nr = CONS[next]!!
                        var j = i + 2
                        if (j < w.length && w[j] == NUKTA_SIGN) { nr = NUKTA[next] ?: nr; j++ }
                        cons = if (!conj && first == 'ज' && next == 'ञ') "gy" else cons + nr
                        conj = true
                        i = j
                    }
                    when {
                        i < w.length && w[i] == HALANT -> { syls.add(Syl(cons, "", false, conj)); i++ }
                        i < w.length && MATRA.containsKey(w[i]) -> { syls.add(Syl(cons, MATRA[w[i]]!!, false, conj)); i++ }
                        else -> syls.add(Syl(cons, "a", true, conj))
                    }
                }
                INDEP.containsKey(c) -> { syls.add(Syl("", INDEP[c]!!, false, false)); i++ }
                c == 'ं' || c == 'ँ' -> {
                    val last = syls.lastOrNull()
                    if (last != null) last.nasal = true else pendingLiteral.append('n')
                    i++
                }
                c == 'ः' -> { syls.lastOrNull()?.visarga = true; i++ }
                else -> i++   // stray nukta / halant / unknown mark
            }
        }
        if (syls.isEmpty()) return pendingLiteral.toString()

        deleteSchwas(syls)

        val sb = StringBuilder()
        for ((idx, s) in syls.withIndex()) {
            val isLast = idx == syls.size - 1
            sb.append(s.cons)
            if (s.hasVowel) sb.append(renderVowel(s, isLast, syls.size == 1))
            if (s.nasal) {
                val nextCons = syls.getOrNull(idx + 1)?.cons ?: ""
                sb.append(if (nextCons.startsWith("p") || nextCons.startsWith("b") || nextCons.startsWith("m")) 'm' else 'n')
            }
            if (s.visarga) sb.append('h')
        }
        return sb.toString()
    }

    /** Hindi drops many inherent "a"s: कमल is "kamal", not "kamala". */
    private fun deleteSchwas(syls: List<Syl>) {
        val last = syls.last()
        if (syls.size > 1 && last.schwa && !last.conj && !last.nasal && !last.visarga) last.deleted = true

        for (i in syls.size - 2 downTo 1) {
            val s = syls[i]
            if (!s.schwa || s.conj || s.nasal || s.visarga) continue
            val prev = syls[i - 1]
            val next = syls[i + 1]
            // between two sounded syllables, and never producing a three-consonant pile-up
            if (prev.hasVowel && !prev.nasal && !prev.visarga && next.hasVowel && !next.conj) s.deleted = true
        }
    }

    private fun renderVowel(s: Syl, isLast: Boolean, single: Boolean): String {
        val finalPos = isLast && !s.nasal && !s.visarga
        return when (s.vowel) {
            "aa" -> if (finalPos && (!single || s.conj)) "a" else "aa"
            "ee" -> if (s.nasal) "i" else if (finalPos) "i" else "ee"
            "oo" -> if (finalPos) "u" else "oo"
            "e" -> if (s.nasal) "ei" else "e"
            else -> s.vowel
        }
    }

    // =====================================================================================
    // Japanese kana
    // =====================================================================================

    private val KANA_TABLE: Map<Char, String> = run {
        val t = """
            あ a い i う u え e お o
            か ka き ki く ku け ke こ ko
            さ sa し shi す su せ se そ so
            た ta ち chi つ tsu て te と to
            な na に ni ぬ nu ね ne の no
            は ha ひ hi ふ fu へ he ほ ho
            ま ma み mi む mu め me も mo
            や ya ゆ yu よ yo
            ら ra り ri る ru れ re ろ ro
            わ wa ゐ i ゑ e を o
            が ga ぎ gi ぐ gu げ ge ご go
            ざ za じ ji ず zu ぜ ze ぞ zo
            だ da ぢ ji づ zu で de ど do
            ば ba び bi ぶ bu べ be ぼ bo
            ぱ pa ぴ pi ぷ pu ぺ pe ぽ po
            ゔ vu
            ぁ a ぃ i ぅ u ぇ e ぉ o ゃ ya ゅ yu ょ yo ゎ wa
        """.trim().split(Regex("\\s+"))
        val m = HashMap<Char, String>()
        var i = 0
        while (i + 1 < t.size) { m[t[i][0]] = t[i + 1]; i += 2 }
        m
    }

    private const val SMALL_VOWELS = "ぁぃぅぇぉ"
    private const val SMALL_Y = "ゃゅょ"

    private fun smallVowel(c: Char): String = when (c) { 'ぁ' -> "a"; 'ぃ' -> "i"; 'ぅ' -> "u"; 'ぇ' -> "e"; else -> "o" }

    /** [attached]: the run follows a letter or a kanji, which decides whether は/へ are particles. */
    private fun kana(run: String, attached: Boolean): String {
        // half-width katakana → full-width (also joins the voicing marks)
        val src = if (run.any { it.code in 0xFF66..0xFF9F }) Normalizer.normalize(run, Normalizer.Form.NFKC) else run

        val h = StringBuilder(src.length)
        val katakana = ArrayList<Boolean>(src.length)
        for (c in src) {
            val code = c.code
            when {
                code in 0x30A1..0x30F6 -> { h.append((code - 0x60).toChar()); katakana.add(true) }
                code == 0x30FB -> { h.append(' '); katakana.add(true) }
                else -> { h.append(c); katakana.add(false) }
            }
        }
        val s = h.toString()
        val n = s.length
        val sb = StringBuilder()

        fun lastVowel(): Char? {
            for (k in sb.length - 1 downTo 0) {
                val ch = sb[k]
                if (ch in "aiueo") return ch
                if (ch.isLetter()) return null
            }
            return null
        }

        // romaji of the syllable starting at [i] and how many kana it uses (no sokuon/ー/ん here)
        fun syllable(i: Int): Pair<String, Int>? {
            val c = s[i]
            val base = KANA_TABLE[c] ?: return null
            if (c in SMALL_VOWELS || c in SMALL_Y) return Pair(base, 1)
            val nx = if (i + 1 < n) s[i + 1] else ' '
            if (nx in SMALL_Y) {
                val y = KANA_TABLE[nx]!!.substring(1)          // a / u / o
                val stem = when (base) {
                    "shi" -> "sh"; "chi" -> "ch"; "ji" -> "j"
                    else -> base.dropLast(1) + "y"
                }
                return Pair(stem + y, 2)
            }
            if (nx in SMALL_VOWELS) {
                val v = smallVowel(nx)
                val stem = when {
                    base == "u" -> "w"
                    base == "i" -> "y"
                    base.length == 1 -> base
                    else -> base.dropLast(1)
                }
                return Pair(stem + v, 2)
            }
            return Pair(base, 1)
        }

        var i = 0
        while (i < n) {
            val c = s[i]
            when {
                c == 'っ' -> {
                    val nxt = if (i + 1 < n) syllable(i + 1) else null
                    val r = nxt?.first
                    if (r != null && r.isNotEmpty() && r[0] in "kstpgzdbhfjcrwmyn") {
                        sb.append(if (r.startsWith("ch")) "t" else r[0].toString())
                    }
                    i++
                }
                c == 'ー' -> { lastVowel()?.let { sb.append(it) }; i++ }
                c == 'ん' -> { sb.append('n'); i++ }
                c == 'は' && !katakana[i] && i == n - 1 && (i > 0 || attached) -> { sb.append("wa"); i++ }
                c == 'へ' && !katakana[i] && i == n - 1 && (i > 0 || attached) -> { sb.append("e"); i++ }
                else -> {
                    val r = syllable(i)
                    if (r == null) { sb.append(c); i++ } else { sb.append(r.first); i += r.second }
                }
            }
        }
        return sb.toString()
    }
}
