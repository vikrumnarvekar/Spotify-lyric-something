package com.example.lyricspopup

import android.os.Build

/**
 * Android's built-in ICU can write many scripts (Korean, Cyrillic, Arabic, Bengali...) in Latin letters.
 * Kanji are skipped because ICU would read them as Chinese. Any failure just leaves the text unchanged.
 *
 * android.icu only exists from Android 7.0 (API 24); on older phones the text is left as it is.
 */
object IcuTranslit {

    private val tr: android.icu.text.Transliterator? by lazy {
        if (Build.VERSION.SDK_INT < 24) {
            null
        } else {
            try {
                android.icu.text.Transliterator.getInstance("[:^Han:] Any-Latin; [:^Han:] Latin-ASCII")
            } catch (e: Throwable) {
                try {
                    android.icu.text.Transliterator.getInstance("Any-Latin; Latin-ASCII")
                } catch (e2: Throwable) {
                    null
                }
            }
        }
    }

    fun transliterate(s: String): String = try { tr?.transliterate(s) ?: s } catch (e: Throwable) { s }
}
