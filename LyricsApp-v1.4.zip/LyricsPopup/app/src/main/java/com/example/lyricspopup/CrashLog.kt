package com.example.lyricspopup

import android.content.Context
import android.util.Log
import java.io.File

/** Saves the last crash to a file so the setup screen can show it (handy when there's no computer). */
object CrashLog {
    private const val FILE = "last_crash.txt"

    private class Catcher(
        private val app: Context,
        private val previous: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            write(app, "Thread ${t.name}\n" + Log.getStackTraceString(e))
            previous?.uncaughtException(t, e)
        }
    }

    fun install(ctx: Context) {
        val current = Thread.getDefaultUncaughtExceptionHandler()
        if (current is Catcher) return
        Thread.setDefaultUncaughtExceptionHandler(Catcher(ctx.applicationContext, current))
    }

    fun record(ctx: Context, e: Throwable) = write(ctx, Log.getStackTraceString(e))

    fun read(ctx: Context): String? = try {
        File(ctx.filesDir, FILE).takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }
    } catch (e: Throwable) { null }

    fun clear(ctx: Context) {
        try { File(ctx.filesDir, FILE).delete() } catch (e: Throwable) {}
    }

    private fun write(ctx: Context, text: String) {
        try { File(ctx.filesDir, FILE).writeText(text.take(6000)) } catch (e: Throwable) {}
    }
}
