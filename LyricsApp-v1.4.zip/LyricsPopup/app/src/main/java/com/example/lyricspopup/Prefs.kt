package com.example.lyricspopup

import android.content.Context
import android.content.SharedPreferences

/** The app's saved settings in one place, so the keys are not repeated as strings around the code. */
object Prefs {
    const val FILE = "prefs"
    const val KEY_TOKEN = "genius_token"
    const val KEY_LANG = "lang_mode"          // "mix" (original scripts) or "english" (romanized)
    const val KEY_OPACITY = "opacity_idx"
    const val KEY_SCALE = "scale"
    const val KEY_SCALE_MODE = "scale_mode"
    const val KEY_COLLAPSED = "collapsed"
    const val KEY_WIN_W = "win_w"
    const val KEY_WIN_H = "win_h"
    const val KEY_WIN_X = "win_x"
    const val KEY_WIN_Y = "win_y"
    const val KEY_BUBBLE_X = "bubble_x"
    const val KEY_BUBBLE_Y = "bubble_y"

    fun of(ctx: Context): SharedPreferences = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun langEnglish(ctx: Context): Boolean = of(ctx).getString(KEY_LANG, "mix") == "english"

    fun token(ctx: Context): String = of(ctx).getString(KEY_TOKEN, "") ?: ""
}
