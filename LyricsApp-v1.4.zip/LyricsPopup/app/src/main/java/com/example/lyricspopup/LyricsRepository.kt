package com.example.lyricspopup

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Future
import java.util.concurrent.FutureTask
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadFactory
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

data class LyricsResult(
    val plain: String?,              // un-timed lyrics, if any
    val synced: List<LrcLine>,       // timed lines (real, or estimated when [estimated] is true)
    val instrumental: Boolean,
    val geniusUrl: String?,          // link to the song on Genius, if matched
    val artUrl: String? = null,      // Genius cover image, used if Spotify gives none
    val error: String? = null,       // set when the lookup failed (e.g. no network)
    val estimated: Boolean = false,  // the timing was guessed from the song length
    val source: String = "",         // which source the lyrics came from
    val matchedDurationSec: Double? = null  // length of the lyrics record that was used, if known
) {
    val hasLyrics get() = synced.isNotEmpty() || !plain.isNullOrBlank()
}

/** Server addresses; only a test points these somewhere else. */
class Hosts(
    val lrclib: String = "https://lrclib.net",
    val ovh: String = "https://api.lyrics.ovh",
    val geniusApi: String = "https://api.genius.com",
    val geniusWeb: String = "https://genius.com",
    val netease: String = "https://music.163.com"
)

/**
 * Looks for lyrics in several places at the same time and shows the best one as soon as it is
 * available (timed lyrics from LRCLIB or NetEase first; otherwise plain text from lyrics.ovh or the
 * Genius song page, with the timing estimated). A better result that arrives later replaces an
 * earlier one. Found lyrics are also kept on disk, so a replayed song loads instantly.
 * For personal use only.
 *
 * Call [fetchProgressive] / [fetch] from a background thread. A lookup can be stopped at any time
 * with [NetSession.cancel] (the song changed, so its answer is no longer wanted).
 */
class LyricsRepository(
    private val hosts: Hosts = Hosts(),
    private val cache: LyricsCache? = null,
    private val geniusToken: () -> String
) {

    private class Found(val source: String, val cand: Candidate, val rank: Int)
    private class Cached(val result: LyricsResult, val at: Long)

    /** What Genius knows about a song: page link, its spelling of title/artist, and the cover image. */
    class GeniusInfo(val url: String, val title: String, val artist: String, val art: String?)

    companion object {
        private const val RANK_LRCLIB_SYNCED = 50
        private const val RANK_NETEASE = 40
        private const val RANK_LRCLIB_PLAIN = 30
        private const val RANK_GENIUS = 25
        private const val RANK_OVH = 20

        private const val GRACE_MS = 600L          // how long a plain result waits for a better one
        private const val LATE_GRACE_MS = 150L     // ...but once the user has waited a while, show it sooner
        private const val LATE_AFTER_MS = 3000L
        private const val OVH_DELAY_MS = 1200L     // lyrics.ovh is slow and plain-only: let the others go first
        private const val POLL_MS = 150L
        private const val OVERALL_MS = 10_000L     // give up after this long
        private const val NEGATIVE_TTL_MS = 180_000L
        private const val MAX_IMAGE_BYTES = 2 * 1024 * 1024
        private const val DISK_LENGTH_TOLERANCE_SEC = 10.0

        private const val BROWSER_UA =
            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"

        private val GENIUS_WEB_HEADERS = mapOf(
            "User-Agent" to BROWSER_UA,
            "Accept" to "application/json, text/plain, */*",
            "Accept-Language" to "en"
        )

        private val ENTITY = Regex("&(#x[0-9a-fA-F]+|#[0-9]+|amp|lt|gt|quot|apos|nbsp);")
    }

    // Two small pools. "Source" tasks wait for "I/O" tasks, never the other way round, so a full
    // pool can never deadlock, and a quick skip through many songs can't pile up threads.
    private val sourcePool: ThreadPoolExecutor = newPool(6, "lyrics-src")
    private val ioPool: ThreadPoolExecutor = newPool(8, "lyrics-io")

    private fun newPool(size: Int, name: String): ThreadPoolExecutor {
        val counter = AtomicInteger()
        val pool = ThreadPoolExecutor(
            size, size, 20L, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>(),
            ThreadFactory { r ->
                val t = Thread(r, name + "-" + counter.incrementAndGet())
                t.isDaemon = true
                t
            }
        )
        pool.allowCoreThreadTimeOut(true)
        return pool
    }

    /** Stops the worker threads. Call when the app is done with this repository. */
    fun shutdown() {
        sourcePool.shutdownNow()
        ioPool.shutdownNow()
    }

    /** Answers already worked out in this run, so the same song isn't looked up twice. */
    private val memory = object : LinkedHashMap<String, Cached>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Cached>?) = size > 40
    }

    // Genius lookups are shared: whoever asks first starts it, everyone else waits for the same answer.
    private val geniusLock = Any()
    private val geniusDone = object : LinkedHashMap<String, GeniusInfo>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, GeniusInfo>?) = size > 40
    }
    private val geniusRunning = HashMap<String, FutureTask<GeniusInfo?>>()

    /** A new, cancellable network session for one lookup. */
    fun newLookup(): NetSession = NetSession()

    /** Blocking convenience wrapper (used by tests). */
    fun fetch(title: String, artist: String, album: String, durationMs: Long): LyricsResult =
        fetchProgressive(title, artist, album, durationMs, NetSession()) { _, _ -> }

    /**
     * Looks the lyrics up and reports progress through [onUpdate] (result, isFinal). The first
     * acceptable result is reported as soon as no better one is likely; a better one may follow.
     * If [net] is cancelled, the lookup stops quietly and [onUpdate] gets no final call.
     * [durationMs] is the track length, or 0 when unknown.
     */
    fun fetchProgressive(
        title: String, artist: String, album: String, durationMs: Long,
        net: NetSession,
        onUpdate: (LyricsResult, Boolean) -> Unit
    ): LyricsResult {
        val key = "$title|$artist|$durationMs"
        val startedAt = System.currentTimeMillis()

        val remembered = synchronized(memory) { memory[key] }
        if (remembered != null &&
            (remembered.result.hasLyrics || remembered.result.instrumental || startedAt - remembered.at < NEGATIVE_TTL_MS)
        ) {
            onUpdate(remembered.result, true)
            return remembered.result
        }

        val stored = cache?.load(title, artist)
        if (stored != null && TrackText.sameLength(stored.cand.durationSec, durationMs, DISK_LENGTH_TOLERANCE_SEC)) {
            val r = toResult(Found(stored.source, stored.cand, stored.rank), durationMs, false, stored.geniusUrl, stored.artUrl)
            synchronized(memory) { memory[key] = Cached(r, startedAt) }
            onUpdate(r, true)
            return r
        }

        val durationSec = if (durationMs > 0) durationMs / 1000.0 else null
        val cleaned = TrackText.cleanTitle(title)
        val primary = TrackText.primaryArtist(artist)
        val geniusFut = geniusFuture(cleaned, primary)

        val queue = LinkedBlockingQueue<Pair<String, Found?>>()
        val pending = HashMap<String, Int>()       // source name -> best rank it could still deliver
        val bestRank = AtomicInteger(0)

        fun launch(name: String, maxRank: Int, task: () -> Found?) {
            pending[name] = maxRank
            sourcePool.execute {
                val r = try {
                    if (net.cancelled || bestRank.get() >= maxRank) null else task()
                } catch (e: Throwable) {
                    null
                }
                queue.add(Pair(name, r))
            }
        }

        launch("lrclib", RANK_LRCLIB_SYNCED) {
            lrclibSource(title, artist, album, durationSec, cleaned, primary, geniusFut, net)
        }
        launch("netease", RANK_NETEASE) { neteaseSource(cleaned, primary, durationSec, net) }
        launch("genius", RANK_GENIUS) { geniusPageSource(geniusFut, net) }
        launch("ovh", RANK_OVH) {
            pause(OVH_DELAY_MS, net)
            if (net.cancelled || bestRank.get() >= RANK_OVH) null else ovhSource(title, artist, cleaned, primary, net)
        }

        fun geniusNow(): GeniusInfo? =
            if (geniusFut.isDone) try { geniusFut.get() } catch (e: Exception) { null } else null

        fun build(f: Found?): LyricsResult {
            val g = geniusNow()
            return toResult(f, durationMs, f == null && net.looksOffline, g?.url, g?.art)
        }

        var best: Found? = null
        var emitted: Found? = null
        var firstAt = 0L
        val deadline = startedAt + OVERALL_MS

        while (pending.isNotEmpty() && !net.cancelled) {
            val now = System.currentTimeMillis()
            if (now >= deadline) break
            val grace = if (now - startedAt > LATE_AFTER_MS) LATE_GRACE_MS else GRACE_MS
            val wait = if (best != null && emitted !== best) {
                (firstAt + grace - now).coerceIn(1L, POLL_MS)
            } else {
                minOf(POLL_MS, deadline - now)
            }
            val r = queue.poll(wait, TimeUnit.MILLISECONDS)
            if (r != null) {
                pending.remove(r.first)
                val f = r.second
                if (f != null && (best == null || f.rank > best.rank)) {
                    if (best == null) firstAt = System.currentTimeMillis()
                    best = f
                    bestRank.set(f.rank)
                }
            }
            val b = best
            if (b != null && emitted !== b) {
                val t = System.currentTimeMillis()
                val graceNow = if (t - startedAt > LATE_AFTER_MS) LATE_GRACE_MS else GRACE_MS
                val higherPossible = pending.values.any { it > b.rank }
                // Show a plain result right away unless a clearly better source may still answer.
                if (!higherPossible || t - firstAt >= graceNow) {
                    emitted = b
                    onUpdate(build(b), false)
                }
            }
            // Nothing pending can beat what is shown: done.
            if (b != null && emitted === b && pending.values.none { it > b.rank }) break
        }

        val userCancelled = net.cancelled
        val complete = pending.isEmpty()
        val finalBest = best
        val result = build(finalBest)

        if (!userCancelled) {
            if (finalBest != null) {
                cache?.save(
                    title, artist,
                    LyricsCache.Entry(finalBest.source, finalBest.rank, finalBest.cand, result.geniusUrl, result.artUrl)
                )
            }
            // Only remember definite answers, so a temporary network problem is retried next time.
            val definite = result.hasLyrics || result.instrumental || (result.error == null && complete && net.failures == 0)
            if (definite) synchronized(memory) { memory[key] = Cached(result, System.currentTimeMillis()) }
            onUpdate(result, true)
        }
        net.cancel()        // stop sources that can no longer win
        return result
    }

    private fun toResult(
        found: Found?, durationMs: Long, networkFailed: Boolean, geniusUrl: String?, artUrl: String?
    ): LyricsResult {
        val cand = found?.cand
        val timed = cand?.synced?.let { LrcParser.parse(it) } ?: emptyList()
        val plain = cand?.plain?.takeIf { it.isNotBlank() }
        var lines = timed
        var estimated = false
        if (timed.isEmpty() && plain != null && durationMs > 0) {
            lines = PlainTiming.estimate(plain, durationMs)
            estimated = lines.isNotEmpty()
        }
        return LyricsResult(
            plain = plain,
            synced = lines,
            instrumental = cand?.instrumental == true,
            geniusUrl = geniusUrl,
            artUrl = artUrl,
            error = if (networkFailed) "Couldn't reach the lyrics service.\nCheck your connection." else null,
            estimated = estimated,
            source = found?.source ?: "",
            matchedDurationSec = cand?.durationSec
        )
    }

    // ---------- Genius (shared lookup) ----------

    /** Genius's page link and spelling of a song. Blocks for up to ~8 s; null when not found. */
    fun geniusInfo(title: String, artist: String): GeniusInfo? {
        val f = geniusFuture(TrackText.cleanTitle(title), TrackText.primaryArtist(artist))
        return try { f.get(8, TimeUnit.SECONDS) } catch (e: Exception) { null }
    }

    private fun geniusFuture(cleaned: String, primary: String): Future<GeniusInfo?> {
        val key = "$cleaned|$primary".lowercase()
        return synchronized(geniusLock) {
            val known = geniusDone[key]
            val running = geniusRunning[key]
            val result: Future<GeniusInfo?>
            if (known != null) {
                val ready = FutureTask<GeniusInfo?>(Callable<GeniusInfo?> { known })
                ready.run()
                result = ready
            } else if (running != null) {
                result = running
            } else {
                val task = object : FutureTask<GeniusInfo?>(Callable<GeniusInfo?> { geniusMatch(cleaned, primary) }) {
                    override fun done() {
                        synchronized(geniusLock) {
                            geniusRunning.remove(key)
                            try {
                                val v = get()
                                if (v != null) geniusDone[key] = v
                            } catch (e: Exception) {
                                // failed or cancelled: nothing to remember
                            }
                        }
                    }
                }
                geniusRunning[key] = task
                ioPool.execute(task)
                result = task
            }
            result
        }
    }

    private fun geniusMatch(title: String, artist: String): GeniusInfo? {
        val net = NetSession()
        val token = geniusToken().trim()
        val q = enc("$title $artist")
        val http = if (token.isEmpty()) {
            net.get("${hosts.geniusWeb}/api/search/song?q=$q", GENIUS_WEB_HEADERS)
        } else {
            net.get("${hosts.geniusApi}/search?q=$q", mapOf("Authorization" to "Bearer $token"))
        }
        val body = http?.body ?: return null
        try {
            val resp = JSONObject(body).getJSONObject("response")
            val hits = if (token.isEmpty()) {
                resp.getJSONArray("sections").getJSONObject(0).getJSONArray("hits")
            } else {
                resp.getJSONArray("hits")
            }
            var romanized: GeniusInfo? = null
            var k = 0
            while (k < hits.length() && k < 8) {
                val r = hits.getJSONObject(k).getJSONObject("result")
                k++
                val owner = r.optJSONObject("primary_artist")?.optString("name", "") ?: ""
                val info = GeniusInfo(
                    url = r.getString("url"),
                    title = r.optString("title", title),
                    artist = owner.ifEmpty { artist },
                    art = r.optString("song_art_image_thumbnail_url", "").takeIf { it.startsWith("http") }
                )
                if (TrackText.isTranslationArtist(owner)) continue      // an English translation, not the lyrics
                if (TrackText.isRomanizationArtist(owner)) {
                    if (romanized == null) romanized = info
                    continue
                }
                return info
            }
            return romanized
        } catch (e: Exception) {
            return null
        }
    }

    /** The text of the Genius song page (the only way to get lyrics Genius has but nobody else does). */
    private fun geniusPageSource(geniusFut: Future<GeniusInfo?>, net: NetSession): Found? {
        val g = try { geniusFut.get(8, TimeUnit.SECONDS) } catch (e: Exception) { null } ?: return null
        if (net.cancelled) return null
        val text = scrapeGeniusPage(g.url, net) ?: return null
        return Found("genius", Candidate(null, text, null, false), RANK_GENIUS)
    }

    // ---------- other sources ----------

    private fun hasText(c: Candidate) = c.instrumental || !c.plain.isNullOrBlank() || !c.synced.isNullOrBlank()

    private fun lrclibSource(
        title: String, artist: String, album: String, durationSec: Double?,
        cleaned: String, primary: String,
        geniusFut: Future<GeniusInfo?>, net: NetSession
    ): Found? {
        fun found(c: Candidate) =
            Found("lrclib", c, if (!c.synced.isNullOrBlank()) RANK_LRCLIB_SYNCED else RANK_LRCLIB_PLAIN)

        // Round 1: the exact lookups and the fuzzy searches all go out at once; an exact hit wins.
        val ecs = ExecutorCompletionService<Candidate?>(ioPool)
        val exactFutures = ArrayList<Future<Candidate?>>()
        for (t in listOf(title, cleaned).distinct()) {
            for (a in listOf(artist, primary).distinct()) {
                val url = lrclibGetUrl(t, a, album, durationSec)
                exactFutures.add(ecs.submit(Callable<Candidate?> { exactLookup(url, net) }))
            }
        }
        val searches = searchesFor(listOf(
            "${hosts.lrclib}/api/search?track_name=${enc(cleaned)}&artist_name=${enc(primary)}",
            "${hosts.lrclib}/api/search?q=${enc("$cleaned $primary")}",
            "${hosts.lrclib}/api/search?q=${enc("$title $artist")}"
        ), net)

        var hit: Candidate? = null
        for (i in 0 until exactFutures.size) {
            if (net.cancelled) return null
            val c = try { ecs.take().get() } catch (e: Exception) { null }
            if (c != null) {
                hit = c
                break
            }
        }
        if (hit != null) {
            for (f in searches) f.cancel(false)
            return found(hit)
        }
        pickFrom(searches, durationSec)?.let { return found(it) }
        if (net.cancelled) return null

        // Round 2: Genius's spelling (it often titles songs differently from Spotify), and the title
        // alone. The title-only search is safe because the track length must match.
        val titleOnly = if (durationSec != null) {
            searchesFor(listOf("${hosts.lrclib}/api/search?q=${enc(cleaned)}"), net)
        } else {
            emptyList()
        }
        val g = try { geniusFut.get(5, TimeUnit.SECONDS) } catch (e: Exception) { null }
        val spelled = if (g != null) {
            searchesFor(listOf(
                "${hosts.lrclib}/api/search?track_name=${enc(g.title)}&artist_name=${enc(g.artist)}",
                "${hosts.lrclib}/api/search?q=${enc("${g.title} ${g.artist}")}"
            ), net)
        } else {
            emptyList()
        }
        return pickFrom(spelled + titleOnly, durationSec)?.let { found(it) }
    }

    /** NetEase Cloud Music: timed lyrics for many songs LRCLIB lacks (including Japanese and Indian pop). */
    private fun neteaseSource(cleaned: String, primary: String, durationSec: Double?, net: NetSession): Found? {
        val headers = mapOf(
            "Referer" to "https://music.163.com/",
            "Cookie" to "appver=2.0.2",
            "User-Agent" to BROWSER_UA
        )
        val search = net.get(
            "${hosts.netease}/api/search/get/web?csrf_token=&s=${enc("$cleaned $primary")}&type=1&offset=0&total=true&limit=8",
            headers
        )
        val body = search?.body ?: return null
        val songs = try { JSONObject(body).getJSONObject("result").getJSONArray("songs") } catch (e: Exception) { return null }

        fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
        fun similar(a: String, b: String): Boolean {
            val x = norm(a)
            val y = norm(b)
            return x.length >= 2 && y.length >= 2 && (x == y || x.contains(y) || y.contains(x))
        }

        var bestId = 0L
        var bestDiff = Double.MAX_VALUE
        var bestDur: Double? = null
        for (k in 0 until songs.length()) {
            val s = try { songs.getJSONObject(k) } catch (e: Exception) { continue }
            val id = s.optLong("id", 0L)
            if (id == 0L) continue
            if (!similar(s.optString("name", ""), cleaned)) continue
            val dur = s.optLong("duration", 0L).takeIf { it > 0 }?.let { it / 1000.0 }
            var artistOk = false
            val arr = s.optJSONArray("artists")
            if (arr != null) for (j in 0 until arr.length()) {
                val nm = try { arr.getJSONObject(j).optString("name", "") } catch (e: Exception) { "" }
                if (similar(nm, primary)) artistOk = true
            }
            val diff = if (durationSec != null && dur != null) Math.abs(dur - durationSec) else if (artistOk) 2.0 else Double.MAX_VALUE
            val accept = (durationSec != null && dur != null && diff <= 4.0) || (artistOk && (dur == null || durationSec == null || diff <= 6.0))
            if (accept && diff < bestDiff) {
                bestDiff = diff
                bestId = id
                bestDur = dur
            }
        }
        if (bestId == 0L) return null

        val lyr = net.get("${hosts.netease}/api/song/lyric?id=$bestId&lv=1&kv=1&tv=-1", headers)?.body ?: return null
        val raw = try { JSONObject(lyr).optJSONObject("lrc")?.optString("lyric", "") ?: "" } catch (e: Exception) { "" }
        val text = TrackText.dropCreditLines(raw)
        if (LrcParser.parse(text).size < 4) return null
        return Found("netease", Candidate(bestDur, null, text, false), RANK_NETEASE)
    }

    private fun ovhSource(title: String, artist: String, cleaned: String, primary: String, net: NetSession): Found? {
        val pairs = listOf(Pair(primary, cleaned), Pair(artist, title)).distinct()
        val tasks: List<() -> String?> = pairs.map { p -> { ovhLookup(p.first, p.second, net) } }
        val txt = firstNonNull(tasks, net) ?: return null
        return Found("ovh", Candidate(null, txt, null, false), RANK_OVH)
    }

    private fun ovhLookup(artist: String, title: String, net: NetSession): String? {
        val body = net.get("${hosts.ovh}/v1/${seg(artist)}/${seg(title)}")?.body ?: return null
        val txt = try { JSONObject(body).optString("lyrics", "") } catch (e: Exception) { "" }
        return txt.trim().takeIf { it.isNotBlank() }
    }

    // ---------- helpers ----------

    private fun <T> io(task: () -> T): Future<T> = ioPool.submit(Callable<T> { task() })

    /** Runs the tasks at the same time and returns the first non-null answer. */
    private fun <T : Any> firstNonNull(tasks: List<() -> T?>, net: NetSession): T? {
        if (tasks.isEmpty()) return null
        val ecs = ExecutorCompletionService<T?>(ioPool)
        val futures = ArrayList<Future<T?>>()
        for (t in tasks) {
            futures.add(ecs.submit(Callable<T?> { try { t() } catch (e: Exception) { null } }))
        }
        try {
            for (i in 0 until tasks.size) {
                if (net.cancelled) return null
                val r = try { ecs.take().get() } catch (e: Exception) { null }
                if (r != null) return r
            }
            return null
        } finally {
            for (f in futures) f.cancel(false)
        }
    }

    private fun pause(ms: Long, net: NetSession) {
        var left = ms
        while (left > 0 && !net.cancelled) {
            val step = if (left < 100L) left else 100L
            try { Thread.sleep(step) } catch (e: InterruptedException) { return }
            left -= step
        }
    }

    private fun exactLookup(url: String, net: NetSession): Candidate? {
        val body = net.get(url)?.body ?: return null
        return try { toCandidate(JSONObject(body)).takeIf { hasText(it) } } catch (e: Exception) { null }
    }

    private fun searchesFor(urls: List<String>, net: NetSession): List<Future<List<Candidate>>> =
        urls.distinct().map { u -> io { searchList(u, net) } }

    private fun searchList(url: String, net: NetSession): List<Candidate> {
        val body = net.get(url)?.body ?: return emptyList()
        val arr = try { JSONArray(body) } catch (e: Exception) { return emptyList() }
        val out = ArrayList<Candidate>()
        for (i in 0 until arr.length()) {
            try { out.add(toCandidate(arr.getJSONObject(i))) } catch (e: Exception) { }
        }
        return out
    }

    /** Waits for the searches (they run at the same time), then picks the best record across all of them. */
    private fun pickFrom(futures: List<Future<List<Candidate>>>, durationSec: Double?): Candidate? {
        val all = ArrayList<Candidate>()
        for (f in futures) {
            try { all.addAll(f.get()) } catch (e: Exception) { }
        }
        return TrackText.pick(all, durationSec)
    }

    private fun lrclibGetUrl(title: String, artist: String, album: String, durationSec: Double?): String {
        val sb = StringBuilder("${hosts.lrclib}/api/get?track_name=${enc(title)}&artist_name=${enc(artist)}")
        if (album.isNotBlank()) sb.append("&album_name=").append(enc(album))
        if (durationSec != null && durationSec in 1.0..3600.0) sb.append("&duration=").append(durationSec.toInt())
        return sb.toString()
    }

    private fun toCandidate(o: JSONObject) = Candidate(
        durationSec = if (o.has("duration") && !o.isNull("duration")) o.optDouble("duration") else null,
        plain = o.optString("plainLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        synced = o.optString("syncedLyrics", "").takeIf { it.isNotBlank() && it != "null" },
        instrumental = o.optBoolean("instrumental", false)
    )

    /** Removes nested <div data-exclude-from-selection> blocks (Genius puts blurbs inside the lyrics). */
    private fun stripExcluded(input: String): String {
        var s = input
        while (true) {
            val at = s.indexOf("data-exclude-from-selection=\"true\"")
            if (at == -1) return s
            val start = s.lastIndexOf("<div", at)
            if (start == -1) return s
            var depth = 0
            var pos = start
            var end = -1
            while (pos < s.length) {
                val o = s.indexOf("<div", pos)
                val c = s.indexOf("</div>", pos)
                if (c == -1) break
                if (o != -1 && o < c) {
                    depth++
                    pos = o + 4
                } else {
                    depth--
                    pos = c + 6
                    if (depth == 0) {
                        end = pos
                        break
                    }
                }
            }
            if (end == -1) return s.substring(0, start)
            s = s.substring(0, start) + s.substring(end)
        }
    }

    /**
     * Fetches the Genius song page and extracts lyrics from data-lyrics-container divs.
     * Returns null if the page could not be fetched or no lyrics container was found.
     */
    private fun scrapeGeniusPage(url: String, net: NetSession): String? {
        val http = net.get(url, mapOf("User-Agent" to BROWSER_UA, "Accept-Language" to "en")) ?: return null
        val html = http.body ?: return null
        val sb = StringBuilder()
        var searchFrom = 0
        while (true) {
            val attrIdx = html.indexOf("data-lyrics-container=\"true\"", searchFrom)
            if (attrIdx == -1) break
            val openTagEnd = html.indexOf('>', attrIdx)
            if (openTagEnd == -1) break
            var depth = 1
            var pos = openTagEnd + 1
            var contentEnd = -1
            while (pos < html.length && depth > 0) {
                val nextOpenDiv = html.indexOf("<div", pos)
                val nextCloseDiv = html.indexOf("</div>", pos)
                if (nextCloseDiv == -1) break
                if (nextOpenDiv != -1 && nextOpenDiv < nextCloseDiv) {
                    depth++
                    pos = nextOpenDiv + 4
                } else {
                    depth--
                    if (depth == 0) contentEnd = nextCloseDiv
                    pos = nextCloseDiv + 6
                }
            }
            if (contentEnd != -1) {
                sb.append(stripExcluded(html.substring(openTagEnd + 1, contentEnd))).append("\n")
            }
            searchFrom = if (contentEnd != -1) contentEnd + 6 else openTagEnd + 1
        }
        if (sb.isEmpty()) return null
        val noTags = sb.toString()
            .replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), "\n")
            .replace(Regex("<[^>]+>"), "")
        return decodeEntities(noTags)
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
            .takeIf { it.isNotEmpty() }
    }

    /** Turns &amp; &#x27; &#8217; and friends into the characters they stand for, in a single pass. */
    private fun decodeEntities(s: String): String = ENTITY.replace(s) { m ->
        val g = m.groupValues[1]
        try {
            when {
                g == "amp" -> "&"
                g == "lt" -> "<"
                g == "gt" -> ">"
                g == "quot" -> "\""
                g == "apos" -> "'"
                g == "nbsp" -> " "
                g.startsWith("#x") -> String(Character.toChars(g.substring(2).toInt(16)))
                else -> String(Character.toChars(g.substring(1).toInt()))
            }
        } catch (e: Exception) {
            m.value
        }
    }

    /** Downloads a small image (shrunk to a thumbnail); null on any failure. */
    fun fetchBitmap(url: String): Bitmap? {
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 5000
                c.readTimeout = 8000
                c.setRequestProperty("User-Agent", NetSession.USER_AGENT)
                LegacyTls.prepare(c)
                val bytes = c.inputStream.use { it.readBytes() }
                if (bytes.size > MAX_IMAGE_BYTES) return null
                return decodeSampled(bytes, 256)
            } finally {
                try { c.disconnect() } catch (e: Throwable) { }
            }
        } catch (e: Exception) {
            return null
        }
    }

    private fun decodeSampled(bytes: ByteArray, target: Int): Bitmap? {
        val bounds = BitmapFactory.Options()
        bounds.inJustDecodeBounds = true
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= target && bounds.outHeight / (sample * 2) >= target) sample *= 2
        val opts = BitmapFactory.Options()
        opts.inSampleSize = sample
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** URL-encode one path segment (spaces must be %20 in a path, not +). */
    private fun seg(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")
}
