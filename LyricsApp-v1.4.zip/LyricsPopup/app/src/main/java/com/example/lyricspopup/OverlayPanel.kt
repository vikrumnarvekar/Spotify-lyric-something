package com.example.lyricspopup

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Space
import android.widget.TextView
import kotlin.math.abs

/**
 * The floating window (cover, title, buttons, seek bar, the lyrics area) and the small bubble it
 * collapses into. Dragging, resizing and zooming live here; what happens when a button is pressed
 * is reported through [Events].
 */
class OverlayPanel(
    private val ctx: Context,
    private val wm: WindowManager,
    private val lyrics: LyricsDisplay,
    private val events: Events
) {

    interface Events {
        fun onPrevious()
        fun onNext()
        fun onPlayPause()
        fun onSeek(ms: Long)
        fun onOpenGenius()
        fun onClose()
        fun onResetSync()

        /** The full window is showing (true) or only the bubble (false). */
        fun onVisibilityChanged(panelVisible: Boolean)
    }

    companion object {
        /** Background opacity steps, cycled by the half-filled circle button (higher = more solid). */
        private val ALPHAS = intArrayOf(0x26, 0x4D, 0x80, 0xCC)
        private const val MIN_SCALE = 0.6f
        private const val MAX_SCALE = 2.2f
    }

    private var uiScale = 1f
    private var scaleMode = false          // false: grip resizes the window only; true: grip zooms everything
    private var controlsCollapsed = false
    private var opacityIdx = 1
    private var seeking = false
    private var panelAdded = false
    private var bubbleAdded = false

    /** True once a cover picture is showing. */
    var hasCover = false
        private set

    private lateinit var frame: FrameLayout
    private lateinit var panelRoot: LinearLayout
    private lateinit var bubble: TextView
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private lateinit var panelBg: GradientDrawable

    private lateinit var coverView: ImageView
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeNow: TextView
    private lateinit var timeTotal: TextView
    private lateinit var playBtn: IconView
    private lateinit var prevBtn: IconView
    private lateinit var nextBtn: IconView
    private lateinit var collapseBtn: IconView
    private lateinit var seekRow: LinearLayout
    private lateinit var modeChip: TextView
    private lateinit var grip: TextView

    init {
        buildPanel()
        buildBubble()
    }

    // ---------- what the rest of the app can do ----------

    fun show() {
        showPanel()
    }

    fun showBubble() {
        saveLayoutPrefs()
        if (panelAdded) {
            removeWindow(frame)
            panelAdded = false
        }
        if (!bubbleAdded) bubbleAdded = addWindow(bubble, bubbleParams)
        events.onVisibilityChanged(false)
    }

    fun destroy() {
        saveLayoutPrefs()
        if (panelAdded) removeWindow(frame)
        if (bubbleAdded) removeWindow(bubble)
        panelAdded = false
        bubbleAdded = false
    }

    /** The screen was rotated or resized: keep the window and bubble on screen. */
    fun onScreenChanged() {
        val dm = ctx.resources.displayMetrics
        panelParams.width = clamp(panelParams.width, minOf(dp(150), dm.widthPixels), dm.widthPixels)
        panelParams.height = clamp(panelParams.height, minOf(dp(150), dm.heightPixels), dm.heightPixels)
        clampPosition(panelParams)
        clampPosition(bubbleParams)
        applyLayout()
        if (bubbleAdded) updateWindow(bubble, bubbleParams)
    }

    fun setTrack(title: String, artist: String) {
        titleView.text = title
        artistView.text = artist
    }

    fun setArtist(artist: String) {
        artistView.text = artist
    }

    fun setCover(b: Bitmap) {
        coverView.setImageBitmap(b)
        hasCover = true
    }

    fun clearCover() {
        coverView.setImageDrawable(null)
        hasCover = false
    }

    fun setPlaying(playing: Boolean) {
        val kind = if (playing) IconView.PAUSE else IconView.PLAY
        if (playBtn.kind != kind) {
            playBtn.kind = kind
            playBtn.invalidate()
        }
    }

    fun updateProgress(posMs: Long, durMs: Long) {
        seek.isEnabled = durMs > 0
        if (durMs > 0) {
            if (seek.max != durMs.toInt()) seek.max = durMs.toInt()
            timeTotal.text = LyricsFollow.formatTime(durMs)
            if (!seeking) {
                seek.progress = posMs.toInt().coerceIn(0, seek.max)
                timeNow.text = LyricsFollow.formatTime(posMs)
            }
        } else {
            timeTotal.text = "0:00"
            if (!seeking) {
                seek.progress = 0
                timeNow.text = "0:00"
            }
        }
    }

    // ---------- building ----------

    private fun dp(v: Int) = Ui.dp(ctx, v)

    @Suppress("DEPRECATION")
    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE

    private fun clamp(v: Int, lo: Int, hi: Int): Int = if (v < lo) lo else if (v > hi) hi else v

    private fun applyOpacity() {
        val a = ALPHAS[opacityIdx]
        panelBg.setColors(intArrayOf(Color.argb(a, 34, 36, 46), Color.argb(a, 8, 9, 14)))
    }

    private fun buildPanel() {
        val dm = ctx.resources.displayMetrics
        val sp = Prefs.of(ctx)
        opacityIdx = sp.getInt(Prefs.KEY_OPACITY, 1).coerceIn(0, ALPHAS.size - 1)

        panelBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, 0)).apply {
            cornerRadius = dp(26).toFloat()
            setStroke(dp(1), Color.argb(60, 255, 255, 255))
        }
        applyOpacity()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding(dp(14), dp(12), dp(14), dp(4))
        }

        // header: cover | title + artist | G  v  (o)  -  x
        collapseBtn = IconView(ctx, IconView.CHEV_DOWN)
        coverView = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                setColor(Color.argb(50, 255, 255, 255))
                cornerRadius = dp(10).toFloat()
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: android.graphics.Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, dp(10).toFloat())
                }
            }
        }
        titleView = TextView(ctx).apply {
            text = "Waiting for Spotify\u2026"
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
        }
        artistView = TextView(ctx).apply {
            setTextColor(Ui.GREEN)
            textSize = 12.5f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
        }
        val titleBox = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView)
            addView(artistView)
        }
        collapseBtn.background = chipBg()
        collapseBtn.contentDescription = "Hide or show the player controls"
        collapseBtn.setOnClickListener {
            controlsCollapsed = !controlsCollapsed
            applyCollapsed()
            saveLayoutPrefs()
        }
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(coverView, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
            addView(titleBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(textChip("G", "Open this song on Genius") { events.onOpenGenius() }, chipParams())
            addView(collapseBtn, chipParams())
            addView(iconChip(IconView.OPACITY, "Change transparency") {
                opacityIdx = (opacityIdx + 1) % ALPHAS.size
                Prefs.of(ctx).edit().putInt(Prefs.KEY_OPACITY, opacityIdx).apply()
                applyOpacity()
            }, chipParams())
            addView(iconChip(IconView.MINUS, "Shrink to a bubble") { showBubble() }, chipParams())
            addView(iconChip(IconView.CLOSE, "Close") { events.onClose() }, chipParams())
        }

        // seek bar row
        timeNow = timeLabel()
        timeTotal = timeLabel()
        seek = SeekBar(ctx).apply {
            max = 1
            progressTintList = ColorStateList.valueOf(Ui.GREEN)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(80, 255, 255, 255))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) timeNow.text = LyricsFollow.formatTime(p.toLong())
                }

                override fun onStartTrackingTouch(sb: SeekBar) {
                    seeking = true
                }

                override fun onStopTrackingTouch(sb: SeekBar) {
                    seeking = false
                    events.onSeek(sb.progress.toLong())
                }
            })
        }
        seekRow = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(timeNow)
            addView(seek, LinearLayout.LayoutParams(0, dp(32), 1f))
            addView(timeTotal)
        }

        // controls row: [mode] prev play next [grip]
        prevBtn = IconView(ctx, IconView.PREV).apply {
            contentDescription = "Previous song"
            setOnClickListener { events.onPrevious() }
        }
        playBtn = IconView(ctx, IconView.PLAY).apply {
            contentDescription = "Play or pause"
            setOnClickListener { events.onPlayPause() }
        }
        nextBtn = IconView(ctx, IconView.NEXT).apply {
            contentDescription = "Next song"
            setOnClickListener { events.onNext() }
        }

        // What the corner grip does is chosen by the chip on its left:
        //   Window = change the window size only (text stays the same size, more/less lyrics fit)
        //   Scale  = zoom the whole popup (window, text and buttons grow/shrink together)
        modeChip = TextView(ctx).apply {
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = GradientDrawable().apply { cornerRadius = dp(12).toFloat() }
            setOnClickListener {
                scaleMode = !scaleMode
                applyMode()
                saveLayoutPrefs()
                Ui.toast(
                    ctx,
                    if (scaleMode) "Scale: dragging \u25E2 zooms everything" else "Window: dragging \u25E2 resizes only"
                )
            }
        }
        grip = TextView(ctx).apply {
            text = "\u25E2"
            textSize = 20f
            gravity = Gravity.CENTER
        }
        var gW = 0
        var gH = 0
        var gX = 0f
        var gY = 0f
        var gS = 1f
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    gW = panelParams.width
                    gH = panelParams.height
                    gX = e.rawX
                    gY = e.rawY
                    gS = uiScale
                }
                MotionEvent.ACTION_MOVE -> {
                    val sw = ctx.resources.displayMetrics.widthPixels
                    val sh = ctx.resources.displayMetrics.heightPixels
                    val dx = e.rawX - gX
                    val dy = e.rawY - gY
                    if (scaleMode) {
                        // zoom: window and content change by the same ratio, so the layout stays identical
                        var r = (((gW + dx) / gW) + ((gH + dy) / gH)) / 2f
                        val rMin = MIN_SCALE / gS
                        val rMax = minOf(sw.toFloat() / gW, sh.toFloat() / gH, MAX_SCALE / gS)
                        r = r.coerceAtLeast(rMin).coerceAtMost(rMax)
                        uiScale = gS * r
                        panelParams.width = (gW * r).toInt()
                        panelParams.height = (gH * r).toInt()
                    } else {
                        // resize: same zoom, just a bigger or smaller window
                        val minW = (dp(190) * uiScale).toInt()
                        val minH = (dp(150) * uiScale).toInt()
                        panelParams.width = (gW + dx).toInt().coerceAtLeast(minW).coerceAtMost(sw)
                        panelParams.height = (gH + dy).toInt().coerceAtLeast(minH).coerceAtMost(sh)
                    }
                    applyLayout()
                }
                MotionEvent.ACTION_UP -> saveLayoutPrefs()
            }
            true
        }
        val controls = LinearLayout(ctx).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(modeChip, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(Space(ctx), LinearLayout.LayoutParams(0, dp(1), 1f))
            addView(prevBtn, LinearLayout.LayoutParams(dp(48), dp(40)))
            addView(playBtn, LinearLayout.LayoutParams(dp(56), dp(40)))
            addView(nextBtn, LinearLayout.LayoutParams(dp(48), dp(40)))
            addView(Space(ctx), LinearLayout.LayoutParams(0, dp(1), 1f))
            addView(grip, LinearLayout.LayoutParams(dp(48), dp(40)))
        }

        val divider = View(ctx).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) }
        val bottomLine = View(ctx).apply { setBackgroundColor(Color.argb(40, 255, 255, 255)) }

        root.addView(header)
        root.addView(divider, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)).apply {
            topMargin = dp(8)
        })
        root.addView(lyrics.view, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(bottomLine, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1)))
        root.addView(seekRow)
        root.addView(controls)

        uiScale = sp.getFloat(Prefs.KEY_SCALE, 1f).coerceAtLeast(MIN_SCALE).coerceAtMost(MAX_SCALE)
        scaleMode = sp.getBoolean(Prefs.KEY_SCALE_MODE, false)
        controlsCollapsed = sp.getBoolean(Prefs.KEY_COLLAPSED, false)
        val w = clamp(
            sp.getInt(Prefs.KEY_WIN_W, (dm.widthPixels * 0.9f).toInt()),
            minOf(dp(150), dm.widthPixels), dm.widthPixels
        )
        val h = clamp(
            sp.getInt(Prefs.KEY_WIN_H, (dm.heightPixels * 0.6f).toInt()),
            minOf(dp(150), dm.heightPixels), dm.heightPixels
        )
        panelParams = WindowManager.LayoutParams(
            w, h,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt(Prefs.KEY_WIN_X, (dm.widthPixels * 0.05f).toInt())
            y = sp.getInt(Prefs.KEY_WIN_Y, dp(100))
        }
        clampPosition(panelParams)

        // The window is a plain frame; the real UI inside is laid out at (window size / zoom) and then
        // zoomed, so "Window" resizing changes the layout and "Scale" zoom keeps it identical.
        frame = FrameLayout(ctx)
        frame.addView(root, FrameLayout.LayoutParams(1, 1))
        panelRoot = root

        makeDraggable(titleBox, panelParams, onDouble = { showBubble() }, onLong = { events.onResetSync() }) { frame }
        makeDraggable(coverView, panelParams, onDouble = { showBubble() }) { frame }
        applyLayout()
        applyMode()
        applyCollapsed()
    }

    private fun buildBubble() {
        val sp = Prefs.of(ctx)
        val circle = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.argb(235, 30, 215, 96))
        }
        bubble = TextView(ctx).apply {
            text = "\u266A"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER
            background = circle
            elevation = dp(6).toFloat()
            contentDescription = "Show the lyrics window"
        }
        bubbleParams = WindowManager.LayoutParams(
            dp(56), dp(56), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = sp.getInt(Prefs.KEY_BUBBLE_X, dp(12))
            y = sp.getInt(Prefs.KEY_BUBBLE_Y, dp(200))
        }
        clampPosition(bubbleParams)
        makeDraggable(bubble, bubbleParams, onTap = { showPanel() }) { bubble }
    }

    // ---------- layout ----------

    /** Lay the UI out at window size / zoom, then zoom it, so the window always shows exactly [panelParams]. */
    private fun applyLayout() {
        val root = panelRoot
        val lp = root.layoutParams as FrameLayout.LayoutParams
        lp.width = (panelParams.width / uiScale).toInt()
        lp.height = (panelParams.height / uiScale).toInt()
        root.layoutParams = lp
        root.pivotX = 0f
        root.pivotY = 0f
        root.scaleX = uiScale
        root.scaleY = uiScale
        lyrics.requestRecenter()
        if (panelAdded) updateWindow(frame, panelParams)
    }

    private fun applyMode() {
        modeChip.text = if (scaleMode) "Scale" else "Window"
        modeChip.setTextColor(if (scaleMode) Ui.GREEN else Ui.SOFT)
        (modeChip.background as GradientDrawable)
            .setStroke(dp(1), if (scaleMode) Ui.GREEN else Color.argb(90, 255, 255, 255))
        grip.setTextColor(if (scaleMode) Ui.GREEN else Color.argb(150, 255, 255, 255))
    }

    private fun applyCollapsed() {
        val v = if (controlsCollapsed) View.GONE else View.VISIBLE
        seekRow.visibility = v
        prevBtn.visibility = v
        playBtn.visibility = v
        nextBtn.visibility = v
        collapseBtn.kind = if (controlsCollapsed) IconView.CHEV_UP else IconView.CHEV_DOWN
        collapseBtn.invalidate()
        lyrics.requestRecenter()
    }

    private fun saveLayoutPrefs() {
        try {
            Prefs.of(ctx).edit()
                .putInt(Prefs.KEY_WIN_W, panelParams.width).putInt(Prefs.KEY_WIN_H, panelParams.height)
                .putInt(Prefs.KEY_WIN_X, panelParams.x).putInt(Prefs.KEY_WIN_Y, panelParams.y)
                .putInt(Prefs.KEY_BUBBLE_X, bubbleParams.x).putInt(Prefs.KEY_BUBBLE_Y, bubbleParams.y)
                .putFloat(Prefs.KEY_SCALE, uiScale)
                .putBoolean(Prefs.KEY_SCALE_MODE, scaleMode)
                .putBoolean(Prefs.KEY_COLLAPSED, controlsCollapsed)
                .apply()
        } catch (e: Throwable) {
            // settings are a convenience only
        }
    }

    /** Keeps at least a thumb-sized part of a window on screen, so it can never be dragged away for good. */
    private fun clampPosition(p: WindowManager.LayoutParams) {
        val dm = ctx.resources.displayMetrics
        val visible = minOf(dp(72), p.width)
        p.x = clamp(p.x, visible - p.width, dm.widthPixels - visible)
        p.y = clamp(p.y, 0, dm.heightPixels - minOf(dp(72), p.height))
    }

    // ---------- windows ----------

    private fun showPanel() {
        if (bubbleAdded) {
            removeWindow(bubble)
            bubbleAdded = false
        }
        if (!panelAdded) panelAdded = addWindow(frame, panelParams)
        lyrics.requestRecenter()
        events.onVisibilityChanged(panelAdded)
    }

    private fun addWindow(v: View, p: WindowManager.LayoutParams): Boolean {
        return try {
            wm.addView(v, p)
            true
        } catch (e: Exception) {
            Ui.toast(ctx, "Couldn't show the lyrics window. Check \"Display over other apps\".")
            false
        }
    }

    private fun removeWindow(v: View) {
        try { wm.removeView(v) } catch (e: Exception) { }
    }

    private fun updateWindow(v: View, p: WindowManager.LayoutParams) {
        try { wm.updateViewLayout(v, p) } catch (e: Exception) { }
    }

    // ---------- small view helpers ----------

    private fun timeLabel() = TextView(ctx).apply {
        text = "0:00"
        textSize = 11f
        setTextColor(Ui.SOFT)
        gravity = Gravity.CENTER
        minWidth = dp(36)
        setShadowLayer(dp(2).toFloat(), 0f, dp(1).toFloat(), Color.argb(190, 0, 0, 0))
    }

    private fun chipBg() = GradientDrawable().apply {
        setColor(Color.argb(42, 255, 255, 255))
        cornerRadius = dp(10).toFloat()
    }

    private fun chipParams() =
        LinearLayout.LayoutParams(dp(34), dp(30)).apply { leftMargin = dp(4) }

    private fun iconChip(kind: Int, description: String, onClick: () -> Unit) = IconView(ctx, kind).apply {
        background = chipBg()
        contentDescription = description
        setOnClickListener { onClick() }
    }

    private fun textChip(label: String, description: String, onClick: () -> Unit) = TextView(ctx).apply {
        text = label
        textSize = 14f
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(Color.argb(235, 255, 255, 255))
        gravity = Gravity.CENTER
        background = chipBg()
        contentDescription = description
        setOnClickListener { onClick() }
    }

    /**
     * Drags the window by touching [handle]; a tiny movement counts as a tap. A double tap, or a long
     * press, can trigger their own actions. The window can't be dragged completely off the screen.
     */
    private fun makeDraggable(
        handle: View,
        params: WindowManager.LayoutParams,
        onTap: (() -> Unit)? = null,
        onDouble: (() -> Unit)? = null,
        onLong: (() -> Unit)? = null,
        windowView: () -> View
    ) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false
        var longPressed = false
        val detector = if (onDouble == null && onLong == null) null else GestureDetector(
            ctx, object : GestureDetector.SimpleOnGestureListener() {
                override fun onDoubleTap(e: MotionEvent): Boolean {
                    onDouble?.invoke()
                    return true
                }

                override fun onLongPress(e: MotionEvent) {
                    if (!moved) {
                        longPressed = true
                        onLong?.invoke()
                    }
                }
            })
        handle.setOnTouchListener { v, e ->
            detector?.onTouchEvent(e)
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = e.rawX
                    touchY = e.rawY
                    moved = false
                    longPressed = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - touchX).toInt()
                    val dy = (e.rawY - touchY).toInt()
                    if (abs(dx) > dp(4) || abs(dy) > dp(4)) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    clampPosition(params)
                    updateWindow(windowView(), params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        saveLayoutPrefs()
                    } else if (!longPressed) {
                        if (onTap != null) onTap() else v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
    }
}
