package com.example.lyricspopup

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler

/** Watches Spotify's media session: what is playing, where in the song, and the transport buttons. */
class NowPlaying(context: Context, private val main: Handler, private val events: Events) {

    interface Events {
        /** Spotify's session appeared (true) or went away (false). */
        fun onAttached(attached: Boolean)

        /** The track info changed; may be a repeat of the same track with more details filled in. */
        fun onMetadata(md: MediaMetadata?)

        fun onPlaybackChanged()
    }

    companion object {
        const val SPOTIFY = "com.spotify.music"
        private const val SEEK_HOLD_MS = 1500L
    }

    private val msm = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerComponent = ComponentName(context, MediaListenerService::class.java)

    private var controller: MediaController? = null
    private var playbackState: PlaybackState? = null
    private var pendingSeekPos = 0L
    private var pendingSeekAt = -10_000L

    val isPlaying: Boolean get() = playbackState?.state == PlaybackState.STATE_PLAYING

    /** Current track info straight from Spotify (an IPC call, so don't ask more often than needed). */
    val metadata: MediaMetadata? get() = controller?.metadata

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            events.onMetadata(metadata)
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            playbackState = state
            events.onPlaybackChanged()
        }
    }

    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { attach(it) }

    /** Starts watching. Returns false when notification access has not been granted. */
    fun start(): Boolean {
        return try {
            msm.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent, main)
            attach(msm.getActiveSessions(listenerComponent))
            true
        } catch (e: SecurityException) {
            false
        }
    }

    fun stop() {
        try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun attach(controllers: List<MediaController>?) {
        val spotify = controllers?.firstOrNull { it.packageName == SPOTIFY }
        val current = controller
        if (spotify != null && current != null && spotify.sessionToken == current.sessionToken) return

        current?.unregisterCallback(callback)
        controller = spotify
        if (spotify == null) {
            playbackState = null
            events.onAttached(false)
            return
        }
        spotify.registerCallback(callback, main)
        playbackState = spotify.playbackState
        events.onAttached(true)
        events.onMetadata(spotify.metadata)
        events.onPlaybackChanged()
    }

    /** Where the song is now, in ms, estimated between Spotify's position updates. */
    fun positionMs(now: Long, durationMs: Long): Long {
        val st = playbackState ?: return 0L
        val playing = st.state == PlaybackState.STATE_PLAYING
        if (now - pendingSeekAt < SEEK_HOLD_MS) {
            return LyricsFollow.estimatePosition(pendingSeekPos, pendingSeekAt, now, 1f, playing, durationMs)
        }
        return LyricsFollow.estimatePosition(
            st.position, st.lastPositionUpdateTime, now, st.playbackSpeed, playing, durationMs
        )
    }

    /** Jumps to [ms]; until Spotify confirms, the position is shown as if it already happened. */
    fun seekTo(ms: Long, now: Long) {
        pendingSeekPos = ms
        pendingSeekAt = now
        controller?.transportControls?.seekTo(ms)
    }

    fun playPause() {
        val tc = controller?.transportControls ?: return
        if (isPlaying) tc.pause() else tc.play()
    }

    fun previous() {
        controller?.transportControls?.skipToPrevious()
    }

    fun next() {
        controller?.transportControls?.skipToNext()
    }
}
