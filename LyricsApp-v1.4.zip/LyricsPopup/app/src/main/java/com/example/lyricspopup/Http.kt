package com.example.lyricspopup

import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.atomic.AtomicInteger

/** What one HTTP request returned: the status code and, for 2xx answers, the body text. */
class HttpReply(val code: Int, val body: String?)

/**
 * The network side of one lyrics lookup. It counts requests that got an answer and requests that
 * failed (to tell "no internet" from "not found"), and it can [cancel] everything still in flight,
 * which is what happens when the song changes before the lookup is done.
 */
class NetSession {

    companion object {
        const val USER_AGENT = "LyricsPopup/1.4 (Android; personal use)"
        private const val CONNECT_MS = 4000
        private const val READ_MS = 6000
        private const val DRAIN_LIMIT = 16 * 1024
    }

    private val answered = AtomicInteger()
    private val failed = AtomicInteger()
    private val open: MutableSet<HttpURLConnection> =
        Collections.synchronizedSet(HashSet<HttpURLConnection>())

    @Volatile
    var cancelled = false
        private set

    /** True when no request got an answer and at least one failed: most likely no internet. */
    val looksOffline: Boolean get() = answered.get() == 0 && failed.get() > 0

    /** Number of requests that failed with an I/O error or a timeout. */
    val failures: Int get() = failed.get()

    /** Stops the lookup: new requests are refused and running ones are aborted. Safe from any thread. */
    fun cancel() {
        cancelled = true
        val snapshot: List<HttpURLConnection> = synchronized(open) { ArrayList(open) }
        if (snapshot.isEmpty()) return
        // Closing a TLS socket does network work, which Android forbids on the main thread.
        val t = Thread {
            for (c in snapshot) {
                try { c.disconnect() } catch (e: Throwable) { }
            }
        }
        t.isDaemon = true
        t.start()
    }

    /**
     * GET [url]. Returns null only when the request itself failed (no network, timeout) or the
     * lookup was cancelled. A 404 comes back as an [HttpReply] with a null body.
     */
    fun get(url: String, headers: Map<String, String> = emptyMap()): HttpReply? {
        if (cancelled) return null
        var conn: HttpURLConnection? = null
        try {
            val c = URL(url).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = CONNECT_MS
            c.readTimeout = READ_MS
            c.setRequestProperty("User-Agent", USER_AGENT)
            for ((k, v) in headers) c.setRequestProperty(k, v)
            LegacyTls.prepare(c)
            open.add(c)
            if (cancelled) return null
            val code = c.responseCode
            val body = if (code in 200..299) {
                c.inputStream.bufferedReader().use { it.readText() }
            } else {
                drain(c)
                null
            }
            answered.incrementAndGet()
            return HttpReply(code, body)
        } catch (e: IOException) {
            if (!cancelled) failed.incrementAndGet()
            return null
        } catch (e: RuntimeException) {
            return null
        } finally {
            val c = conn
            if (c != null) {
                open.remove(c)
                try { c.disconnect() } catch (e: Throwable) { }
            }
        }
    }

    /** Reading an error body to its end lets the connection be reused for the next request. */
    private fun drain(c: HttpURLConnection) {
        try {
            val stream = c.errorStream ?: return
            stream.use { s ->
                val buf = ByteArray(2048)
                var total = 0
                while (total < DRAIN_LIMIT) {
                    val n = s.read(buf)
                    if (n < 0) break
                    total += n
                }
            }
        } catch (e: IOException) { }
    }
}
