package com.example.lyricspopup

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.widget.Toast

/** Colors and small helpers shared by the setup screen and the floating window. */
object Ui {
    val GREEN: Int = Color.parseColor("#1ED760")
    val BRIGHT: Int = Color.argb(245, 255, 255, 255)
    val DIM: Int = Color.argb(120, 255, 255, 255)
    val SOFT: Int = Color.argb(185, 255, 255, 255)

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density).toInt()

    fun toast(ctx: Context, text: String) {
        Toast.makeText(ctx, text, Toast.LENGTH_SHORT).show()
    }

    /** Opens a web page in the browser; says so instead of crashing when nothing can open it. */
    fun openUrl(ctx: Context, url: String) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast(ctx, "Couldn't open the link")
        }
    }
}
