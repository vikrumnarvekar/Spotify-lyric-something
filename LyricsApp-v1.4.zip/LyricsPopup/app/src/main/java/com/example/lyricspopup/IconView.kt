package com.example.lyricspopup

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/** Small drawn icons (transport buttons, header chips), so no emoji font is needed. */
internal class IconView(context: Context, var kind: Int) : View(context) {
    companion object {
        const val PLAY = 0
        const val PAUSE = 1
        const val PREV = 2
        const val NEXT = 3
        const val CHEV_DOWN = 4
        const val CHEV_UP = 5
        const val CLOSE = 6
        const val MINUS = 7
        const val OPACITY = 8
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val s = minOf(width, height) * 0.36f
        path.reset()
        when (kind) {
            PLAY -> {
                path.moveTo(cx - s * 0.7f, cy - s)
                path.lineTo(cx - s * 0.7f, cy + s)
                path.lineTo(cx + s, cy)
                path.close()
                c.drawPath(path, paint)
            }
            PAUSE -> {
                c.drawRoundRect(cx - s * 0.85f, cy - s, cx - s * 0.2f, cy + s, s * 0.15f, s * 0.15f, paint)
                c.drawRoundRect(cx + s * 0.2f, cy - s, cx + s * 0.85f, cy + s, s * 0.15f, s * 0.15f, paint)
            }
            PREV -> {
                c.drawRect(cx - s, cy - s * 0.85f, cx - s * 0.6f, cy + s * 0.85f, paint)
                path.moveTo(cx + s, cy - s * 0.9f)
                path.lineTo(cx + s, cy + s * 0.9f)
                path.lineTo(cx - s * 0.5f, cy)
                path.close()
                c.drawPath(path, paint)
            }
            CLOSE -> {
                stroke.strokeWidth = s * 0.28f
                val d = s * 0.62f
                c.drawLine(cx - d, cy - d, cx + d, cy + d, stroke)
                c.drawLine(cx - d, cy + d, cx + d, cy - d, stroke)
            }
            MINUS -> {
                stroke.strokeWidth = s * 0.28f
                c.drawLine(cx - s * 0.7f, cy, cx + s * 0.7f, cy, stroke)
            }
            OPACITY -> {
                stroke.strokeWidth = s * 0.24f
                val r = s * 0.7f
                c.drawCircle(cx, cy, r, stroke)
                c.drawArc(cx - r, cy - r, cx + r, cy + r, 90f, 180f, true, paint)
            }
            CHEV_DOWN, CHEV_UP -> {
                val dir = if (kind == CHEV_DOWN) 1f else -1f
                stroke.strokeWidth = s * 0.3f
                path.moveTo(cx - s * 0.75f, cy - dir * s * 0.3f)
                path.lineTo(cx, cy + dir * s * 0.3f)
                path.lineTo(cx + s * 0.75f, cy - dir * s * 0.3f)
                c.drawPath(path, stroke)
            }
            NEXT -> {
                c.drawRect(cx + s * 0.6f, cy - s * 0.85f, cx + s, cy + s * 0.85f, paint)
                path.moveTo(cx - s, cy - s * 0.9f)
                path.lineTo(cx - s, cy + s * 0.9f)
                path.lineTo(cx + s * 0.5f, cy)
                path.close()
                c.drawPath(path, paint)
            }
        }
    }
}
