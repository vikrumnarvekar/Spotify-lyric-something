package com.example.lyricspopup

/**
 * Lyrics without timestamps (for example from Genius) cannot be followed exactly, so this makes
 * an estimate: every singable line gets a share of the song's length in proportion to how many
 * syllables it has, after a short intro and before a short outro. It is only approximate; the
 * popup lets you correct it by holding the line that is being sung.
 *
 * Pure Kotlin so it can be unit-tested on a JVM.
 */
object PlainTiming {

    private val VOWEL_GROUP = Regex("[aeiouyAEIOUY]+")
    private val JUNK = Regex("""^\d*Embed$|^You might also like$""", RegexOption.IGNORE_CASE)

    fun estimate(plain: String, durationMs: Long): List<LrcLine> {
        if (durationMs < 20_000) return emptyList()

        val texts = ArrayList<String>()
        val weights = ArrayList<Double>()
        for (raw in plain.lines()) {
            val t = raw.trim()
            if (t.isEmpty()) {
                // a blank line is a breath between stanzas
                if (weights.isNotEmpty()) weights[weights.size - 1] = weights[weights.size - 1] + 2.5
                continue
            }
            if (isHeader(t) || JUNK.matches(t)) continue
            texts.add(t)
            weights.add(syllables(t) + 1.2)
        }
        if (texts.size < 2) return emptyList()

        val intro = (durationMs * 0.06).toLong().coerceIn(3_000L, 18_000L)
        val outro = (durationMs * 0.05).toLong().coerceIn(3_000L, 14_000L)
        var span = durationMs - intro - outro
        var start = intro
        if (span < 10_000L) { start = (durationMs * 0.05).toLong(); span = (durationMs * 0.9).toLong() }

        val total = weights.sum()
        val out = ArrayList<LrcLine>(texts.size)
        var cum = 0.0
        for (k in texts.indices) {
            out.add(LrcLine(start + (span * (cum / total)).toLong(), texts[k]))
            cum += weights[k]
        }
        return out
    }

    /** "[Chorus]", "[Verse 1: Name]" */
    fun isHeader(line: String) = line.length > 2 && line.startsWith("[") && line.endsWith("]")

    /** Rough singing length of a line: vowel groups for Latin words, one per letter otherwise. */
    fun syllables(line: String): Double {
        var n = 0.0
        for (word in line.split(Regex("\\s+"))) {
            if (word.isEmpty()) continue
            val latin = word.filter { it.code < 0x0250 && it.isLetter() }
            val other = word.count { it.code >= 0x0250 && it.isLetter() }
            if (latin.isNotEmpty()) n += VOWEL_GROUP.findAll(latin).count().coerceAtLeast(1)
            n += other * 0.9
        }
        return n.coerceAtLeast(1.0)
    }
}
