package com.example.lyricspopup

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.net.Uri
import android.os.Handler
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.ThreadFactory

/**
 * Everything that happens when the song changes: waits briefly for the song length, starts the
 * lyrics lookup, cancels it when the song changes again, and shows whatever comes back.
 * All methods are called on the main thread.
 */
class LyricsSession(
    private val ctx: Context,
    private val main: Handler,
    private val panel: OverlayPanel,
    private val lyrics: LyricsDisplay,
    private val repo: LyricsRepository,
    private val positionProvider: () -> Long
) {

    companion object {
        /** How long to wait for Spotify to report the song length before looking up lyrics without it. */
        private const val LENGTH_WAIT_MS = 1500L
    }

    private var trackKey: String? = null
    private var title = ""
    private var artist = ""
    private var album = ""
    private var artUri: String? = null
    private var geniusUrl: String? = null

    /** Length of the current song in ms, 0 while unknown. */
    var durationMs = 0L
        private set

    private var lookup: NetSession? = null
    private var lookupStarted = false
    private var lookupDurationMs = 0L          // the length that was known when the lookup began
    private var revalidated = false
    private var lastResult: LyricsResult? = null
    private var lastFinal = false
    private var shownSig = ""
    private var extrasStarted = false
    private var displayEstimated = false
    private var lastArtCheck = 0L
    private var lastLengthCheck = 0L
    private var destroyed = false

    private val worker: ExecutorService = Executors.newSingleThreadExecutor(daemonFactory("lyrics-lookup"))
    private val extrasWorker: ExecutorService = Executors.newSingleThreadExecutor(daemonFactory("lyrics-extras"))

    private val startLookupRunnable = Runnable { beginLookup() }

    private fun daemonFactory(name: String): ThreadFactory = ThreadFactory { r ->
        val t = Thread(r, name)
        t.isDaemon = true
        t
    }

    // ---------- events from Spotify ----------

    /** Spotify's session appeared (true) or went away (false). */
    fun onAttached(attached: Boolean) {
        if (attached) return        // metadata follows
        cancelLookup()
        trackKey = null
        durationMs = 0L
        lastResult = null
        panel.setTrack("Waiting for Spotify\u2026", "")
        panel.clearCover()
        lyrics.showStatus("Start playing a song in Spotify.")
    }

    fun onMetadata(md: MediaMetadata?) {
        if (md == null) return
        val newTitle = md.getString(MediaMetadata.METADATA_KEY_TITLE) ?: return
        val newArtist = md.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: ""
        val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val art = artFrom(md)
        val key = "$newTitle|$newArtist"

        if (key == trackKey) {
            // Same song, refreshed info. Spotify often delivers the cover (and length) a moment late.
            if (dur > 0) onLength(dur)
            if (art != null && !panel.hasCover) panel.setCover(art)
            return
        }
        startTrack(key, newTitle, newArtist, md, dur, art)
    }

    private fun startTrack(key: String, newTitle: String, newArtist: String, md: MediaMetadata, dur: Long, art: Bitmap?) {
        cancelLookup()
        trackKey = key
        title = newTitle
        artist = newArtist
        album = md.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        artUri = artUriFrom(md)
        durationMs = if (dur > 0) dur else 0L
        geniusUrl = null
        lastResult = null
        lastFinal = false
        shownSig = ""
        extrasStarted = false
        displayEstimated = false
        lookupStarted = false
        lookupDurationMs = 0L
        revalidated = false

        panel.setTrack(newTitle, newArtist)
        panel.clearCover()
        if (art != null) panel.setCover(art)
        lyrics.setShift(0L)
        lyrics.showStatus("Loading lyrics\u2026")
        lyrics.scrollToTop()

        if (TrackText.isAd(newTitle, newArtist)) {
            lyrics.showStatus("Advertisement playing\u2026")
            lookupStarted = true       // nothing to look up
            return
        }
        if (durationMs > 0) {
            beginLookup()
        } else {
            // Wait a moment for the length: lyrics for the wrong cut of a song drift out of sync.
            main.postDelayed(startLookupRunnable, LENGTH_WAIT_MS)
        }
    }

    /** The song length became known (possibly after the lookup already started). */
    private fun onLength(dur: Long) {
        val had = durationMs
        durationMs = dur
        if (!lookupStarted) {
            main.removeCallbacks(startLookupRunnable)
            beginLookup()
            return
        }
        if (had != 0L) return
        val res = lastResult ?: return
        // Plain lyrics can now get an estimated timing.
        if (res.synced.isEmpty() && !res.plain.isNullOrBlank()) {
            shownSig = ""
            renderResult(res, lastFinal)
        }
        maybeRevalidate(res)
    }

    /** Called from the window's ticker: asks Spotify for a late cover or song length, only when needed. */
    fun maintain(now: Long, metadata: () -> MediaMetadata?) {
        val needCover = !panel.hasCover && now - lastArtCheck > 2000
        val needLength = trackKey != null && durationMs <= 0 && now - lastLengthCheck > 500
        if (!needCover && !needLength) return
        if (needCover) lastArtCheck = now
        if (needLength) lastLengthCheck = now
        val md = metadata() ?: return
        if (needCover) artFrom(md)?.let { panel.setCover(it) }
        if (needLength && md.getLong(MediaMetadata.METADATA_KEY_DURATION) > 0) onMetadata(md)
    }

    // ---------- the lookup ----------

    private fun cancelLookup() {
        main.removeCallbacks(startLookupRunnable)
        lookup?.cancel()
        lookup = null
    }

    private fun beginLookup() {
        if (lookupStarted || destroyed) return
        val key = trackKey ?: return
        lookupStarted = true
        lookupDurationMs = durationMs
        val t = title
        val a = artist
        val al = album
        val d = durationMs
        val uri = artUri
        val net = repo.newLookup()
        lookup = net
        try {
            worker.execute {
                try {
                    repo.fetchProgressive(t, a, al, d, net) { res, final ->
                        main.post {
                            if (!destroyed && net === lookup && key == trackKey) onResult(res, final, uri)
                        }
                    }
                } catch (e: Throwable) {
                    CrashLog.record(ctx, e)
                }
            }
        } catch (e: Exception) {
            // the worker was shut down: the service is going away
        }
    }

    private fun onResult(res: LyricsResult, final: Boolean, art: String?) {
        lastResult = res
        lastFinal = final
        if (res.geniusUrl != null) geniusUrl = res.geniusUrl
        renderResult(res, final)
        maybeRevalidate(res)
        startExtras(art, res)
    }

    /**
     * Lyrics chosen before the song length was known may belong to another cut of the song, and their
     * timing would drift. Once the length is known, look again, this time with it (once per song).
     */
    private fun maybeRevalidate(res: LyricsResult) {
        if (revalidated || lookupDurationMs > 0 || durationMs <= 0 || !res.hasLyrics) return
        if (TrackText.sameLength(res.matchedDurationSec, durationMs)) return
        revalidated = true
        cancelLookup()
        lookupStarted = false
        extrasStarted = true       // the Genius link and cover were already looked up
        beginLookup()
    }

    /** User asked to try again (after a connection error). */
    fun retry() {
        if (trackKey == null || destroyed) return
        cancelLookup()
        lookupStarted = false
        lastResult = null
        lastFinal = false
        shownSig = ""
        lyrics.showStatus("Loading lyrics\u2026")
        beginLookup()
    }

    /** Genius link and cover fallback are looked up separately so they never delay the lyrics. */
    private fun startExtras(art: String?, res: LyricsResult) {
        if (extrasStarted) return
        extrasStarted = true
        if (res.geniusUrl != null && panel.hasCover) return
        val key = trackKey ?: return
        val t = title
        val a = artist
        val needCover = !panel.hasCover
        try {
            extrasWorker.execute {
                if (key != trackKey) return@execute
                val g = repo.geniusInfo(t, a)
                val url = art ?: g?.art ?: res.artUrl
                val bmp = if (url != null && needCover) repo.fetchBitmap(url) else null
                main.post {
                    if (destroyed || key != trackKey) return@post
                    if (g != null) geniusUrl = g.url
                    if (bmp != null && !panel.hasCover) panel.setCover(bmp)
                }
            }
        } catch (e: Exception) {
            // shutting down
        }
    }

    // ---------- showing a result ----------

    /** Romanizes Hindi/Japanese (and other scripts) when the language is set to English. */
    private fun conv(s: String, english: Boolean): String =
        if (english) Romanizer.toEnglish(s) { IcuTranslit.transliterate(it) } else s

    /** Real timed lines, or an estimate for plain lyrics once the song length is known. */
    private fun effectiveLines(res: LyricsResult): Pair<List<LrcLine>, Boolean> {
        if (res.synced.isNotEmpty()) return Pair(res.synced, res.estimated)
        val plain = res.plain
        if (!plain.isNullOrBlank() && durationMs > 0) {
            val est = PlainTiming.estimate(plain, durationMs)
            if (est.isNotEmpty()) return Pair(est, true)
        }
        return Pair(emptyList(), false)
    }

    private fun offsetKey() =
        "off_" + (if (displayEstimated) "e" else "s") + "_" + "$title|$artist".hashCode()

    private fun renderResult(res: LyricsResult, final: Boolean) {
        val english = Prefs.langEnglish(ctx)
        val (lines, est) = effectiveLines(res)
        val plain = res.plain
        val sig = when {
            res.hasLyrics -> "L|${lines.size}|${lines.firstOrNull()?.timeMs}|${plain?.length}|$est|$english"
            res.instrumental -> "I"
            final -> "F|${res.error}"
            else -> "loading"
        }
        if (sig == shownSig) return
        shownSig = sig

        when {
            res.hasLyrics -> {
                displayEstimated = est
                lyrics.setShift(Prefs.of(ctx).getLong(offsetKey(), 0L))
                panel.setArtist(artist + if (est) "  \u00B7  approx. timing" else "")
                if (lines.isNotEmpty()) {
                    lyrics.showSynced(lines.map { LrcLine(it.timeMs, conv(it.text, english)) })
                } else if (!plain.isNullOrBlank()) {
                    lyrics.showPlain(conv(plain, english))
                }
                lyrics.scrollToTop()
            }
            res.instrumental -> lyrics.showStatus("\u266A Instrumental \u266A")
            final -> {
                val err = res.error
                if (err != null) lyrics.showStatus(err + "\nTap to retry.") else lyrics.showNotFound(title, artist, geniusUrl)
                lyrics.scrollToTop()
            }
            else -> { }   // still loading
        }
    }

    /** The language setting changed: show the same lyrics again in the other script. */
    fun refreshLanguage() {
        val res = lastResult ?: return
        shownSig = ""
        renderResult(res, lastFinal)
    }

    // ---------- things the user does ----------

    /** Single tap on the lyrics: retry after an error, otherwise jump back to the current line. */
    fun onLyricsTap() {
        val r = lastResult
        if (lastFinal && r != null && r.error != null) retry() else lyrics.resumeFollow()
    }

    /** Holding a line while it is being sung re-aligns the timing (saved for this song). */
    fun syncTo(index: Int) {
        val lineMs = lyrics.lineTimeMs(index) ?: return
        val shift = positionProvider() - lineMs
        lyrics.setShift(shift)
        Prefs.of(ctx).edit().putLong(offsetKey(), shift).apply()
        lyrics.resumeFollow()
        lyrics.feedback()
        Ui.toast(ctx, "Synced to this line")
    }

    /** Holding the title forgets the saved timing correction for this song. */
    fun resetSync() {
        if (!lyrics.hasTimedLines) return
        lyrics.setShift(0L)
        Prefs.of(ctx).edit().remove(offsetKey()).apply()
        lyrics.feedback()
        Ui.toast(ctx, "Timing reset for this song")
    }

    fun openGenius() {
        // Exact Genius page if we matched one, otherwise a Genius search for the current song.
        val url = geniusUrl ?: ("https://genius.com/search?q=" + Uri.encode("$title $artist"))
        Ui.openUrl(ctx, url)
    }

    fun destroy() {
        destroyed = true
        cancelLookup()
        worker.shutdownNow()
        extrasWorker.shutdownNow()
    }

    // ---------- Spotify's metadata helpers ----------

    private fun artFrom(md: MediaMetadata): Bitmap? =
        md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)

    private fun artUriFrom(md: MediaMetadata): String? =
        listOf(
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        ).mapNotNull { md.getString(it) }.firstOrNull { it.startsWith("http") }
}
