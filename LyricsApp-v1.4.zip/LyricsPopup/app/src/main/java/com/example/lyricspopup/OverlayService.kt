package com.example.lyricspopup

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.media.MediaMetadata
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.WindowManager
import java.io.File

/**
 * Foreground service that owns the floating lyrics window. It only wires the pieces together:
 * [NowPlaying] (Spotify), [LyricsSession] (lookup and what to show), [OverlayPanel] (the window)
 * and [LyricsDisplay] (the lyrics area).
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.lyricspopup.STOP"
        private const val CHANNEL_ID = "lyrics_overlay"
        private const val NOTIF_ID = 42
        private const val TICK_MS = 250L

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())

    private lateinit var repo: LyricsRepository
    private lateinit var lyrics: LyricsDisplay
    private lateinit var panel: OverlayPanel
    private lateinit var session: LyricsSession
    private lateinit var nowPlaying: NowPlaying

    private var uiBuilt = false

    // ---------- the pieces report back here ----------

    private val nowEvents = object : NowPlaying.Events {
        override fun onAttached(attached: Boolean) {
            session.onAttached(attached)
        }

        override fun onMetadata(md: MediaMetadata?) {
            session.onMetadata(md)
        }

        override fun onPlaybackChanged() {
            panel.setPlaying(nowPlaying.isPlaying)
        }
    }

    private val lyricsEvents = object : LyricsDisplay.Events {
        override fun onLineHeld(index: Int) {
            session.syncTo(index)
        }

        override fun onTap() {
            session.onLyricsTap()
        }

        override fun onDoubleTap() {
            panel.showBubble()
        }
    }

    private val panelEvents = object : OverlayPanel.Events {
        override fun onPrevious() {
            nowPlaying.previous()
        }

        override fun onNext() {
            nowPlaying.next()
        }

        override fun onPlayPause() {
            nowPlaying.playPause()
        }

        override fun onSeek(ms: Long) {
            nowPlaying.seekTo(ms, SystemClock.elapsedRealtime())
            lyrics.resumeFollow()
        }

        override fun onOpenGenius() {
            session.openGenius()
        }

        override fun onClose() {
            stopSelf()
        }

        override fun onResetSync() {
            session.resetSync()
        }

        override fun onVisibilityChanged(panelVisible: Boolean) {
            // Nothing to follow while only the bubble is showing.
            main.removeCallbacks(ticker)
            if (panelVisible) main.post(ticker)
        }
    }

    // The preferences keep only a weak reference to a listener, so it must be held here.
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, k ->
        if (k == Prefs.KEY_LANG && uiBuilt) session.refreshLanguage()
    }

    private val ticker = object : Runnable {
        override fun run() {
            try {
                tick()
            } catch (t: Throwable) {
                CrashLog.record(this@OverlayService, t)
            }
            main.postDelayed(this, TICK_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        try {
            startAsForeground()
        } catch (t: Throwable) {
            // Android refuses to (re)start a foreground service from the background in some cases.
            CrashLog.record(this, t)
            stopSelf()
            return
        }
        running = true
        try {
            LegacyTls.install(this)
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            repo = LyricsRepository(cache = LyricsCache(File(cacheDir, "lyrics"))) { Prefs.token(this@OverlayService) }
            lyrics = LyricsDisplay(this, lyricsEvents)
            panel = OverlayPanel(this, wm, lyrics, panelEvents)
            session = LyricsSession(this, main, panel, lyrics, repo) { currentPosition() }
            nowPlaying = NowPlaying(this, main, nowEvents)
            Prefs.of(this).registerOnSharedPreferenceChangeListener(prefListener)
            uiBuilt = true

            panel.show()
            if (!nowPlaying.start()) {
                lyrics.showStatus("Notification access is not granted.\nOpen the app and finish setup step 2.")
            }
        } catch (t: Throwable) {
            CrashLog.record(this, t)
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    /** Rotation or a screen-size change: keep the window and bubble on screen. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (uiBuilt) panel.onScreenChanged()
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        if (uiBuilt) {
            try { Prefs.of(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Throwable) { }
            nowPlaying.stop()
            session.destroy()
            panel.destroy()
            repo.shutdown()
        }
        super.onDestroy()
    }

    // ---------- the window ticker (runs while the window is open) ----------

    private fun currentPosition(): Long = nowPlaying.positionMs(SystemClock.elapsedRealtime(), session.durationMs)

    private fun tick() {
        val now = SystemClock.elapsedRealtime()
        val dur = session.durationMs
        val pos = nowPlaying.positionMs(now, dur)
        panel.updateProgress(pos, dur)
        panel.setPlaying(nowPlaying.isPlaying)
        lyrics.follow(pos, dur, now)
        session.maintain(now) { nowPlaying.metadata }
    }

    // ---------- foreground notification ----------

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val immutable = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or immutable
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or immutable
        )
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Lyrics overlay", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, CHANNEL_ID)
        } else {
            builder = Notification.Builder(this).setPriority(Notification.PRIORITY_LOW)
        }
        builder.setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Lyrics Popup is running")
            .setContentText("Tap to open settings")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", stop)
        val n = builder.build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
