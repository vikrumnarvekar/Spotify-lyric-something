package com.example.lyricspopup

import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/** Lyrics found earlier, kept on disk so a replayed song shows instantly (and without internet). */
class LyricsCache(private val dir: File, private val maxFiles: Int = 400) {

    class Entry(
        val source: String,
        val rank: Int,
        val cand: Candidate,
        val geniusUrl: String?,
        val artUrl: String?
    )

    companion object {
        private const val DAY_MS = 24L * 60L * 60L * 1000L
        private const val TTL_TIMED_MS = 60L * DAY_MS
        private const val TTL_PLAIN_MS = 2L * DAY_MS
        private const val TTL_INSTRUMENTAL_MS = 30L * DAY_MS

        /** Deletes every saved lyric file in [dir]; returns how many were removed. */
        fun clearAll(dir: File): Int {
            var n = 0
            val files = dir.listFiles() ?: return 0
            for (f in files) if (f.delete()) n++
            return n
        }
    }

    private var writes = 0

    @Synchronized
    fun load(title: String, artist: String, now: Long = System.currentTimeMillis()): Entry? {
        try {
            val f = fileFor(title, artist)
            if (!f.isFile) return null
            val o = JSONObject(f.readText())
            val cand = Candidate(
                durationSec = if (o.has("dur")) o.optDouble("dur") else null,
                plain = o.optString("plain", "").takeIf { it.isNotBlank() },
                synced = o.optString("synced", "").takeIf { it.isNotBlank() },
                instrumental = o.optBoolean("inst", false)
            )
            val age = now - o.optLong("t", 0L)
            val ttl = when {
                cand.instrumental -> TTL_INSTRUMENTAL_MS
                cand.synced != null -> TTL_TIMED_MS
                else -> TTL_PLAIN_MS
            }
            if (age < 0 || age > ttl) {
                f.delete()
                return null
            }
            return Entry(
                source = o.optString("src", "cache"),
                rank = o.optInt("rank", 0),
                cand = cand,
                geniusUrl = o.optString("g", "").takeIf { it.isNotBlank() },
                artUrl = o.optString("art", "").takeIf { it.isNotBlank() }
            )
        } catch (e: Exception) {
            return null
        }
    }

    @Synchronized
    fun save(title: String, artist: String, entry: Entry, now: Long = System.currentTimeMillis()) {
        try {
            if (!dir.isDirectory && !dir.mkdirs()) return
            val o = JSONObject()
            o.put("t", now)
            o.put("src", entry.source)
            o.put("rank", entry.rank)
            entry.cand.durationSec?.let { o.put("dur", it) }
            entry.cand.plain?.let { o.put("plain", it) }
            entry.cand.synced?.let { o.put("synced", it) }
            o.put("inst", entry.cand.instrumental)
            entry.geniusUrl?.let { o.put("g", it) }
            entry.artUrl?.let { o.put("art", it) }
            val target = fileFor(title, artist)
            val tmp = File(dir, target.name + ".tmp")
            tmp.writeText(o.toString())
            if (!tmp.renameTo(target)) {
                target.delete()
                tmp.renameTo(target)
            }
            writes++
            if (writes % 20 == 0) prune()
        } catch (e: Exception) {
            // The cache is only a speed-up; never let it break a lookup.
        }
    }

    private fun prune() {
        val files = dir.listFiles { f -> f.name.endsWith(".json") } ?: return
        if (files.size <= maxFiles) return
        val oldestFirst = files.sortedBy { it.lastModified() }
        for (f in oldestFirst.take(files.size - maxFiles)) f.delete()
    }

    private fun fileFor(title: String, artist: String): File {
        val md = MessageDigest.getInstance("SHA-1")
            .digest(("$title|$artist").lowercase().toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(md.size * 2)
        for (b in md) {
            sb.append(Character.forDigit((b.toInt() shr 4) and 0xF, 16))
            sb.append(Character.forDigit(b.toInt() and 0xF, 16))
        }
        return File(dir, sb.toString() + ".json")
    }
}
