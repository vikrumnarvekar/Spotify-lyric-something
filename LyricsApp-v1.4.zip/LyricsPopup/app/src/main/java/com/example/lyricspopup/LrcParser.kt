package com.example.lyricspopup

/** One timed lyric line from an LRC file. */
data class LrcLine(val timeMs: Long, val text: String)

/**
 * Parser for the LRC "synced lyrics" format: lines like "[01:23.45] text".
 * Pure Kotlin (no Android classes) so it can be unit-tested on a plain JVM.
 */
object LrcParser {

    private val TIME_TAG = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val OFFSET_TAG = Regex("""\[offset:\s*([+-]?\d+)\s*]""", RegexOption.IGNORE_CASE)

    fun parse(lrc: String): List<LrcLine> {
        // "[offset:+500]" means the lyrics should appear 500 ms sooner than their timestamps say.
        val offset = OFFSET_TAG.find(lrc)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        val out = ArrayList<LrcLine>()
        for (raw in lrc.lineSequence()) {
            val line = raw.trim()
            if (!line.startsWith("[")) continue

            // Consume every leading time tag; a line may carry several: "[00:10.0][01:20.0]text"
            val times = ArrayList<Long>()
            var idx = 0
            while (idx < line.length) {
                val m = TIME_TAG.find(line, idx)
                if (m == null || m.range.first != idx) break
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                times.add(min * 60_000L + sec * 1_000L + ms)
                idx = m.range.last + 1
            }
            if (times.isEmpty()) continue        // metadata like [ar:Artist] or [length:3:20]
            val text = line.substring(idx).trim()
            for (t in times) out.add(LrcLine((t - offset).coerceAtLeast(0L), text))
        }
        return out.sortedBy { it.timeMs }        // sortedBy is stable
    }

    /** Index of the line being sung at [positionMs], or -1 before the first line. */
    fun currentIndex(lines: List<LrcLine>, positionMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= positionMs) {
                ans = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return ans
    }
}
