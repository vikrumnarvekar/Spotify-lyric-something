package com.example.lyricspopup

import android.content.Context
import android.os.Build
import java.net.HttpURLConnection
import java.security.KeyStore
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.TrustManager
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager

/**
 * Phones older than Android 7.1.1 don't know the Let's Encrypt root certificate, so many websites
 * fail there with a certificate error. On those phones the root certificate bundled in
 * res/raw/extra_roots.pem is trusted in addition to the phone's own list. Newer phones are untouched.
 */
object LegacyTls {

    @Volatile
    private var factory: SSLSocketFactory? = null

    fun install(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 25 || factory != null) return
        try {
            val cf = CertificateFactory.getInstance("X.509")
            val extra = ctx.resources.openRawResource(R.raw.extra_roots).use { cf.generateCertificates(it) }
            val ks = KeyStore.getInstance(KeyStore.getDefaultType())
            ks.load(null, null)
            var n = 0
            for (c in extra) {
                ks.setCertificateEntry("extra" + n, c)
                n++
            }
            val system = trustManager(null)
            val ours = trustManager(ks)
            val both = object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                    system.checkClientTrusted(chain, authType)
                }

                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                    try {
                        system.checkServerTrusted(chain, authType)
                    } catch (e: CertificateException) {
                        ours.checkServerTrusted(chain, authType)
                    }
                }

                override fun getAcceptedIssuers(): Array<X509Certificate> =
                    system.acceptedIssuers + ours.acceptedIssuers
            }
            val tls = SSLContext.getInstance("TLS")
            tls.init(null, arrayOf<TrustManager>(both), null)
            factory = tls.socketFactory
        } catch (e: Throwable) {
            factory = null          // keep the phone's default behaviour
        }
    }

    /** Call on every new connection before it is used. Does nothing on newer phones. */
    fun prepare(conn: HttpURLConnection) {
        val f = factory ?: return
        if (conn is HttpsURLConnection) conn.sslSocketFactory = f
    }

    private fun trustManager(ks: KeyStore?): X509TrustManager {
        val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
        tmf.init(ks)
        return tmf.trustManagers.filterIsInstance<X509TrustManager>().first()
    }
}
