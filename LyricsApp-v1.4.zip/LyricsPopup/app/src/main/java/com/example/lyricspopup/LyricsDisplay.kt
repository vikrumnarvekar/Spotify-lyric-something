package com.example.lyricspopup

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.SystemClock
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.ScrollView
import android.widget.TextView

/**
 * The scrolling lyrics area: shows status messages, plain or timed lyrics, highlights the line that
 * is being sung and keeps it in the middle (unless you are scrolling yourself).
 */
class LyricsDisplay(private val ctx: Context, private val events: Events) {

    interface Events {
        /** A timed line was held down: the user says "this line is being sung right now". */
        fun onLineHeld(index: Int)

        /** Single tap on the lyrics. */
        fun onTap()

        /** Double tap on the lyrics (collapses the window to the bubble). */
        fun onDoubleTap()
    }

    companion object {
        private const val LOOKAHEAD_MS = 250L       // highlight a line a hair early
        private const val USER_HOLD_MS = 6000L      // leave the scroll alone after you touch it
    }

    private var synced: List<LrcLine> = emptyList()
    private var lineStarts = IntArray(0)
    private var lineEnds = IntArray(0)
    private var plainMode = false
    private var highlightIdx = -2
    private var highlightSpan: ForegroundColorSpan? = null
    private var recenter = true
    private var lastUserTouch = -USER_HOLD_MS

    /** Timing correction for this song, set by holding the line that is being sung. */
    var syncShiftMs = 0L
        private set

    private val text = TextView(ctx).apply {
        setTextColor(Ui.BRIGHT)
        textSize = 19f
        gravity = Gravity.CENTER_HORIZONTAL
        setTypeface(typeface, Typeface.BOLD)
        setLineSpacing(0f, 1.3f)
        setPadding(Ui.dp(ctx, 6), Ui.dp(ctx, 16), Ui.dp(ctx, 6), Ui.dp(ctx, 40))
        setShadowLayer(Ui.dp(ctx, 4).toFloat(), 0f, Ui.dp(ctx, 1).toFloat(), Color.argb(210, 0, 0, 0))
        addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> recenter = true }
    }

    /** The view to put into the window. */
    val view = ScrollView(ctx).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        addView(text)
    }

    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            events.onDoubleTap()
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            holdAt(e)
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            events.onTap()
            return true
        }
    })

    init {
        // Touching pauses auto-follow for a few seconds.
        view.setOnTouchListener { _, e ->
            gestures.onTouchEvent(e)
            if (e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE) {
                lastUserTouch = SystemClock.elapsedRealtime()
                recenter = true
            }
            false   // let the ScrollView keep scrolling normally
        }
    }

    val hasTimedLines: Boolean get() = synced.isNotEmpty()

    fun lineTimeMs(index: Int): Long? = synced.getOrNull(index)?.timeMs

    /** Go back to following the song right away (e.g. after a seek or a tap). */
    fun resumeFollow() {
        lastUserTouch = -USER_HOLD_MS
        recenter = true
    }

    /** Re-centre on the next tick (the window size changed). */
    fun requestRecenter() {
        recenter = true
    }

    fun setShift(ms: Long) {
        syncShiftMs = ms
        highlightIdx = -2
        recenter = true
    }

    /** A short buzz to confirm a long press. */
    fun feedback() {
        text.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    fun scrollToTop() {
        view.scrollTo(0, 0)
    }

    /** Called about four times a second while the window is open. */
    fun follow(posMs: Long, durMs: Long, now: Long) {
        if (text.layout == null || text.height <= 0) return
        val userBusy = now - lastUserTouch < USER_HOLD_MS
        if (synced.isNotEmpty()) {
            val idx = LrcParser.currentIndex(synced, posMs + LOOKAHEAD_MS - syncShiftMs)
            val changed = idx != highlightIdx
            if (changed) setHighlight(idx)
            if ((changed || recenter) && !userBusy) {
                scrollToLine(idx)
                recenter = false
            }
        } else if (plainMode && !userBusy && durMs > 0) {
            val range = text.height - view.height
            if (range > 0) {
                view.scrollTo(0, (LyricsFollow.plainFraction(posMs, durMs) * range).toInt())
            }
        }
    }

    // ---------- what to show ----------

    private fun resetFollow() {
        synced = emptyList()
        lineStarts = IntArray(0)
        lineEnds = IntArray(0)
        plainMode = false
        highlightIdx = -2
        highlightSpan = null
        recenter = true
    }

    /** A short message (loading, errors, instrumental...). */
    fun showStatus(message: String) {
        resetFollow()
        text.movementMethod = null
        text.setTextColor(Ui.BRIGHT)
        text.setText(message, TextView.BufferType.SPANNABLE)
    }

    fun showPlain(lyrics: String) {
        resetFollow()
        plainMode = true
        text.movementMethod = null
        text.setTextColor(Ui.BRIGHT)
        text.setText(lyrics, TextView.BufferType.SPANNABLE)
    }

    /** Timed lyrics: every line dim, the line being sung bright, scrolled to the middle. */
    fun showSynced(lines: List<LrcLine>) {
        resetFollow()
        val b = LyricsFollow.build(lines)
        synced = lines
        lineStarts = b.starts
        lineEnds = b.ends
        text.movementMethod = null
        text.setTextColor(Ui.DIM)
        text.setText(b.text, TextView.BufferType.SPANNABLE)
    }

    /** No lyrics in any source we can read: show tappable links to where they can be found. */
    fun showNotFound(title: String, artist: String, geniusUrl: String?) {
        resetFollow()
        val q = Uri.encode("$title $artist")
        val links = listOf(
            "Genius" to (geniusUrl ?: "https://genius.com/search?q=$q"),
            "Google" to ("https://www.google.com/search?q=" + Uri.encode("$title $artist lyrics")),
            "Musixmatch" to "https://www.musixmatch.com/search/$q",
            "YouTube" to ("https://www.youtube.com/results?search_query=" + Uri.encode("$title $artist lyrics"))
        )
        val sb = SpannableStringBuilder(
            "These lyrics aren't in the sources this app can read.\nTap a site to find them:\n"
        )
        for ((name, url) in links) {
            sb.append("\n")
            val start = sb.length
            sb.append("\u25B6  $name")
            sb.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) {
                    Ui.openUrl(ctx, url)
                }
            }, start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        text.setTextColor(Ui.BRIGHT)
        text.setLinkTextColor(Ui.GREEN)
        text.movementMethod = LinkMovementMethod.getInstance()
        text.setText(sb, TextView.BufferType.SPANNABLE)
    }

    // ---------- internals ----------

    private fun setHighlight(idx: Int) {
        val sp = text.text as? Spannable ?: return
        highlightSpan?.let { sp.removeSpan(it) }
        highlightSpan = null
        if (idx in synced.indices) {
            val span = ForegroundColorSpan(Ui.BRIGHT)
            sp.setSpan(span, lineStarts[idx], lineEnds[idx], Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            highlightSpan = span
        }
        highlightIdx = idx
    }

    private fun scrollToLine(idx: Int) {
        if (idx < 0) {
            view.smoothScrollTo(0, 0)
            return
        }
        val l = text.layout ?: return
        val first = l.getLineForOffset(lineStarts[idx])
        val last = l.getLineForOffset((lineEnds[idx] - 1).coerceAtLeast(lineStarts[idx]))
        val mid = (l.getLineTop(first) + l.getLineBottom(last)) / 2 + text.paddingTop
        view.smoothScrollTo(0, (mid - view.height / 2).coerceAtLeast(0))
    }

    /** Which timed line is under the finger. */
    private fun holdAt(e: MotionEvent) {
        if (synced.isEmpty()) return
        val l = text.layout ?: return
        val y = (e.y + view.scrollY - text.top - text.paddingTop).toInt().coerceIn(0, l.height)
        val off = l.getLineStart(l.getLineForVertical(y))
        var idx = 0
        for (k in lineStarts.indices) {
            if (lineStarts[k] <= off) idx = k else break
        }
        events.onLineHeld(idx)
    }
}
