# Lyrics Popup

A see-through, floating lyrics window that follows the song playing in Spotify. Personal project,
made for my own phone. Works on Android 5.0 and newer (including older Redmi phones).

## Where the lyrics come from

All of these are looked up at the same time and the best result is shown first:

| Source | What it gives | How |
|---|---|---|
| LRCLIB | Timed lyrics (best) | Public API |
| NetEase Cloud Music | Timed lyrics, good for Japanese and Indian pop | Unofficial web endpoint |
| Genius | Plain text, timing estimated from the song length | **Reads the public song page (scraping)**; the Genius API only gives the page link and cover |
| lyrics.ovh | Plain text, last resort | Public API |

Honest note: reading lyrics from the Genius page and using NetEase's unofficial endpoint is not
something those sites allow in their terms. This app is for my own personal use on my own phone and
nobody else uses it. Do not publish or distribute a build of it. Lyrics belong to their owners.

Found lyrics are saved on the phone (up to 400 songs), so a replayed song shows instantly and works
without internet. "Advanced > Clear saved lyrics" empties that. Nothing is sent anywhere except the
song title and artist to the sources above.

## Setup (on the phone)

1. Install the APK. If you had an older build installed, uninstall it once first (older builds were
   signed with a different key; builds from this version on can update each other).
2. Open the app and finish the two steps: "Show over other apps" and "Read what's playing".
   On Android 13+ the notification-access switch may be greyed out for sideloaded apps:
   App info > ⋮ menu > Allow restricted settings, then try again.
3. Tap "Start lyrics popup", then play a song in Spotify.

Redmi / Xiaomi / POCO: the app shows a card with shortcuts. Turn on "Display pop-up windows while
running in the background" and Autostart, set Battery saver to "No restrictions", and lock the app
in the recent-apps screen, or MIUI will close it in the background.

## Using the popup

- Drag the title to move it (it can't be dragged off the screen). Double-tap the title or lyrics, or
  tap –, to shrink it into a ♪ bubble. Tap the bubble to bring it back.
- Drag the ◢ corner to resize. The chip beside it chooses Window (size only) or Scale (zoom everything).
- ◐ changes transparency. The tab next to G hides or shows the player controls. G opens the song on Genius.
- Tap the lyrics to jump back to the current line, or to retry after a connection error.
- Lyrics a little off? Hold the line being sung right now and everything re-aligns (saved per song).
  Hold the song title to undo it.
- The notification has a Stop button.

## Building

Push the folder to GitHub: Actions > "Build APK" produces `LyricsPopup-debug-apk`. The unit tests run
in a separate job, so a failing test never blocks the APK. Or open the folder in Android Studio.

Debug builds are signed with the fixed throwaway key in `app/debug.keystore` so that every build can
update the previous one. Do not use that key for anything you publish.

## Code map

- `OverlayService` wires everything together and owns the notification.
- `NowPlaying` watches Spotify's media session. `LyricsSession` handles song changes and the lookup
  (waits briefly for the song length, cancels stale lookups, re-checks lyrics chosen without a length).
- `OverlayPanel` is the window and bubble; `LyricsDisplay` is the scrolling lyrics.
- `LyricsRepository` + `Http` (`NetSession`) + `LyricsCache` do the lookups, with bounded thread pools.
- `LegacyTls` adds the Let's Encrypt root certificate on phones older than Android 7.1.1.
- Pure helpers with unit tests in `src/test`: `LrcParser`, `TrackText`, `PlainTiming`, `LyricsFollow`, `Romanizer`.
